mkdir -p assets
cp -r ../assets/flash0 assets/
cp -r ../assets/lang assets/
cp -r ../assets/shaders assets/
cp -r ../assets/themes assets/
cp -r ../assets/debugger assets/
cp -r ../assets/upload assets/
cp -r ../assets/ui_images assets/
cp ../assets/*.ini assets/
cp ../assets/*.ttf assets/
cp ../assets/*.png assets/
cp ../assets/*.zim assets/
cp ../assets/*.meta assets/
cp ../assets/*.wav assets/
NDK_MODULE_PATH=../ext $NDK/ndk-build -j3 $*
