#!/bin/bash
cd "${0%/*}"
exec ./gearcoleco "$@"
