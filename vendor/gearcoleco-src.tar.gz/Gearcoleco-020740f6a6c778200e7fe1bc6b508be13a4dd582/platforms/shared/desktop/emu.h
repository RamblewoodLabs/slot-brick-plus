/*
 * Gearcoleco - ColecoVision Emulator
 * Copyright (C) 2021  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#ifndef EMU_H
#define EMU_H

#include "gearcoleco.h"

#ifdef EMU_IMPORT
    #define EXTERN
#else
    #define EXTERN extern
#endif

enum Debug_Command
{
    Debug_Command_Continue,
    Debug_Command_Step,
    Debug_Command_StepFrame,
    Debug_Command_None
};

enum Directory_Location
{
    Directory_Location_Default = 0,
    Directory_Location_ROM = 1,
    Directory_Location_Custom = 2
};

struct Emu_AdamMediaInfo
{
    bool inserted;
    bool write_protected;
    bool dirty;
    bool state_owned;
    GC_AdamMediaType type;
    size_t size;
    u32 base_crc;
    char path[4096];
    char working_path[4096];
};

#define EMU_FRAME_BUFFER_WIDTH 512
#define EMU_FRAME_BUFFER_HEIGHT 512
#define EMU_FRAME_BUFFER_SIZE (EMU_FRAME_BUFFER_WIDTH * EMU_FRAME_BUFFER_HEIGHT * 4)

EXTERN u8* emu_frame_buffer;
EXTERN GC_SaveState_Header emu_savestates[5];
EXTERN GC_SaveState_Screenshot emu_savestates_screenshots[5];
EXTERN u32 emu_savestates_generation;
EXTERN u8* emu_debug_background_buffer;
EXTERN u8* emu_debug_tile_buffer;
EXTERN u8* emu_debug_sprite_buffers[GC_MAX_SPRITES];
EXTERN u8* emu_debug_f18a_nametable_buffer;
EXTERN u8* emu_debug_f18a_pattern_buffer;
EXTERN u8* emu_debug_f18a_sprite_buffers[GC_MAX_SPRITES];
EXTERN int emu_debug_f18a_sprite_sizes[GC_MAX_SPRITES];

EXTERN Debug_Command emu_debug_command;
EXTERN bool emu_debug_pc_changed;
EXTERN int emu_debug_step_frames_pending;
EXTERN u64 emu_frame_counter;
EXTERN u64 emu_video_frame_counter;
EXTERN bool emu_video_recording_frame_pending;
EXTERN bool emu_audio_sync;
EXTERN bool emu_audio_rate_control;
EXTERN float emu_audio_ratio;
EXTERN bool emu_debug_disable_breakpoints;
EXTERN bool emu_debug_irq_breakpoints;
EXTERN bool emu_debug_tile_color_mode;
EXTERN int emu_debug_f18a_layer;
EXTERN int emu_debug_f18a_pattern_palette;

EXTERN bool emu_init(void);
EXTERN void emu_destroy(void);
EXTERN void emu_update(void);
EXTERN bool emu_load_media_async(const char* file_path, Cartridge::ForceConfiguration config);
EXTERN bool emu_is_media_loading(void);
EXTERN bool emu_is_busy(void);
EXTERN bool emu_finish_media_loading(void);
EXTERN GC_Machine emu_get_last_load_machine(void);
EXTERN bool emu_get_last_load_result(void);
EXTERN void emu_reset_rewind_timing(void);
EXTERN void emu_key_pressed(GC_Controllers controller, GC_Keys key);
EXTERN void emu_key_released(GC_Controllers controller, GC_Keys key);
EXTERN void emu_spinner1(int movement);
EXTERN void emu_spinner2(int movement);
EXTERN void emu_pause(void);
EXTERN void emu_resume(void);
EXTERN bool emu_is_paused(void);
EXTERN bool emu_is_debug_idle(void);
EXTERN bool emu_is_empty(void);
EXTERN bool emu_is_bios_loaded(void);
EXTERN bool emu_start_adam(const char* const* media_paths = NULL);
EXTERN bool emu_power_off_adam(void);
EXTERN bool emu_unload_content(void);
EXTERN bool emu_load_adam_firmware(GC_AdamFirmware firmware, const char* file_path);
EXTERN bool emu_is_adam_firmware_loaded(GC_AdamFirmware firmware);
EXTERN void emu_get_adam_firmware_path(GC_AdamFirmware firmware, char* path, size_t path_size);
EXTERN bool emu_inspect_adam_firmware(GC_AdamFirmware firmware, const char* file_path, size_t* actual_size, u32* crc);
EXTERN bool emu_are_adam_firmware_paths_valid(void);
EXTERN bool emu_replace_adam_media(GC_AdamMediaSlot slot, const char* file_path, bool discard_current_changes);
EXTERN int emu_get_adam_playlist_count(GC_AdamMediaSlot slot);
EXTERN int emu_get_adam_playlist_index(GC_AdamMediaSlot slot);
EXTERN const char* emu_get_adam_playlist_name(GC_AdamMediaSlot slot, int index);
EXTERN bool emu_select_adam_playlist_entry(GC_AdamMediaSlot slot, int index, bool discard_current_changes);
EXTERN bool emu_save_adam_media(GC_AdamMediaSlot slot);
EXTERN bool emu_save_adam_media_as(GC_AdamMediaSlot slot, const char* file_path);
EXTERN bool emu_discard_adam_media_changes(GC_AdamMediaSlot slot);
EXTERN bool emu_discard_all_adam_media_changes(void);
EXTERN bool emu_flush_adam_media(void);
EXTERN bool emu_eject_adam_media(GC_AdamMediaSlot slot);
EXTERN bool emu_set_adam_media_write_protected(GC_AdamMediaSlot slot, bool write_protected);
EXTERN bool emu_get_adam_media_info(GC_AdamMediaSlot slot, Emu_AdamMediaInfo* info);
EXTERN void emu_reconcile_adam_media_after_state_load(void);
EXTERN bool emu_save_adam_printer(const char* file_path);
EXTERN void emu_clear_adam_printer(void);
EXTERN void emu_adam_key_pressed(GC_AdamKey key);
EXTERN void emu_adam_key_released(GC_AdamKey key);
EXTERN void emu_adam_release_all_keys(void);
EXTERN void emu_adam_host_key_pressed(int usage);
EXTERN void emu_adam_host_key_released(int usage);
EXTERN void emu_adam_release_all_host_keys(void);
EXTERN bool emu_key_mapper_is_open(void);
EXTERN void emu_host_hotkey_used(void);
EXTERN bool emu_has_pointer(void);
EXTERN void emu_key_mapper_toggle(void);
EXTERN void emu_key_mapper_set_pointer(int x, int y);
EXTERN void emu_key_mapper_set_buttons(u8 buttons);
EXTERN bool emu_key_mapping_is_enabled(void);
EXTERN void emu_key_mapping_toggle(void);
EXTERN const char* emu_key_map_get_path(void);
EXTERN void emu_key_map_save(void);
EXTERN GC_Machine emu_get_machine(void);
EXTERN const char* emu_get_content_path(void);
EXTERN const char* emu_get_content_name(void);
EXTERN bool emu_get_debug_identity(char* identity, size_t identity_size);
EXTERN void emu_save_persistent_data(void);
EXTERN void emu_reset(Cartridge::ForceConfiguration config, bool adam_computer = false, bool save_persistent_data = true);
EXTERN void emu_audio_mute(bool mute);
EXTERN void emu_audio_set_master_volume(float volume);
EXTERN void emu_audio_reset(void);
EXTERN void emu_audio_restart(void);
EXTERN bool emu_is_audio_open(void);
EXTERN void emu_palette(GC_Color* palette);
EXTERN void emu_predefined_palette(int palette);
EXTERN void emu_save_ram(const char* file_path);
EXTERN void emu_load_ram(const char* file_path, Cartridge::ForceConfiguration config);
EXTERN bool emu_save_state_slot(int index);
EXTERN bool emu_load_state_slot(int index);
EXTERN bool emu_save_state_file(const char* file_path);
EXTERN bool emu_load_state_file(const char* file_path);
EXTERN void emu_debug_state_restored(void);
EXTERN void emu_restore_adam_state_screenshot(const char* file_path);
EXTERN void emu_get_runtime(GC_RuntimeInfo& runtime);
EXTERN double emu_get_frame_rate(void);
EXTERN void emu_get_info(char* info, int buffer_size);
EXTERN GearcolecoCore* emu_get_core(void);
EXTERN void emu_debug_step_over(void);
EXTERN void emu_debug_step_into(void);
EXTERN void emu_debug_step_out(void);
EXTERN void emu_debug_step_frame(void);
EXTERN void emu_debug_step_frames(int frames);
EXTERN void emu_debug_break(void);
EXTERN void emu_debug_continue(void);
EXTERN void emu_set_disassembler_syntax(int syntax);
EXTERN void emu_mcp_start(void);
EXTERN void emu_mcp_stop(void);
EXTERN void emu_mcp_set_transport(int mode, int port, const char* address);
EXTERN bool emu_mcp_is_running(void);
EXTERN int emu_mcp_get_transport_mode(void);
EXTERN const char* emu_mcp_get_http_address(void);
EXTERN int emu_mcp_get_http_port(void);
EXTERN void emu_mcp_pump_commands(void);
EXTERN bool emu_load_bios(const char* file_path);
EXTERN void emu_video_no_sprite_limit(bool enabled);
EXTERN void emu_set_video_chip(int video_chip);
EXTERN void emu_set_overscan(int overscan);
EXTERN bool emu_save_screenshot(const char* file_path);
EXTERN bool emu_save_sprite(const char* file_path, int index);
EXTERN bool emu_save_background(const char* file_path);
EXTERN bool emu_save_tiles(const char* file_path);
EXTERN int emu_get_screenshot_png(unsigned char** out_buffer);
EXTERN int emu_get_sprite_png(int sprite_index, unsigned char** out_buffer);
EXTERN bool emu_start_vgm_recording(const char* file_path);
EXTERN void emu_stop_vgm_recording(void);
EXTERN bool emu_is_vgm_recording(void);
EXTERN bool emu_start_video_recording(const char* file_path);
EXTERN void emu_stop_video_recording(void);
EXTERN bool emu_is_video_recording(void);
EXTERN void update_savestates_data(void);

#undef EMU_IMPORT
#undef EXTERN
#endif /* EMU_H */
