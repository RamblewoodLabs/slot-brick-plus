/*
 * Gearcoleco - ColecoVision Emulator
 * Copyright (C) 2021  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#include "config_macros.h"
#include "hotkeys.h"
#include "shader_preset.h"

static inline void process(config_Operation operation)
{
    //**************************************
    // Debug
    //**************************************

    // Debugger windows
    CONFIG_BOOL("Debug", "Debug", config_debug.debug, false);
    CONFIG_BOOL("Debug", "Disassembler", config_debug.show_disassembler, true);
    CONFIG_BOOL("Debug", "Screen", config_debug.show_screen, true);
    CONFIG_BOOL("Debug", "Memory", config_debug.show_memory, false);
    CONFIG_BOOL("Debug", "Processor", config_debug.show_processor, true);
    CONFIG_BOOL("Debug", "CallStack", config_debug.show_call_stack, false);
    CONFIG_BOOL("Debug", "Breakpoints", config_debug.show_breakpoints, false);
    CONFIG_BOOL("Debug", "Symbols", config_debug.show_symbols, false);
    CONFIG_BOOL("Debug", "Profiler", config_debug.show_profiler, false);
    CONFIG_BOOL("Debug", "Video", config_debug.show_video, false);
    CONFIG_BOOL("Debug", "TMS9918ANameTable", config_debug.show_tms9918a_nametable, false);
    CONFIG_BOOL("Debug", "TMS9918APatterns", config_debug.show_tms9918a_patterns, false);
    CONFIG_BOOL("Debug", "TMS9918ASprites", config_debug.show_tms9918a_sprites, false);
    CONFIG_BOOL("Debug", "TMS9918APalettes", config_debug.show_tms9918a_palettes, false);
    CONFIG_BOOL("Debug", "F18ANameTables", config_debug.show_f18a_nametables, false);
    CONFIG_BOOL("Debug", "F18APatterns", config_debug.show_f18a_patterns, false);
    CONFIG_BOOL("Debug", "F18ASprites", config_debug.show_f18a_sprites, false);
    CONFIG_BOOL("Debug", "F18APalette", config_debug.show_f18a_palette, false);
    CONFIG_BOOL("Debug", "TMS9918ARegs", config_debug.show_tms9918a_regs, false);
    CONFIG_BOOL("Debug", "F18ARegs", config_debug.show_f18a_regs, false);
    CONFIG_BOOL("Debug", "F18AExtendedRegs", config_debug.show_f18a_extended_regs, false);
    CONFIG_BOOL("Debug", "PSG", config_debug.show_psg, false);
    CONFIG_BOOL("Debug", "AY8910", config_debug.show_ay8910, false);
    CONFIG_BOOL("Debug", "AdamSystem", config_debug.show_adam_system, false);
    CONFIG_BOOL("Debug", "AdamNet", config_debug.show_adam_net, false);
    CONFIG_BOOL("Debug", "AdamPrinter", config_debug.show_adam_printer, false);
    CONFIG_BOOL("Debug", "TraceLogger", config_debug.show_trace_logger, false);
    CONFIG_BOOL("Debug", "Rewind", config_debug.show_rewind, false);

    // Trace logger
    CONFIG_BOOL("Debug", "TraceCounter", config_debug.trace_counter, true);
    CONFIG_BOOL("Debug", "TraceCycles", config_debug.trace_cycles, false);
    CONFIG_BOOL("Debug", "TraceBank", config_debug.trace_bank, true);
    CONFIG_BOOL("Debug", "TraceRegisters", config_debug.trace_registers, true);
    CONFIG_BOOL("Debug", "TraceFlags", config_debug.trace_flags, true);
    CONFIG_BOOL("Debug", "TraceBytes", config_debug.trace_bytes, true);
    CONFIG_BOOL("Debug", "TraceCpuEnabled", config_debug.trace_cpu_enabled, true);
    CONFIG_BOOL("Debug", "TraceCpu", config_debug.trace_cpu, true);
    CONFIG_BOOL("Debug", "TraceCpuIrq", config_debug.trace_cpu_irq, true);
    CONFIG_BOOL("Debug", "TraceVdp", config_debug.trace_vdp, false);
    CONFIG_BOOL("Debug", "TracePsg", config_debug.trace_psg, false);
    CONFIG_BOOL("Debug", "TraceAy8910", config_debug.trace_ay8910, false);
    CONFIG_BOOL("Debug", "TraceIo", config_debug.trace_io, false);
    CONFIG_BOOL("Debug", "TraceInput", config_debug.trace_input, false);
    CONFIG_BOOL("Debug", "TraceSgm", config_debug.trace_sgm, false);
    CONFIG_BOOL("Debug", "TraceAdam", config_debug.trace_adam, false);
    CONFIG_BOOL("Debug", "TraceMapper", config_debug.trace_mapper, false);
    CONFIG_INT_RANGE("Debug", "TraceVdpEvents", config_debug.trace_vdp_events, TRACE_VDP_EVENT_DEFAULT, 0, TRACE_VDP_EVENT_ALL);
    CONFIG_INT_RANGE("Debug", "TracePsgEvents", config_debug.trace_psg_events, TRACE_PSG_EVENT_ALL, 0, TRACE_PSG_EVENT_ALL);
    CONFIG_INT_RANGE("Debug", "TraceAy8910Events", config_debug.trace_ay8910_events, TRACE_AY8910_EVENT_ALL, 0, TRACE_AY8910_EVENT_ALL);
    CONFIG_INT_RANGE("Debug", "TraceIoEvents", config_debug.trace_io_events, TRACE_IO_EVENT_ALL, 0, TRACE_IO_EVENT_ALL);
    CONFIG_INT_RANGE("Debug", "TraceInputEvents", config_debug.trace_input_events, TRACE_INPUT_EVENT_ALL, 0, TRACE_INPUT_EVENT_ALL);
    CONFIG_INT_RANGE("Debug", "TraceSgmEvents", config_debug.trace_sgm_events, TRACE_SGM_EVENT_ALL, 0, TRACE_SGM_EVENT_ALL);
    CONFIG_INT_RANGE("Debug", "TraceAdamEvents", config_debug.trace_adam_events, TRACE_ADAM_EVENT_ALL, 0, TRACE_ADAM_EVENT_ALL);
    CONFIG_INT_RANGE("Debug", "TraceMapperEvents", config_debug.trace_mapper_events, TRACE_MAPPER_EVENT_ALL, 0, TRACE_MAPPER_EVENT_ALL);
    CONFIG_INT_RANGE("Debug", "TraceVBlankWatchAddress", config_debug.trace_vblank_watch_address, 0, 0, 0xFFFF);
    CONFIG_INT_RANGE("Debug", "TraceVBlankWatchOperation", config_debug.trace_vblank_watch_operation, 1, 0, 2);
    CONFIG_INT_RANGE("Debug", "TraceOutput", config_debug.trace_output, 0, 0, 1);
    CONFIG_INT_RANGE("Debug", "TraceCapacity", config_debug.trace_capacity, 0, 0, 4);
    CONFIG_INT_RANGE("Debug", "TraceDiskDirOption", config_debug.trace_disk_dir_option, 0, 0, 2);
    CONFIG_INT_RANGE("Debug", "TraceDiskSize", config_debug.trace_disk_size, 2, 0, 6);
    CONFIG_STRING_NOT_EMPTY("Debug", "TraceDiskPath", config_debug.trace_disk_path, config_root_path);

    // Disassembler
    CONFIG_BOOL("Debug", "DisMem", config_debug.dis_show_mem, true);
    CONFIG_BOOL("Debug", "DisSymbols", config_debug.dis_show_symbols, true);
    CONFIG_BOOL("Debug", "DisSegment", config_debug.dis_show_segment, true);
    CONFIG_BOOL("Debug", "DisBank", config_debug.dis_show_bank, true);
    CONFIG_BOOL("Debug", "DisAutoSymbols", config_debug.dis_show_auto_symbols, true);
    CONFIG_BOOL("Debug", "DisDimAutoSymbols", config_debug.dis_dim_auto_symbols, false);
    CONFIG_BOOL("Debug", "DisReplaceSymbols", config_debug.dis_replace_symbols, true);
    CONFIG_BOOL("Debug", "DisReplaceLabels", config_debug.dis_replace_labels, true);
    CONFIG_INT_RANGE("Debug", "DisSyntax", config_debug.dis_syntax, GC_Disassembler_Syntax_Gearcoleco, GC_Disassembler_Syntax_Gearcoleco, GC_Disassembler_Syntax_Count - 1);
    CONFIG_INT("Debug", "DisLookAheadCount", config_debug.dis_look_ahead_count, 20);

    // Interface
    CONFIG_INT_RANGE("Debug", "FontType", config_debug.font_type, 0, 0, 1);
    CONFIG_INT_RANGE("Debug", "FontSize", config_debug.font_size, 0, 0, 3);
    CONFIG_INT("Debug", "Scale", config_debug.scale, 2);
    CONFIG_INT("Debug", "Overscan", config_debug.overscan, 0);
    CONFIG_BOOL("Debug", "MultiViewport", config_debug.multi_viewport, false);
    CONFIG_BOOL("Debug", "SingleInstance", config_debug.single_instance, false);
    CONFIG_BOOL("Debug", "AutoDebugSettings", config_debug.auto_debug_settings, false);

    // Memory editors
    for (int i = 0; i < config_memory_editor_count; i++)
    {
        char section[32];
        snprintf(section, sizeof(section), "MemEditor_%d", i);
        CONFIG_INT(section, "BytesPerRow", config_debug.mem_editor_bytes_per_row[i], 16);
        CONFIG_INT(section, "PreviewDataType", config_debug.mem_editor_preview_data_type[i], 0);
        CONFIG_INT(section, "PreviewEndianess", config_debug.mem_editor_preview_endianess[i], 0);
        CONFIG_BOOL(section, "UppercaseHex", config_debug.mem_editor_uppercase_hex[i], true);
        CONFIG_BOOL(section, "GrayOutZeros", config_debug.mem_editor_gray_out_zeros[i], true);
    }

    //**************************************
    // Emulator
    //**************************************

    // Window and interface
    CONFIG_BOOL("Emulator", "Maximized", config_emulator.maximized, false);
    CONFIG_BOOL("Emulator", "FullScreen", config_emulator.fullscreen, false);
    CONFIG_INT("Emulator", "FullScreenMode", config_emulator.fullscreen_mode, 0);
    CONFIG_BOOL("Emulator", "AlwaysShowMenu", config_emulator.always_show_menu, false);
    CONFIG_INT_RANGE("Emulator", "Theme", config_emulator.theme, config_Theme_Dark, config_Theme_Light, config_Theme_Dark);
    CONFIG_INT("Emulator", "WindowWidth", config_emulator.window_width, 770);
    CONFIG_INT("Emulator", "WindowHeight", config_emulator.window_height, 600);
    CONFIG_BOOL("Emulator", "ShowNotifications", config_emulator.show_notifications, true);
    CONFIG_INT_RANGE("Emulator", "NotificationDuration", config_emulator.notification_duration, 4, 3, 10);
    CONFIG_BOOL("Emulator", "AllowScreenSaver", config_emulator.allow_screensaver, false);

    // Emulation
    CONFIG_INT("Emulator", "FFWD", config_emulator.ffwd_speed, 1);
    CONFIG_INT_RANGE("Emulator", "RunAhead", config_emulator.runahead, 0, 0, 3);
    CONFIG_INT_RANGE("Emulator", "SaveSlot", config_emulator.save_slot, 0, 0, 4);
    CONFIG_BOOL("Emulator", "StartPaused", config_emulator.start_paused, false);
    CONFIG_BOOL("Emulator", "PauseWhenInactive", config_emulator.pause_when_inactive, true);
    CONFIG_BOOL("Emulator", "SoftPatching", config_emulator.softpatching, true);
    CONFIG_INT("Emulator", "Mapper", config_emulator.mapper, 0);
    CONFIG_INT("Emulator", "Region", config_emulator.region, 0);
    CONFIG_INT_RANGE("Emulator", "Machine", config_emulator.machine, GC_MACHINE_AUTO, GC_MACHINE_AUTO, GC_MACHINE_ADAM);
    CONFIG_INT_RANGE("Emulator", "AdamBootMode", config_emulator.adam_boot_mode, 0, 0, 2);
    CONFIG_STRING("Emulator", "BiosPath", config_emulator.bios_path, "");
    CONFIG_STRING("Emulator", "AdamEOSPath", config_emulator.adam_eos_path, "");
    CONFIG_STRING("Emulator", "AdamSmartWriterPath", config_emulator.adam_smartwriter_path, "");
    for (int i = 0; i < config_adam_key_count; i++)
    {
        CONFIG_SCANCODE("ADAM Keyboard", config_adam_keys[i].setting,
            config_emulator.adam_keys[i], config_adam_keys[i].default_scancode);
    }
    CONFIG_BOOL("Emulator", "AdamMediaPersistence", config_emulator.adam_media_persistence, true);
    CONFIG_INT_RANGE("ADAM", "Controller1", config_emulator.adam_controller[0], config_AdamController_Gamepad, config_AdamController_None, config_AdamController_Gamepad);
    CONFIG_INT_RANGE("ADAM", "Controller2", config_emulator.adam_controller[1], config_AdamController_Gamepad, config_AdamController_None, config_AdamController_Gamepad);
    CONFIG_STRING_ARRAY("ADAM", "Disk1Recent%d", config_emulator.adam_recent_media[0], 5, "");
    CONFIG_STRING_ARRAY("ADAM", "Disk2Recent%d", config_emulator.adam_recent_media[1], 5, "");
    CONFIG_STRING_ARRAY("ADAM", "DataPack1Recent%d", config_emulator.adam_recent_media[2], 5, "");
    CONFIG_STRING_ARRAY("ADAM", "DataPack2Recent%d", config_emulator.adam_recent_media[3], 5, "");
    CONFIG_BOOL("Emulator", "AdamDisk1WriteProtected", config_emulator.adam_media_write_protected[GC_ADAM_MEDIA_DISK_1], false);
    CONFIG_BOOL("Emulator", "AdamDisk2WriteProtected", config_emulator.adam_media_write_protected[GC_ADAM_MEDIA_DISK_2], false);
    CONFIG_BOOL("Emulator", "AdamDataPack1WriteProtected", config_emulator.adam_media_write_protected[GC_ADAM_MEDIA_DATA_PACK_1], false);
    CONFIG_BOOL("Emulator", "AdamDataPack2WriteProtected", config_emulator.adam_media_write_protected[GC_ADAM_MEDIA_DATA_PACK_2], false);
    CONFIG_INT("Emulator", "Spinner", config_emulator.spinner, 0);
    CONFIG_INT("Emulator", "SpinnerSensitivity", config_emulator.spinner_sensitivity, 4);
    CONFIG_BOOL("Emulator", "AllowSharedGamepads", config_emulator.allow_shared_gamepads, false);

    // Files and paths
    CONFIG_INT("Emulator", "SaveFilesDirOption", config_emulator.savefiles_dir_option, 0);
    CONFIG_STRING_NOT_EMPTY("Emulator", "SaveFilesPath", config_emulator.savefiles_path, config_root_path);
    CONFIG_INT("Emulator", "SaveStatesDirOption", config_emulator.savestates_dir_option, 0);
    CONFIG_STRING_NOT_EMPTY("Emulator", "SaveStatesPath", config_emulator.savestates_path, config_root_path);
    CONFIG_INT("Emulator", "ScreenshotDirOption", config_emulator.screenshots_dir_option, 0);
    CONFIG_STRING_NOT_EMPTY("Emulator", "ScreenshotPath", config_emulator.screenshots_path, config_root_path);
    CONFIG_INT("Emulator", "VideoRecordingDirOption", config_emulator.video_recordings_dir_option, 0);
    CONFIG_STRING_NOT_EMPTY("Emulator", "VideoRecordingPath", config_emulator.video_recordings_path, config_root_path);
    CONFIG_STRING_ARRAY("Emulator", "RecentROM%d", config_emulator.recent_roms, config_max_recent_roms, "");

    // File dialogs
    CONFIG_STRING("FileDialogs", "ROM", config_file_dialogs.rom, "");
    CONFIG_STRING("FileDialogs", "RAM", config_file_dialogs.ram, "");
    CONFIG_STRING("FileDialogs", "States", config_file_dialogs.states, "");
    CONFIG_STRING("FileDialogs", "Screenshots", config_file_dialogs.screenshots, "");
    CONFIG_STRING("FileDialogs", "Recordings", config_file_dialogs.recordings, "");
    CONFIG_STRING("FileDialogs", "Debug", config_file_dialogs.debug, "");
    CONFIG_STRING("FileDialogs", "BIOS", config_file_dialogs.bios, "");
    CONFIG_STRING("FileDialogs", "AdamMedia", config_file_dialogs.adam_media, "");
    CONFIG_STRING("FileDialogs", "AdamPrinter", config_file_dialogs.adam_printer, "");

    // Services
    CONFIG_INT("Emulator", "MCPTCPPort", config_emulator.mcp_tcp_port, 7777);
    CONFIG_STRING_NOT_EMPTY("Emulator", "MCPHTTPAddress", config_emulator.mcp_http_address, "127.0.0.1");

    //**************************************
    // Video
    CONFIG_INT_RANGE("Video", "VideoChip", config_video.video_chip, GC_VIDEO_CHIP_AUTO, GC_VIDEO_CHIP_AUTO, GC_VIDEO_CHIP_F18A);
    //**************************************

    // Display
    CONFIG_INT("Video", "Scale", config_video.scale, 0);
    CONFIG_INT_RANGE("Video", "ScaleManual", config_video.scale_manual, 1, 1, 20);
    CONFIG_INT("Video", "AspectRatio", config_video.ratio, 1);
    CONFIG_INT("Video", "Overscan", config_video.overscan, 1);
    CONFIG_BOOL("Video", "FPS", config_video.fps, false);
    CONFIG_BOOL("Video", "SpriteLimit", config_video.sprite_limit, false);
    CONFIG_INT("Video", "Palette", config_video.palette, 0);
    CONFIG_INT_RANGE("Video", "ShaderMode", config_video.shader_mode, config_ShaderMode_PixelPerfect, config_ShaderMode_PixelPerfect, config_ShaderMode_External);

    if (operation == config_Operation_Write)
    {
        std::string preset_file = get_filename(config_video.shader_preset_path.c_str());
        CONFIG_STRING("Video", "ShaderPresetFile", preset_file, "");
    }
    else
    {
        CONFIG_STRING("Video", "ShaderPresetFile", config_video.shader_preset_path, "");
    }

    CONFIG_INT_RANGE("Video", "SyncMode", config_video.sync_mode, config_VideoSync_Fixed, config_VideoSync_Disabled, config_VideoSync_VRR);
    CONFIG_INT_RANGE("Video", "RecordingScale", config_video.recording_scale, 2, 1, 20);
    CONFIG_INT_RANGE("Video", "RecordingAspectRatio", config_video.recording_ratio, 0, 0, 4);
    CONFIG_INT_RANGE("Video", "RecordingQuality", config_video.recording_quality, 2, 0, 4);

    // Background colors
    CONFIG_FLOAT("Video", "BackgroundColorR", config_video.background_color[config_Theme_Dark][0], 0.1f);
    CONFIG_FLOAT("Video", "BackgroundColorG", config_video.background_color[config_Theme_Dark][1], 0.1f);
    CONFIG_FLOAT("Video", "BackgroundColorB", config_video.background_color[config_Theme_Dark][2], 0.1f);
    CONFIG_FLOAT("Video", "BackgroundColorDebuggerR", config_video.background_color_debugger[config_Theme_Dark][0], 0.2f);
    CONFIG_FLOAT("Video", "BackgroundColorDebuggerG", config_video.background_color_debugger[config_Theme_Dark][1], 0.2f);
    CONFIG_FLOAT("Video", "BackgroundColorDebuggerB", config_video.background_color_debugger[config_Theme_Dark][2], 0.2f);
    CONFIG_FLOAT("Video", "BackgroundColorLightR", config_video.background_color[config_Theme_Light][0], 128.0f / 255.0f);
    CONFIG_FLOAT("Video", "BackgroundColorLightG", config_video.background_color[config_Theme_Light][1], 128.0f / 255.0f);
    CONFIG_FLOAT("Video", "BackgroundColorLightB", config_video.background_color[config_Theme_Light][2], 128.0f / 255.0f);
    CONFIG_FLOAT("Video", "BackgroundColorDebuggerLightR",
                 config_video.background_color_debugger[config_Theme_Light][0],
                 233.0f / 255.0f);
    CONFIG_FLOAT("Video", "BackgroundColorDebuggerLightG",
                 config_video.background_color_debugger[config_Theme_Light][1],
                 232.0f / 255.0f);
    CONFIG_FLOAT("Video", "BackgroundColorDebuggerLightB",
                 config_video.background_color_debugger[config_Theme_Light][2],
                 230.0f / 255.0f);

    // Custom palette
    const GC_Color default_palette[16] = {
        {255, 0, 255}, {0, 0, 0}, {33, 200, 66}, {94, 220, 120},
        {84, 85, 237}, {125, 118, 252}, {212, 82, 77}, {66, 235, 245},
        {252, 85, 84}, {255, 121, 120}, {212, 193, 84}, {230, 206, 128},
        {33, 176, 59}, {201, 91, 186}, {204, 204, 204}, {255, 255, 255}
    };

    for (int i = 0; i < 16; i++)
    {
        char key[32];

        int red = config_video.color[i].red;
        snprintf(key, sizeof(key), "CustomPalette%dR", i);
        CONFIG_INT("Video", key, red, default_palette[i].red);
        config_video.color[i].red = (u8)red;

        int green = config_video.color[i].green;
        snprintf(key, sizeof(key), "CustomPalette%dG", i);
        CONFIG_INT("Video", key, green, default_palette[i].green);
        config_video.color[i].green = (u8)green;

        int blue = config_video.color[i].blue;
        snprintf(key, sizeof(key), "CustomPalette%dB", i);
        CONFIG_INT("Video", key, blue, default_palette[i].blue);
        config_video.color[i].blue = (u8)blue;
    }

    //**************************************
    // Audio
    //**************************************

    CONFIG_BOOL("Audio", "Enable", config_audio.enable, true);
    CONFIG_BOOL("Audio", "Sync", config_audio.sync, true);
    CONFIG_FLOAT_RANGE("Audio", "MasterVolume", config_audio.master_volume, 1.0f, 0.0f, 2.0f);
    CONFIG_INT("Audio", "BufferCount", config_audio.buffer_count, 3);

    //**************************************
    // Rewind
    //**************************************

    CONFIG_BOOL("Rewind", "Enabled", config_rewind.enabled, true);
    CONFIG_INT("Rewind", "BufferSeconds", config_rewind.buffer_seconds, 10);
    CONFIG_INT("Rewind", "FramesPerSnapshot", config_rewind.frames_per_snapshot, 1);
    CONFIG_FLOAT("Rewind", "Speed", config_rewind.speed, 2.0f);

    //**************************************
    // Input
    //**************************************

    const char* input_sections[2] = { "InputA", "InputB" };
    const SDL_Scancode keyboard_defaults[2][20] = {
        { SDL_SCANCODE_LEFT, SDL_SCANCODE_RIGHT, SDL_SCANCODE_UP, SDL_SCANCODE_DOWN,
          SDL_SCANCODE_A, SDL_SCANCODE_S, SDL_SCANCODE_D, SDL_SCANCODE_F,
          SDL_SCANCODE_KP_0, SDL_SCANCODE_KP_1, SDL_SCANCODE_KP_2, SDL_SCANCODE_KP_3,
          SDL_SCANCODE_KP_4, SDL_SCANCODE_KP_5, SDL_SCANCODE_KP_6, SDL_SCANCODE_KP_7,
          SDL_SCANCODE_KP_8, SDL_SCANCODE_KP_9, SDL_SCANCODE_KP_MULTIPLY, SDL_SCANCODE_KP_DIVIDE },
        { SDL_SCANCODE_J, SDL_SCANCODE_L, SDL_SCANCODE_I, SDL_SCANCODE_K,
          SDL_SCANCODE_G, SDL_SCANCODE_H, SDL_SCANCODE_J, SDL_SCANCODE_K,
          SDL_SCANCODE_NONUSBACKSLASH, SDL_SCANCODE_Z, SDL_SCANCODE_X, SDL_SCANCODE_C,
          SDL_SCANCODE_V, SDL_SCANCODE_B, SDL_SCANCODE_N, SDL_SCANCODE_M,
          SDL_SCANCODE_COMMA, SDL_SCANCODE_PERIOD, SDL_SCANCODE_SLASH, SDL_SCANCODE_RSHIFT }
    };

    for (int i = 0; i < 2; i++)
    {
        const char* section = input_sections[i];
        const SDL_Scancode* defaults = keyboard_defaults[i];

        // Keyboard
        CONFIG_SCANCODE(section, "KeyLeft", config_input[i].key_left, defaults[0]);
        CONFIG_SCANCODE(section, "KeyRight", config_input[i].key_right, defaults[1]);
        CONFIG_SCANCODE(section, "KeyUp", config_input[i].key_up, defaults[2]);
        CONFIG_SCANCODE(section, "KeyDown", config_input[i].key_down, defaults[3]);
        CONFIG_SCANCODE(section, "KeyLeftButton", config_input[i].key_left_button, defaults[4]);
        CONFIG_SCANCODE(section, "KeyRightButton", config_input[i].key_right_button, defaults[5]);
        CONFIG_SCANCODE(section, "KeyBlue", config_input[i].key_blue, defaults[6]);
        CONFIG_SCANCODE(section, "KeyPurple", config_input[i].key_purple, defaults[7]);
        CONFIG_SCANCODE(section, "Key0", config_input[i].key_0, defaults[8]);
        CONFIG_SCANCODE(section, "Key1", config_input[i].key_1, defaults[9]);
        CONFIG_SCANCODE(section, "Key2", config_input[i].key_2, defaults[10]);
        CONFIG_SCANCODE(section, "Key3", config_input[i].key_3, defaults[11]);
        CONFIG_SCANCODE(section, "Key4", config_input[i].key_4, defaults[12]);
        CONFIG_SCANCODE(section, "Key5", config_input[i].key_5, defaults[13]);
        CONFIG_SCANCODE(section, "Key6", config_input[i].key_6, defaults[14]);
        CONFIG_SCANCODE(section, "Key7", config_input[i].key_7, defaults[15]);
        CONFIG_SCANCODE(section, "Key8", config_input[i].key_8, defaults[16]);
        CONFIG_SCANCODE(section, "Key9", config_input[i].key_9, defaults[17]);
        CONFIG_SCANCODE(section, "KeyAsterisk", config_input[i].key_asterisk, defaults[18]);
        CONFIG_SCANCODE(section, "KeyHash", config_input[i].key_hash, defaults[19]);

        // Gamepad
        CONFIG_BOOL(section, "AllowUpDown", config_input[i].allow_up_down, false);
        CONFIG_BOOL(section, "Gamepad", config_input[i].gamepad, true);
        CONFIG_INT_RANGE(section, "GamepadDirectional", config_input[i].gamepad_directional, 0, 0, 2);
        CONFIG_BOOL(section, "GamepadInvertX", config_input[i].gamepad_invert_x_axis, false);
        CONFIG_BOOL(section, "GamepadInvertY", config_input[i].gamepad_invert_y_axis, false);
        CONFIG_INT(section, "GamepadLeft", config_input[i].gamepad_left_button, SDL_GAMEPAD_BUTTON_SOUTH);
        CONFIG_INT(section, "GamepadRight", config_input[i].gamepad_right_button, SDL_GAMEPAD_BUTTON_EAST);
        CONFIG_INT(section, "GamepadBlue", config_input[i].gamepad_blue, SDL_GAMEPAD_BUTTON_GUIDE);
        CONFIG_INT(section, "GamepadPurple", config_input[i].gamepad_purple, SDL_GAMEPAD_BUTTON_GUIDE);
        CONFIG_INT(section, "GamepadX", config_input[i].gamepad_x_axis, SDL_GAMEPAD_AXIS_LEFTX);
        CONFIG_INT(section, "GamepadY", config_input[i].gamepad_y_axis, SDL_GAMEPAD_AXIS_LEFTY);
        CONFIG_INT(section, "Gamepad1", config_input[i].gamepad_1, SDL_GAMEPAD_BUTTON_WEST);
        CONFIG_INT(section, "Gamepad2", config_input[i].gamepad_2, SDL_GAMEPAD_BUTTON_NORTH);
        CONFIG_INT(section, "Gamepad3", config_input[i].gamepad_3, SDL_GAMEPAD_BUTTON_RIGHT_SHOULDER);
        CONFIG_INT(section, "Gamepad4", config_input[i].gamepad_4, SDL_GAMEPAD_BUTTON_LEFT_SHOULDER);
        CONFIG_INT(section, "Gamepad5", config_input[i].gamepad_5, SDL_GAMEPAD_BUTTON_RIGHT_STICK);
        CONFIG_INT(section, "Gamepad6", config_input[i].gamepad_6, SDL_GAMEPAD_BUTTON_LEFT_STICK);
        CONFIG_INT(section, "Gamepad7", config_input[i].gamepad_7, SDL_GAMEPAD_BUTTON_GUIDE);
        CONFIG_INT(section, "Gamepad8", config_input[i].gamepad_8, SDL_GAMEPAD_BUTTON_GUIDE);
        CONFIG_INT(section, "Gamepad9", config_input[i].gamepad_9, SDL_GAMEPAD_BUTTON_GUIDE);
        CONFIG_INT(section, "Gamepad0", config_input[i].gamepad_0, SDL_GAMEPAD_BUTTON_GUIDE);
        CONFIG_INT(section, "GamepadAsterisk", config_input[i].gamepad_asterisk, SDL_GAMEPAD_BUTTON_START);
        CONFIG_INT(section, "GamepadHash", config_input[i].gamepad_hash, SDL_GAMEPAD_BUTTON_BACK);
    }

    // Gamepad shortcuts
    for (int i = 0; i < 2; i++)
    {
        char section[32];
        snprintf(section, sizeof(section), "InputGamepadShortcuts%d", i + 1);

        for (int j = 0; j < config_HotkeyIndex_COUNT; j++)
        {
            char key[64];
            snprintf(key, sizeof(key), "Shortcut%s", hotkey_definitions[j].name);
            CONFIG_INT(section, key, config_input_gamepad_shortcuts[i].gamepad_shortcuts[j], SDL_GAMEPAD_BUTTON_INVALID);
        }
    }

    // Hotkeys
    for (int i = 0; i < config_HotkeyIndex_COUNT; i++)
        CONFIG_HOTKEY(hotkey_definitions[i].name, config_hotkeys[i], hotkey_definitions[i].key, hotkeys_default_mod(i));
}

//**************************************
// Emulator-specific behavior
//**************************************

static void before_read(int file_version);
static void after_read(int file_version);
static void before_write(void);
static void after_write(void);
static void before_defaults(void);
static void after_defaults(void);
static void normalize(void);
static void migrate(int file_version);
static void migrate_hotkeys(void);
static void sync_shader_preset_parameter_defaults(void);

static void before_read(int file_version)
{
    migrate(file_version);
}

static void after_read(int file_version)
{
    UNUSED(file_version);
    sync_shader_preset_parameter_defaults();
}

static void before_write(void)
{
    if (config_emulator.ffwd)
        config_audio.sync = true;
}

static void after_write(void)
{
    sync_shader_preset_parameter_defaults();
}

static void before_defaults(void)
{
}

static void after_defaults(void)
{
    config_emulator.paused = false;
    config_emulator.ffwd = false;
    config_emulator.show_info = false;
}

static void normalize(void)
{
#if defined(GEARCOLECO_DISABLE_DISASSEMBLER)
    config_debug.debug = false;
#endif
#if !defined(_WIN32)
    if (config_video.sync_mode == config_VideoSync_VRR)
        config_video.sync_mode = config_VideoSync_Fixed;
#endif
}

static void migrate(int file_version)
{
    int sync_mode = -1;
    std::string stored;

    if (file_version < 7)
    {
        float red = 0.0f;
        float green = 0.0f;
        float blue = 0.0f;
        bool old_default = get_setting("Video", "BackgroundColorDebuggerLightR", &stored) &&
                           parse_float_string(stored, &red) &&
                           get_setting("Video", "BackgroundColorDebuggerLightG", &stored) &&
                           parse_float_string(stored, &green) &&
                           get_setting("Video", "BackgroundColorDebuggerLightB", &stored) &&
                           parse_float_string(stored, &blue) &&
                           std::fabs(red - (160.0f / 255.0f)) < 0.005f &&
                           std::fabs(green - (160.0f / 255.0f)) < 0.005f &&
                           std::fabs(blue - (160.0f / 255.0f)) < 0.005f;

        if (old_default)
        {
            write_float("Video", "BackgroundColorDebuggerLightR", 233.0f / 255.0f);
            write_float("Video", "BackgroundColorDebuggerLightG", 232.0f / 255.0f);
            write_float("Video", "BackgroundColorDebuggerLightB", 230.0f / 255.0f);
        }
    }
    bool valid_sync_mode = get_setting("Video", "SyncMode", &stored) &&
        parse_int_string(stored, &sync_mode) && sync_mode >= config_VideoSync_Disabled &&
        sync_mode <= config_VideoSync_VRR;

    if (file_version < 4 || !valid_sync_mode)
    {
        bool sync = read_bool("Video", "Sync", true);
        bool vrr = read_bool("Video", "VRR", false);
        sync_mode = sync ? (vrr ? config_VideoSync_VRR : config_VideoSync_Fixed) : config_VideoSync_Disabled;
        write_int("Video", "SyncMode", sync_mode);
    }

    if (file_version < 5)
    {
        bool cpu = read_bool("Debug", "TraceCpu", true);
        bool cpu_irq = read_bool("Debug", "TraceCpuIrq", true);
        bool vdp_write = read_bool("Debug", "TraceVdpWrite", true);
        bool vdp_status = read_bool("Debug", "TraceVdpStatus", true);
        bool psg = read_bool("Debug", "TracePsg", true);
        bool ay8910 = read_bool("Debug", "TraceAy8910", true);
        bool io = read_bool("Debug", "TraceIoPort", true);
        bool sgm = read_bool("Debug", "TraceSgm", true);
        bool old_default = cpu && cpu_irq && vdp_write && vdp_status && psg && ay8910 && io && sgm;

        write_bool("Debug", "TraceCpuEnabled", cpu || cpu_irq);
        write_bool("Debug", "TraceCpu", cpu);
        write_bool("Debug", "TraceCpuIrq", cpu_irq);
        write_bool("Debug", "TraceVdp", !old_default && (vdp_write || vdp_status));
        write_bool("Debug", "TracePsg", !old_default && psg);
        write_bool("Debug", "TraceAy8910", !old_default && ay8910);
        write_bool("Debug", "TraceIo", !old_default && io);
        write_bool("Debug", "TraceInput", false);
        write_bool("Debug", "TraceSgm", !old_default && sgm);
        write_bool("Debug", "TraceMapper", false);
        write_int("Debug", "TraceVdpEvents", (vdp_write ? TRACE_VDP_EVENT_REGISTERS : 0) |
            (vdp_status ? TRACE_VDP_EVENT_INTERRUPTS | TRACE_VDP_EVENT_STATUS |
             TRACE_VDP_EVENT_SPRITES | TRACE_VDP_EVENT_TIMING : 0));
        write_int("Debug", "TracePsgEvents", TRACE_PSG_EVENT_ALL);
        write_int("Debug", "TraceAy8910Events", TRACE_AY8910_EVENT_ALL);
        write_int("Debug", "TraceIoEvents", TRACE_IO_EVENT_ALL);
        write_int("Debug", "TraceInputEvents", TRACE_INPUT_EVENT_ALL);
        write_int("Debug", "TraceSgmEvents", TRACE_SGM_EVENT_ALL);
        write_int("Debug", "TraceMapperEvents", TRACE_MAPPER_EVENT_ALL);
        write_bool("Debug", "TraceCycles", false);
    }

    if (file_version < 6)
    {
        int old_video_chip = read_int("Video", "VideoChip", 0);
        write_int("Video", "VideoChip", old_video_chip == 1 ? GC_VIDEO_CHIP_F18A : GC_VIDEO_CHIP_AUTO);
    }

    int scale = 0;
    if (get_setting("Video", "Scale", &stored) && parse_int_string(stored, &scale) && scale > 3)
        write_int("Video", "Scale", scale - 2);

    if (file_version < 9)
    {
        if (get_setting("Emulator", "LastOpenPath", &stored))
            write_string("FileDialogs", "ROM", stored);

        config_ini_data["Emulator"].remove("LastOpenPath");
    }

    if (file_version < 10)
        migrate_hotkeys();
}

static void migrate_hotkeys(void)
{
    struct migrate_Hotkey
    {
        const char* name;
        int key;
        int mod;
    };

    static const migrate_Hotkey old_defaults[] =
    {
        { "OpenROM", SDL_SCANCODE_O, SDL_KMOD_CTRL }, { "ReloadROM", SDL_SCANCODE_D, SDL_KMOD_CTRL },
        { "Quit", SDL_SCANCODE_Q, SDL_KMOD_CTRL }, { "Reset", SDL_SCANCODE_R, SDL_KMOD_CTRL },
        { "Pause", SDL_SCANCODE_P, SDL_KMOD_CTRL }, { "FFWD", SDL_SCANCODE_F, SDL_KMOD_CTRL },
        { "Rewind", SDL_SCANCODE_BACKSPACE, SDL_KMOD_NONE }, { "SaveState", SDL_SCANCODE_S, SDL_KMOD_CTRL },
        { "LoadState", SDL_SCANCODE_L, SDL_KMOD_CTRL }, { "Screenshot", SDL_SCANCODE_X, SDL_KMOD_CTRL },
        { "Fullscreen", SDL_SCANCODE_F12, SDL_KMOD_NONE }, { "ShowMainMenu", SDL_SCANCODE_M, SDL_KMOD_CTRL },
        { "SelectSlot1", SDL_SCANCODE_1, SDL_KMOD_CTRL }, { "SelectSlot2", SDL_SCANCODE_2, SDL_KMOD_CTRL },
        { "SelectSlot3", SDL_SCANCODE_3, SDL_KMOD_CTRL }, { "SelectSlot4", SDL_SCANCODE_4, SDL_KMOD_CTRL },
        { "SelectSlot5", SDL_SCANCODE_5, SDL_KMOD_CTRL }, { "Mute", SDL_SCANCODE_U, SDL_KMOD_CTRL },
        { "VideoRecording", SDL_SCANCODE_R, SDL_KMOD_CTRL | SDL_KMOD_SHIFT }
    };

    static const char* const old_shortcuts[] =
    {
        "OpenROM", "ReloadROM", "Quit", "Reset", "Pause", "FFWD", "SaveState", "LoadState", "Screenshot", "Fullscreen",
        "GameFocus", "ShowMainMenu", "DebugStepInto", "DebugStepOver", "DebugStepOut", "DebugStepFrame",
        "DebugContinue", "DebugBreak", "DebugRunToCursor", "DebugBreakpoint", "DebugGoBack", "SelectSlot1",
        "SelectSlot2", "SelectSlot3", "SelectSlot4", "SelectSlot5", "Rewind", "Mute", "VideoRecording",
        "KeyboardMapper", "KeyMapping"
    };

    char scancode_key[64];
    char mod_key[64];

    for (size_t i = 0; i < sizeof(old_defaults) / sizeof(old_defaults[0]); i++)
    {
        snprintf(scancode_key, sizeof(scancode_key), "%sScancode", old_defaults[i].name);
        snprintf(mod_key, sizeof(mod_key), "%sMod", old_defaults[i].name);

        if ((read_int("Hotkeys", scancode_key, old_defaults[i].key) == old_defaults[i].key) &&
            (read_int("Hotkeys", mod_key, old_defaults[i].mod) == old_defaults[i].mod))
        {
            config_ini_data["Hotkeys"].remove(scancode_key);
            config_ini_data["Hotkeys"].remove(mod_key);
        }
    }

    int capture_key = read_int("Hotkeys", "CaptureMouseScancode", SDL_SCANCODE_F1);
    int capture_mod = read_int("Hotkeys", "CaptureMouseMod", SDL_KMOD_NONE);

    if ((capture_key != SDL_SCANCODE_UNKNOWN) && ((capture_key != SDL_SCANCODE_F1) || (capture_mod != SDL_KMOD_NONE)))
    {
        write_int("Hotkeys", "GameFocusScancode", capture_key);
        write_int("Hotkeys", "GameFocusMod", capture_mod);
    }

    config_ini_data["Hotkeys"].remove("CaptureMouseScancode");
    config_ini_data["Hotkeys"].remove("CaptureMouseMod");

    for (int i = 0; i < 2; i++)
    {
        char section[32];
        snprintf(section, sizeof(section), "InputGamepadShortcuts%d", i + 1);

        for (size_t j = 0; j < sizeof(old_shortcuts) / sizeof(old_shortcuts[0]); j++)
        {
            char old_key[32];
            snprintf(old_key, sizeof(old_key), "Shortcut%d", (int)j);
            std::string stored;

            if (!get_setting(section, old_key, &stored))
                continue;

            config_ini_data[section].remove(old_key);

            char new_key[64];
            snprintf(new_key, sizeof(new_key), "Shortcut%s", old_shortcuts[j]);
            write_int(section, new_key, atoi(stored.c_str()));
        }
    }
}

static void sync_shader_preset_parameter_defaults(void)
{
    static ShaderPreset preset;
    int preset_count = shader_preset_get_bundled_count();

    for (int i = 0; i < preset_count; i++)
    {
        const ShaderPresetInfo* info = shader_preset_get_bundled(i);
        char error[512];
        if (!info || !shader_preset_load(info->path, &preset, error, sizeof(error)))
            continue;

        char preset_file[SHADER_PRESET_MAX_PATH];
        if (!shader_preset_get_config_path(preset.preset_path, preset_file, sizeof(preset_file)))
            continue;

        std::string section = shader_preset_section_name(preset_file);
        int variant = preset.default_variant;

        if (preset.variant_count > 0)
        {
            if (config_ini_data[section].has("Variant"))
            {
                int index = shader_preset_find_variant(&preset, config_ini_data[section]["Variant"].c_str());
                if (index >= 0)
                    variant = index;
            }
            else
            {
                write_string(section.c_str(), "Variant", preset.variants[variant].name);
            }
        }

        for (int j = 0; j < preset.parameter_count; j++)
        {
            ShaderPresetParameter* parameter = &preset.parameters[j];
            if (config_ini_data[section].has(parameter->name))
                continue;

            write_shader_float(section.c_str(), parameter->name, shader_preset_get_variant_value(&preset, variant, j));
        }
    }
}
