/*
 * Gearcoleco - ColecoVision Emulator
 * Copyright (C) 2021  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#ifndef OGL_SHADER_CHAIN_H
#define OGL_SHADER_CHAIN_H

#include <stdint.h>
#include "shader_preset.h"

#ifdef OGL_SHADER_CHAIN_IMPORT
    #define EXTERN
#else
    #define EXTERN extern
#endif

struct OglShaderChainPassSize
{
    int source_width;
    int source_height;
    int previous_width;
    int previous_height;
    int viewport_width;
    int viewport_height;
};

struct OglShaderChainUniforms
{
    int source_width;
    int source_height;
    int input_width;
    int input_height;
    int output_width;
    int output_height;
    int viewport_width;
    int viewport_height;
    float original_aspect;
    float framebuffer_scale;
    float background_color[3];
};

struct OglShaderChainFrameInfo
{
    int frame_direction;
    float original_fps;
    float pixel_clock;
    float line_rate;
    float source_lines;
    float chroma_origin;
    float chroma_texel_cycles;
    float chroma_line_cycles;
    float chroma_frame_cycles;
    float active_region[4];
    float border_color[4];
    int system_type;
    int video_mode;
    int rotation;
    int interlaced;
    int field_parity;
    int display_enabled;
    int core_flags;
};

enum OglShaderChainCoreFlags
{
    OglShaderChainCoreFlag_ColorCorrection = 1,
    OglShaderChainCoreFlag_LowPass = 2,
    OglShaderChainCoreFlag_Composite = 4
};

struct OglShaderChainSourceTexture
{
    int width;
    int height;
    const void* pixels;
    bool filter_linear;
};

struct OglShaderChainFramebufferTexture
{
    int width;
    int height;
    bool filter_linear;
    bool float_framebuffer;
};

EXTERN bool ogl_shader_chain_init(const char* framebuffer_name);
EXTERN void ogl_shader_chain_destroy(void);
EXTERN bool ogl_shader_chain_is_initialized(void);

EXTERN bool ogl_shader_chain_update_source_texture(const OglShaderChainSourceTexture* texture);
EXTERN bool ogl_shader_chain_resize_pass_texture(const OglShaderChainFramebufferTexture* texture);

EXTERN bool ogl_shader_chain_load_preset(const char* path);
EXTERN void ogl_shader_chain_unload_preset(void);
EXTERN bool ogl_shader_chain_has_preset(void);
EXTERN uint32_t ogl_shader_chain_get_preset_pass_program(int index);
EXTERN const char* ogl_shader_chain_get_preset_name(void);
EXTERN const char* ogl_shader_chain_get_preset_path(void);
EXTERN const char* ogl_shader_chain_get_last_error(void);
EXTERN bool ogl_shader_chain_get_preset_filter_linear(void);
EXTERN int ogl_shader_chain_get_preset_pass_count(void);
EXTERN bool ogl_shader_chain_get_preset_pass_filter_linear(int index);
EXTERN bool ogl_shader_chain_get_preset_pass_float_framebuffer(int index);
EXTERN bool ogl_shader_chain_get_preset_pass_uses_history(int index);
EXTERN bool ogl_shader_chain_preset_uses_feedback(void);
EXTERN void ogl_shader_chain_get_preset_pass_output_size(int index, const OglShaderChainPassSize* pass_size, int* width, int* height);
EXTERN int ogl_shader_chain_get_parameter_count(void);
EXTERN const ShaderPresetParameter* ogl_shader_chain_get_parameter(int index);
EXTERN bool ogl_shader_chain_set_parameter(int index, float value);
EXTERN bool ogl_shader_chain_restore_default_parameters(void);
EXTERN int ogl_shader_chain_get_variant_count(void);
EXTERN const char* ogl_shader_chain_get_variant_name(int index);
EXTERN int ogl_shader_chain_get_variant(void);
EXTERN bool ogl_shader_chain_set_variant(int index);
EXTERN int ogl_shader_chain_find_variant(const char* name);
EXTERN void ogl_shader_chain_reset_frame_info(OglShaderChainFrameInfo* info, int source_width, int source_height);
EXTERN void ogl_shader_chain_begin_frame(const OglShaderChainFrameInfo* info, int advanced_frames);
EXTERN bool ogl_shader_chain_update_line_clock_texture(const float* clocks, int count);
EXTERN bool ogl_shader_chain_update_index_texture(const uint8_t* indices, int width, int height);
EXTERN void ogl_shader_chain_apply_preset_uniforms(int index, const OglShaderChainUniforms* uniforms);
EXTERN void ogl_shader_chain_bind_preset_textures(int index, uint32_t input_texture);

EXTERN uint32_t ogl_shader_chain_get_source_texture(void);
EXTERN uint32_t ogl_shader_chain_get_pass_texture(void);
EXTERN uint32_t ogl_shader_chain_get_pass_framebuffer(void);
EXTERN uint32_t ogl_shader_chain_get_feedback_texture(void);
EXTERN uint32_t ogl_shader_chain_get_feedback_framebuffer(void);
EXTERN bool ogl_shader_chain_resize_intermediate_texture(int index, const OglShaderChainFramebufferTexture* texture);
EXTERN uint32_t ogl_shader_chain_get_intermediate_texture(int index);
EXTERN uint32_t ogl_shader_chain_get_intermediate_framebuffer(int index);
EXTERN uint32_t ogl_shader_chain_get_pass_history_texture(int pass_index, int history_index);
EXTERN int ogl_shader_chain_get_pass_width(void);
EXTERN int ogl_shader_chain_get_pass_height(void);

#undef OGL_SHADER_CHAIN_IMPORT
#undef EXTERN

#endif /* OGL_SHADER_CHAIN_H */