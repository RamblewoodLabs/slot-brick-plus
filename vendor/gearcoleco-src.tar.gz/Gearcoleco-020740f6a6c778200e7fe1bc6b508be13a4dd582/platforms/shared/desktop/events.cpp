/*
 * Gearcoleco - ColecoVision Emulator
 * Copyright (C) 2021  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#include <SDL3/SDL.h>
#include "gearcoleco.h"
#include "config.h"
#include "gui.h"
#include "emu.h"
#include "application.h"
#include "gamepad.h"
#include "KeyMap.h"

#define EVENTS_IMPORT
#include "events.h"

static bool input_updated = false;

struct KeyState
{
    GC_Keys key;
    bool pressed;
};

static KeyState input_last_state[GC_MAX_GAMEPADS][20] = { };
static bool input_initialized = false;
static bool roller_mouse_buttons[2] = { };
static float spinner_remainder[2] = { };
static bool adam_scancode_down[SDL_SCANCODE_COUNT] = { };
static bool adam_controller_keys[SDL_SCANCODE_COUNT] = { };

static void input_force_key(int controller, int index, GC_Keys key, bool pressed);
static void input_poll_controller(int controller);
static void input_filter_opposing_directions(int controller, bool* left, bool* right, bool* up, bool* down);
static void input_send_key(int controller, int index, GC_Keys key, bool pressed);
static void send_adam_key(SDL_Scancode scancode, bool pressed);
static bool adam_keyboard_captures_event(const SDL_Event* event);
static bool adam_controller_uses_key(SDL_Scancode scancode);
static int spinner_movement(int spinner, float movement);

void events_handle_emu_event(const SDL_Event* event, bool shortcut_consumed)
{
    if ((emu_get_machine() == GC_MACHINE_ADAM) && ((event->type == SDL_EVENT_KEY_DOWN) || (event->type == SDL_EVENT_KEY_UP)))
    {
        // Release keys already held by ADAM even when a menu has just taken focus
        SDL_Scancode scancode = event->key.scancode;

        if (scancode <= SDL_SCANCODE_UNKNOWN || scancode >= SDL_SCANCODE_COUNT)
            return;

        if (event->type == SDL_EVENT_KEY_UP)
        {
            adam_controller_keys[scancode] = false;
            send_adam_key(scancode, false);
        }
        else if (adam_keyboard_captures_event(event) && !shortcut_consumed && (event->key.repeat == 0))
        {
            adam_controller_keys[scancode] = true;
            if (!adam_controller_uses_key(scancode))
                send_adam_key(scancode, true);
        }

        return;
    }

    if ((gui_in_use || shortcut_consumed || emu_key_mapper_is_open()) && (event->type != SDL_EVENT_MOUSE_BUTTON_UP))
        return;

    switch (event->type)
    {
        case SDL_EVENT_MOUSE_MOTION:
        {
            if (config_emulator.spinner > 0)
            {
                int sen = config_emulator.spinner_sensitivity - 1;
                if (sen < 0)
                    sen = 0;
                float senf = (float)(sen / 2.0f) + 1.0f;

                switch (config_emulator.spinner)
                {
                    case 1: // SAC
                    {
                        if (event->motion.xrel != 0.0f)
                        {
                            int movement = spinner_movement(0, -(event->motion.xrel) * senf);
                            emu_spinner1(movement);
                        }
                        break;
                    }
                    case 2: // Wheel
                    {
                        if (event->motion.xrel != 0.0f)
                        {
                            int movement = spinner_movement(0, event->motion.xrel * senf);
                            emu_spinner1(movement);
                        }
                        break;
                    }
                    case 3: // Roller
                    {
                        if (event->motion.xrel != 0.0f)
                        {
                            int movement = spinner_movement(0, event->motion.xrel * senf);
                            emu_spinner1(movement);
                        }
                        if (event->motion.yrel != 0.0f)
                        {
                            int movement = spinner_movement(1, event->motion.yrel * senf);
                            emu_spinner2(movement);
                        }
                        break;
                    }
                    default:
                        break;
                }
            }
            break;
        }
        case SDL_EVENT_MOUSE_WHEEL:
        {
            // Mouse wheel only used for SAC mode (spinner2)
            if (config_emulator.spinner == 1 && (event->wheel.y != 0.0f))
            {
                int sen = (config_emulator.spinner_sensitivity - 1) * 20;
                if (sen < 0)
                    sen = 0;
                float senf = (float)(sen / 2.0f) + 1.0f;
                int movement = spinner_movement(1, event->wheel.y * senf);
                emu_spinner2(movement);
            }
            break;
        }
        case SDL_EVENT_MOUSE_BUTTON_DOWN:
        {
            // Roller mouse buttons
            if ((config_emulator.spinner == 3) && !config_debug.debug && !gui_main_menu_hovered)
            {
                if (event->button.button == SDL_BUTTON_LEFT)
                    roller_mouse_buttons[0] = true;
                else if (event->button.button == SDL_BUTTON_RIGHT)
                    roller_mouse_buttons[1] = true;
            }
            break;
        }
        case SDL_EVENT_MOUSE_BUTTON_UP:
        {
            // Roller mouse buttons
            if (event->button.button == SDL_BUTTON_LEFT)
                roller_mouse_buttons[0] = false;
            else if (event->button.button == SDL_BUTTON_RIGHT)
                roller_mouse_buttons[1] = false;
            break;
        }
    }
}

void events_emu(void)
{
    if (input_updated || gui_in_use)
        return;
    input_updated = true;

    SDL_PumpEvents();

    for (int controller = 0; controller < 2; controller++)
    {
        input_poll_controller(controller);
        gamepad_check_shortcuts(controller);
    }
}

void events_sync_input(void)
{
    events_release_adam_keys();
    SDL_PumpEvents();

    if (!input_initialized)
    {
        input_initialized = true;
        memset(input_last_state, 0, sizeof(input_last_state));
    }

    static const GC_Keys keys[20] = {
        Key_Left, Key_Right, Key_Up, Key_Down,
        Key_Left_Button, Key_Right_Button, Key_Blue, Key_Purple,
        Keypad_0, Keypad_1, Keypad_2, Keypad_3,
        Keypad_4, Keypad_5, Keypad_6, Keypad_7,
        Keypad_8, Keypad_9, Keypad_Asterisk, Keypad_Hash
    };

    for (int controller = 0; controller < 2; controller++)
    {
        for (int i = 0; i < 20; i++)
            input_force_key(controller, i, keys[i], false);

        input_poll_controller(controller);
    }
}

void events_release_mouse(void)
{
    memset(roller_mouse_buttons, 0, sizeof(roller_mouse_buttons));
    memset(spinner_remainder, 0, sizeof(spinner_remainder));
}

void events_release_adam_keys(void)
{
    memset(adam_scancode_down, 0, sizeof(adam_scancode_down));
    memset(adam_controller_keys, 0, sizeof(adam_controller_keys));

    emu_adam_release_all_host_keys();
    emu_adam_release_all_keys();

    if (emu_get_machine() == GC_MACHINE_ADAM)
    {
        for (int controller = 0; controller < 2; controller++)
        {
            if (config_emulator.adam_controller[controller] != config_AdamController_Keyboard)
                continue;

            for (int i = 0; i < 20; i++)
            {
                if (input_last_state[controller][i].pressed)
                    input_force_key(controller, i, input_last_state[controller][i].key, false);
            }
        }
    }
}

bool events_is_adam_keyboard_active(void)
{
    return gui_main_window_focused && !gui_in_use && !gui_dialog_in_use && !emu_is_empty() && (emu_get_machine() == GC_MACHINE_ADAM);
}

bool events_is_adam_keyboard_captured(void)
{
    return config_debug.debug && events_is_adam_keyboard_active();
}

static bool adam_keyboard_captures_event(const SDL_Event* event)
{
    if (!events_is_adam_keyboard_active())
        return false;

    return (gui_main_window_sdl_window_id == 0) || (event->key.windowID == gui_main_window_sdl_window_id);
}

void events_reset_input(void)
{
    input_updated = false;
}

bool events_input_updated(void)
{
    return input_updated;
}

static void input_force_key(int controller, int index, GC_Keys key, bool pressed)
{
    input_last_state[controller][index].key = key;
    input_last_state[controller][index].pressed = pressed;

    if (pressed)
        emu_key_pressed((GC_Controllers)controller, key);
    else
        emu_key_released((GC_Controllers)controller, key);
}

static void input_send_key(int controller, int index, GC_Keys key, bool pressed)
{
    if (pressed != input_last_state[controller][index].pressed)
    {
        input_force_key(controller, index, key, pressed);
    }
}

static void input_filter_opposing_directions(int controller, bool* left, bool* right, bool* up, bool* down)
{
    if (config_input[controller].allow_up_down)
        return;

    if (*up && *down)
    {
        if (input_last_state[controller][2].pressed)
            *down = false;
        else if (input_last_state[controller][3].pressed)
            *up = false;
        else
            *down = false;
    }

    if (*left && *right)
    {
        if (input_last_state[controller][0].pressed)
            *right = false;
        else if (input_last_state[controller][1].pressed)
            *left = false;
        else
            *right = false;
    }
}

static bool adam_controller_uses_key(SDL_Scancode scancode)
{
    for (int controller = 0; controller < 2; controller++)
    {
        if (config_emulator.adam_controller[controller] != config_AdamController_Keyboard)
            continue;

        const config_Input* input = &config_input[controller];

        const SDL_Scancode keys[] =
        {
            input->key_left, input->key_right, input->key_up, input->key_down,
            input->key_left_button, input->key_right_button, input->key_blue, input->key_purple,
            input->key_0, input->key_1, input->key_2, input->key_3, input->key_4,
            input->key_5, input->key_6, input->key_7, input->key_8, input->key_9,
            input->key_asterisk, input->key_hash
        };

        for (int i = 0; i < 20; i++)
        {
            if (keys[i] == scancode)
                return true;
        }
    }

    return false;
}

static void input_poll_controller(int controller)
{
    if (controller < 0 || controller >= 2)
        return;

    if (!input_initialized)
    {
        input_initialized = true;
        memset(input_last_state, 0, sizeof(input_last_state));
    }

    SDL_Keymod mods = SDL_GetModState();
    bool adam = (emu_get_machine() == GC_MACHINE_ADAM) && !emu_is_empty();

    if ((mods & SDL_KMOD_CTRL) && !adam)
        return;

    const bool* keyboard_state = adam ? adam_controller_keys : SDL_GetKeyboardState(NULL);

    bool keyboard = !adam || config_emulator.adam_controller[controller] == config_AdamController_Keyboard;

    SDL_Gamepad* gamepad_ctrl = gamepad_controller[controller];

    bool gp = IsValidPointer(gamepad_ctrl) && (adam ? config_emulator.adam_controller[controller] == config_AdamController_Gamepad : config_input[controller].gamepad);

    struct { SDL_Scancode key; GC_Keys gc_key; int gp_btn_field; } button_map[] = {
        { config_input[controller].key_left_button, Key_Left_Button, config_input[controller].gamepad_left_button },
        { config_input[controller].key_right_button, Key_Right_Button, config_input[controller].gamepad_right_button },
        { config_input[controller].key_blue, Key_Blue, config_input[controller].gamepad_blue },
        { config_input[controller].key_purple, Key_Purple, config_input[controller].gamepad_purple },
        { config_input[controller].key_0, Keypad_0, config_input[controller].gamepad_0 },
        { config_input[controller].key_1, Keypad_1, config_input[controller].gamepad_1 },
        { config_input[controller].key_2, Keypad_2, config_input[controller].gamepad_2 },
        { config_input[controller].key_3, Keypad_3, config_input[controller].gamepad_3 },
        { config_input[controller].key_4, Keypad_4, config_input[controller].gamepad_4 },
        { config_input[controller].key_5, Keypad_5, config_input[controller].gamepad_5 },
        { config_input[controller].key_6, Keypad_6, config_input[controller].gamepad_6 },
        { config_input[controller].key_7, Keypad_7, config_input[controller].gamepad_7 },
        { config_input[controller].key_8, Keypad_8, config_input[controller].gamepad_8 },
        { config_input[controller].key_9, Keypad_9, config_input[controller].gamepad_9 },
        { config_input[controller].key_asterisk, Keypad_Asterisk, config_input[controller].gamepad_asterisk },
        { config_input[controller].key_hash, Keypad_Hash, config_input[controller].gamepad_hash },
    };

    // Directional keys (index 0-3)
    bool dir_left = keyboard && keyboard_state[config_input[controller].key_left];
    bool dir_right = keyboard && keyboard_state[config_input[controller].key_right];
    bool dir_up = keyboard && keyboard_state[config_input[controller].key_up];
    bool dir_down = keyboard && keyboard_state[config_input[controller].key_down];

    if (gp)
    {
        if (config_input[controller].gamepad_directional == 0 ||
            config_input[controller].gamepad_directional == 2)
        {
            dir_left  |= SDL_GetGamepadButton(gamepad_ctrl, SDL_GAMEPAD_BUTTON_DPAD_LEFT);
            dir_right |= SDL_GetGamepadButton(gamepad_ctrl, SDL_GAMEPAD_BUTTON_DPAD_RIGHT);
            dir_up    |= SDL_GetGamepadButton(gamepad_ctrl, SDL_GAMEPAD_BUTTON_DPAD_UP);
            dir_down  |= SDL_GetGamepadButton(gamepad_ctrl, SDL_GAMEPAD_BUTTON_DPAD_DOWN);
        }
        if (config_input[controller].gamepad_directional == 1 ||
            config_input[controller].gamepad_directional == 2)
        {
            const int STICK_DEAD_ZONE = 8000;
            int rawx = SDL_GetGamepadAxis(gamepad_ctrl, (SDL_GamepadAxis)config_input[controller].gamepad_x_axis);
            int rawy = SDL_GetGamepadAxis(gamepad_ctrl, (SDL_GamepadAxis)config_input[controller].gamepad_y_axis);
            int x = config_input[controller].gamepad_invert_x_axis ? -rawx : rawx;
            int y = config_input[controller].gamepad_invert_y_axis ? -rawy : rawy;

            if (x < -STICK_DEAD_ZONE) dir_left = true;
            else if (x > STICK_DEAD_ZONE) dir_right = true;
            if (y < -STICK_DEAD_ZONE) dir_up = true;
            else if (y > STICK_DEAD_ZONE) dir_down = true;
        }
    }

    input_filter_opposing_directions(controller, &dir_left, &dir_right, &dir_up, &dir_down);

    input_send_key(controller, 0, Key_Left, dir_left);
    input_send_key(controller, 1, Key_Right, dir_right);
    input_send_key(controller, 2, Key_Up, dir_up);
    input_send_key(controller, 3, Key_Down, dir_down);

    // Button + keypad keys (index 4-19)
    for (int i = 0; i < 16; i++)
    {
        bool pressed = keyboard && keyboard_state[button_map[i].key];
        if (gp)
            pressed |= gamepad_get_button(gamepad_ctrl, button_map[i].gp_btn_field);
        if ((controller == 0) && (i < 2) && (config_emulator.spinner == 3) && !config_debug.debug)
            pressed |= roller_mouse_buttons[i];
        // Left/Right buttons also map from directional for non-keypad
        input_send_key(controller, 4 + i, button_map[i].gc_key, pressed);
    }
}

GC_AdamKey events_adam_typing_key(SDL_Scancode scancode)
{
    int key = KeyMap::GetDefaultKey((u16)scancode);
    return (key < 0) ? GC_ADAM_KEY_COUNT : (GC_AdamKey)key;
}

const char* events_adam_reserved_key(SDL_Scancode scancode)
{
    if (scancode == SDL_SCANCODE_UNKNOWN)
        return NULL;

    switch (scancode)
    {
        case SDL_SCANCODE_LSHIFT: case SDL_SCANCODE_RSHIFT:
        case SDL_SCANCODE_LCTRL: case SDL_SCANCODE_RCTRL:
        case SDL_SCANCODE_LALT: case SDL_SCANCODE_RALT:
        case SDL_SCANCODE_LGUI: case SDL_SCANCODE_RGUI:
        case SDL_SCANCODE_CAPSLOCK:
            return "Keyboard modifier";
        default: break;
    }

    return NULL;
}

static void send_adam_key(SDL_Scancode scancode, bool pressed)
{
    if ((scancode <= SDL_SCANCODE_UNKNOWN) || (scancode >= SDL_SCANCODE_COUNT))
        return;

    if (adam_scancode_down[scancode] == pressed)
        return;

    adam_scancode_down[scancode] = pressed;

    if (pressed)
        emu_adam_host_key_pressed((int)scancode);
    else
        emu_adam_host_key_released((int)scancode);
}

// Fractions carry over so slow movements are not lost
static int spinner_movement(int spinner, float movement)
{
    spinner_remainder[spinner] += movement;
    int ret = (int)spinner_remainder[spinner];
    spinner_remainder[spinner] -= (float)ret;
    return ret;
}
