/*
 * Gearcoleco - ColecoVision Emulator
 * Copyright (C) 2021  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#include <math.h>
#include "imgui.h"
#include "imgui_internal.h"
#include "implot.h"
#include "fonts/RobotoMedium.h"
#include "fonts/MaterialIcons.h"
#include "fonts/IconsMaterialDesign.h"
#include "config.h"
#include "application.h"
#include "emu.h"
#include "events.h"
#include "game_focus.h"
#include "ogl_renderer.h"
#include "utils.h"
#include "gearcoleco.h"
#include "KeyMapper.h"

#define GUI_IMPORT
#include "gui.h"
#include "gui_adam.h"
#include "emu_adam.h"
#include "gui_menus.h"
#include "gui_shader.h"
#include "gui_popups.h"
#include "gui_actions.h"
#include "gui_notifications.h"
#include "gui_colors.h"
#include "gui_filedialogs.h"
#include "gui_debug.h"
#include "gui_debug_memory.h"
#include "gui_debug_disassembler.h"
#include "gui_debug_psg.h"
#include "gui_debug_trace_logger.h"

static bool error_window_active = false;
static char error_message[4096] = "";
static bool loading_rom_active = false;
static int pending_state_slot = 0;
static std::string pending_state_path;
static char loading_rom_path[4096] = "";
static char loading_symbol_path[4096] = "";
static bool output_focus_requested = false;
static bool output_focus_restore = false;
static bool output_blocked = false;
static bool output_debug = false;
static bool output_powered = false;
static bool output_game_focus = false;
static bool output_captured = false;


static void main_window(void);
static void update_output_focus(bool output_was_focused);
static void update_key_mapper_pointer(const ImVec2& min, const ImVec2& max);
static void show_error_window(void);
static void show_loading_popup(void);
static void select_save_slot(int slot);
static bool finish_started_content(bool load_symbols);
static void load_pending_state(void);
static void update_window_visibility_padding(void);
static GC_Color color_float_to_int(ImVec4 color);
static ImVec4 color_int_to_float(GC_Color color);
static void update_palette(void);
static Cartridge::CartridgeTypes get_mapper(int index);
static Cartridge::CartridgeRegions get_region(int index);
static void set_style(void);
static void set_style_light(ImGuiStyle& style);
static void set_style_dark(ImGuiStyle& style);
static ImVec4 make_color(unsigned int rgb, float alpha = 1.0f);
static ImVec4 lerp(const ImVec4& a, const ImVec4& b, float t);

bool gui_init(void)
{
    gui_main_window_width = 0;
    gui_main_window_height = 0;

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImPlot::CreateContext();
    ImGui::StyleColorsDark();
    ImGuiIO& io = ImGui::GetIO();

    io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;
    io.ConfigDockingWithShift = true;
    io.IniFilename = config_imgui_file_path;

#if defined(__APPLE__) || defined(_WIN32)
    if (config_debug.multi_viewport)
        io.ConfigFlags |= ImGuiConfigFlags_ViewportsEnable;
#endif

    gui_roboto_font = io.Fonts->AddFontFromMemoryCompressedTTF(RobotoMedium_compressed_data, RobotoMedium_compressed_size, 17.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());

    float iconFontSize = 20.0f;
    static const ImWchar icons_ranges[] = { ICON_MIN_MD, ICON_MAX_16_MD, 0 };
    ImFontConfig icons_config;
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
    icons_config.GlyphMinAdvanceX = iconFontSize;
    icons_config.GlyphOffset = { 0.0f, 5.0f };
    gui_material_icons_font = io.Fonts->AddFontFromMemoryCompressedTTF(MaterialIcons_compressed_data, MaterialIcons_compressed_size, iconFontSize, &icons_config, icons_ranges);

    ImFontConfig font_cfg;

    for (int i = 0; i < 4; i++)
    {
        font_cfg.SizePixels = (13.0f + (i * 3));
        font_cfg.GlyphMinAdvanceX = font_cfg.SizePixels * 7.0f / 13.0f;
        font_cfg.GlyphMaxAdvanceX = font_cfg.GlyphMinAdvanceX;
        gui_default_fonts[0][i] = io.Fonts->AddFontDefaultVector(&font_cfg);
        gui_default_fonts[1][i] = io.Fonts->AddFontDefaultBitmap(&font_cfg);
    }

    gui_apply_settings();

    if (strlen(gui_bios_path) > 0)
        emu_load_bios(gui_bios_path);

    if (strlen(gui_adam_eos_path) > 0)
        emu_load_adam_firmware(GC_ADAM_FIRMWARE_EOS, gui_adam_eos_path);

    if (strlen(gui_adam_smartwriter_path) > 0)
        emu_load_adam_firmware(GC_ADAM_FIRMWARE_SMARTWRITER, gui_adam_smartwriter_path);

    gui_debug_init();
    gui_init_menus();

    return true;
}

void gui_apply_settings(void)
{
    gui_default_font = gui_default_fonts[config_debug.font_type][config_debug.font_size];

    set_style();

    emu_audio_sync = config_audio.sync;

    emu_audio_mute(!config_audio.enable);
    emu_audio_set_master_volume(config_audio.master_volume);

    emu_set_video_chip(config_video.video_chip);
    emu_set_overscan(config_debug.debug ? config_debug.overscan : config_video.overscan);

    strncpy_fit(gui_bios_path, config_emulator.bios_path.c_str(), sizeof(gui_bios_path));

    strncpy_fit(gui_adam_eos_path, config_emulator.adam_eos_path.c_str(), sizeof(gui_adam_eos_path));

    strncpy_fit(gui_adam_smartwriter_path, config_emulator.adam_smartwriter_path.c_str(), sizeof(gui_adam_smartwriter_path));

    emu_video_no_sprite_limit(config_video.sprite_limit);
    emu_set_disassembler_syntax(config_debug.dis_syntax);

    for (int i = 0; i < 16; i++)
        gui_custom_palette[i] = color_int_to_float(config_video.color[i]);
    update_palette();

    strncpy_fit(gui_savefiles_path, config_emulator.savefiles_path.c_str(), sizeof(gui_savefiles_path));
    strncpy_fit(gui_savestates_path, config_emulator.savestates_path.c_str(), sizeof(gui_savestates_path));
    strncpy_fit(gui_screenshots_path, config_emulator.screenshots_path.c_str(), sizeof(gui_screenshots_path));
    strncpy_fit(gui_video_recordings_path, config_emulator.video_recordings_path.c_str(), sizeof(gui_video_recordings_path));
    strncpy_fit(gui_mcp_http_address, config_emulator.mcp_http_address.c_str(), sizeof(gui_mcp_http_address));
}

void gui_destroy(void)
{
    gui_debug_auto_save_settings();
    gui_debug_destroy();
    ImPlot::DestroyContext();
    ImGui::DestroyContext();
}

void gui_render(void)
{
    bool keyboard_was_active = events_is_adam_keyboard_active();
    bool output_was_focused = gui_main_window_focused;
    output_captured = events_is_adam_keyboard_captured();
    ImGui::NewFrame();

    update_window_visibility_padding();

    if (config_debug.debug)
        ImGui::DockSpaceOverViewport();

    gui_in_use = gui_dialog_in_use;

    gui_main_menu();
    update_output_focus(output_was_focused);

    gui_main_window_hovered = false;
    gui_main_window_focused = false;
    gui_main_window_sdl_window_id = 0;

    if((!config_debug.debug && !emu_is_empty()) || (config_debug.debug && config_debug.show_screen))
        main_window();

    gui_debug_windows();
    gui_adam_windows();
    gui_shader_parameters_window();

    if (config_emulator.show_info)
        gui_show_info();

    show_loading_popup();
    gui_notifications_render();
    show_error_window();

    if (!config_debug.debug && !emu_is_empty() && emu_get_machine() == GC_MACHINE_ADAM)
    {
        ImGuiIO& io = ImGui::GetIO();
        gui_main_window_focused = SDL_GetKeyboardFocus() == application_sdl_window && !io.WantCaptureKeyboard && !io.WantTextInput;
    }

    if (keyboard_was_active && !events_is_adam_keyboard_active())
        events_release_adam_keys();

    ImGui::Render();
}

void gui_hotkey(config_HotkeyIndex hotkey, bool pressed)
{
    if (hotkey == config_HotkeyIndex_Rewind)
    {
        if (pressed)
            gui_action_rewind_pressed();
        else
            gui_action_rewind_released();

        return;
    }

    if (!pressed)
        return;

    switch (hotkey)
    {  
    case config_HotkeyIndex_OpenROM:
        gui_shortcut_open_rom = true;
        break;
    case config_HotkeyIndex_ReloadROM:
        gui_action_reload_rom();
        break;
    case config_HotkeyIndex_Quit:
        application_trigger_quit();
        break;
    case config_HotkeyIndex_Reset:
        gui_action_reset();
        break;
    case config_HotkeyIndex_Pause:
        gui_action_pause();
        break;
    case config_HotkeyIndex_FFWD:
        config_emulator.ffwd = !config_emulator.ffwd;
        gui_action_ffwd();
        break;
    case config_HotkeyIndex_Mute:
        config_audio.enable = !config_audio.enable;
        emu_audio_mute(!config_audio.enable);
        gui_notify(gui_NotificationInfo, config_audio.enable ? ICON_MD_VOLUME_UP : ICON_MD_VOLUME_OFF,
            config_audio.enable ? "Audio unmuted" : "Audio muted", NULL, "mute", gui_NotificationDurationShort);
        break;
    case config_HotkeyIndex_SaveState:
        gui_action_save_state(NULL);
        break;
    case config_HotkeyIndex_LoadState:
        gui_action_load_state(NULL);
        break;
    case config_HotkeyIndex_SelectSlot1:
        select_save_slot(0);
        break;
    case config_HotkeyIndex_SelectSlot2:
        select_save_slot(1);
        break;
    case config_HotkeyIndex_SelectSlot3:
        select_save_slot(2);
        break;
    case config_HotkeyIndex_SelectSlot4:
        select_save_slot(3);
        break;
    case config_HotkeyIndex_SelectSlot5:
        select_save_slot(4);
        break;
    case config_HotkeyIndex_Screenshot:
        gui_action_save_screenshot(NULL);
        break;
    case config_HotkeyIndex_VideoRecording:
        gui_action_toggle_video_recording();
        break;
    case config_HotkeyIndex_Fullscreen:
        if (emu_is_video_recording())
            break;
        config_emulator.fullscreen = !config_emulator.fullscreen;
        application_trigger_fullscreen(config_emulator.fullscreen);
        break;
    case config_HotkeyIndex_KeyboardMapper:
        emu_key_mapper_toggle();
        break;
    case config_HotkeyIndex_KeyMapping:
        gui_action_toggle_key_mapping();
        break;
    case config_HotkeyIndex_GameFocus:
        game_focus_toggle();
        break;
    case config_HotkeyIndex_DebugStepOver:
        if (config_debug.debug)
            emu_debug_step_over();
        break;
    case config_HotkeyIndex_DebugStepInto:
        if (config_debug.debug)
            emu_debug_step_into();
        break;
    case config_HotkeyIndex_DebugStepOut:
        if (config_debug.debug)
            emu_debug_step_out();
        break;
    case config_HotkeyIndex_DebugStepFrame:
        if (config_debug.debug)
        {
            emu_debug_step_frame();
            gui_debug_memory_step_frame();
        }
        break;
    case config_HotkeyIndex_DebugBreak:
        if (config_debug.debug)
            emu_debug_break();
        break;
    case config_HotkeyIndex_DebugContinue:
        if (config_debug.debug)
            emu_debug_continue();
        break;
    case config_HotkeyIndex_DebugRunToCursor:
        if (config_debug.debug)
            gui_debug_runtocursor();
        break;
    case config_HotkeyIndex_DebugGoBack:
        if (config_debug.debug)
            gui_debug_go_back();
        break;
    case config_HotkeyIndex_DebugBreakpoint:
        if (config_debug.debug)
            gui_debug_toggle_breakpoint();
        break;
    case config_HotkeyIndex_ShowMainMenu:
        config_emulator.always_show_menu = !config_emulator.always_show_menu;
        break;
    default:
        break;
    }
}

bool gui_load_rom(const char* path, const char* symbol_path)
{
    if (loading_rom_active)
        return false;

    gui_debug_auto_save_settings();
    emu_resume();

    strncpy(loading_rom_path, path, sizeof(loading_rom_path) - 1);
    loading_rom_path[sizeof(loading_rom_path) - 1] = '\0';
    if (IsValidPointer(symbol_path) && (strlen(symbol_path) > 0))
    {
        strncpy(loading_symbol_path, symbol_path, sizeof(loading_symbol_path) - 1);
        loading_symbol_path[sizeof(loading_symbol_path) - 1] = '\0';
    }
    else
        loading_symbol_path[0] = '\0';
    if (!emu_load_media_async(path, gui_get_force_configuration()))
        return false;

    loading_rom_active = true;

    return true;
}

bool gui_is_cartridge_file(const char* path)
{
    if (emu_is_busy())
        return false;

    EmuDesktopContent content = {};

    bool valid = emu_adam_classify_content(path, GC_MACHINE_AUTO, &content) && content.type == EmuDesktopContentCartridge;

    emu_adam_destroy_content(&content);

    return valid;
}

bool gui_open_rom(const char* path, bool adam_cartridge)
{
    if (loading_rom_active)
        return false;

    if (!gui_is_cartridge_file(path))
    {
        gui_set_error_message("Open ROM accepts cartridge images. Insert ADAM disks and data packs using the ADAM drive menus.");
        return false;
    }

    if (!emu_is_bios_loaded() || (adam_cartridge && !emu_are_adam_firmware_paths_valid()))
    {
        gui_adam_open_missing_firmware(adam_cartridge);
        return false;
    }

    int previous_machine = config_emulator.machine;
    int previous_boot = config_emulator.adam_boot_mode;
    config_emulator.machine = adam_cartridge ? GC_MACHINE_ADAM : GC_MACHINE_COLECOVISION;
    config_emulator.adam_boot_mode = adam_cartridge ? 2 : 0;
    bool started = gui_load_rom(path);
    config_emulator.machine = previous_machine;
    config_emulator.adam_boot_mode = previous_boot;

    return started;
}

void gui_drop_media(const char* path)
{
    if (emu_is_busy())
        return;

    EmuDesktopContent content = {};

    if (!emu_adam_classify_content(path, GC_MACHINE_AUTO, &content))
    {
        emu_adam_destroy_content(&content);
        gui_set_error_message("Unable to identify the dropped image. Use Open ROM or an ADAM drive's Insert menu.");
        return;
    }

    EmuDesktopContentType type = content.type;

    emu_adam_destroy_content(&content);

    if (type == EmuDesktopContentCartridge)
        gui_open_rom(path);
    else
        gui_adam_drop_media(path, type == EmuDesktopContentAdamDisk);
}

bool gui_start_adam(const char* const* media_paths)
{
    if (loading_rom_active)
        return false;

    gui_debug_auto_save_settings();

    emu_resume();

    if (!emu_start_adam(media_paths))
        return false;

    return finish_started_content(false);
}

bool gui_is_rom_loading(void)
{
    return loading_rom_active;
}

bool gui_finish_loading_rom(void)
{
    if (!loading_rom_active || emu_is_media_loading())
        return false;

    loading_rom_active = false;
    gui_dialog_in_use = false;
    bool success = emu_finish_media_loading();

    if (success)
    {
        if (emu_get_machine() == GC_MACHINE_COLECOVISION)
            config_push_recent_media(loading_rom_path);
        else if (emu_get_core()->GetContentType() == GC_CONTENT_ADAM_DISK)
            gui_adam_remember_media(GC_ADAM_MEDIA_DISK_1, loading_rom_path);
        else if (emu_get_core()->GetContentType() == GC_CONTENT_ADAM_DATA_PACK)
            gui_adam_remember_media(GC_ADAM_MEDIA_DATA_PACK_1, loading_rom_path);
        success = finish_started_content(true);
    }

    else
    {
        std::string message("Error loading content:\n");
        message += loading_rom_path;
        gui_set_error_message(message.c_str());
    }


    load_pending_state();
    return success;
}

void gui_load_state_after_media(int slot, const char* path)
{
    pending_state_slot = slot;
    pending_state_path = IsValidPointer(path) ? path : "";

    if (!loading_rom_active)
        load_pending_state();
}

Cartridge::ForceConfiguration gui_get_force_configuration(void)
{
    Cartridge::ForceConfiguration config;
    config.type = get_mapper(config_emulator.mapper);
    config.region = get_region(config_emulator.region);
    return config;
}

void gui_set_error_message(const char* message)
{
    strncpy_fit(error_message, message, sizeof(error_message));
    error_window_active = true;
}

void gui_center_next_window(void)
{
    ImVec2 center = ImGui::GetMainViewport()->GetCenter();
    ImGui::SetNextWindowPos(center, ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
}

bool gui_has_open_window(void)
{
    ImGuiContext* context = ImGui::GetCurrentContext();

    for (int i = 0; i < context->Windows.Size; i++)
    {
        ImGuiWindow* window = context->Windows[i];

        if (window->Active && (window->Flags & ImGuiWindowFlags_NoTitleBar) == 0)
            return true;
    }

    return false;
}

void gui_set_style(void)
{
    set_style();
}

static void update_window_visibility_padding(void)
{
    static bool initialized = false;
    static ImVec2 previous_work_size(0.0f, 0.0f);

    ImGuiViewport* viewport = ImGui::GetMainViewport();
    if (!viewport || viewport->WorkSize.x <= 0.0f || viewport->WorkSize.y <= 0.0f)
        return;

    ImGuiStyle& style = ImGui::GetStyle();
    bool viewport_shrank = initialized && ((viewport->WorkSize.x < previous_work_size.x) || (viewport->WorkSize.y < previous_work_size.y));

    style.DisplayWindowPadding = viewport_shrank ? ImVec2(100.0f, 70.0f) : ImVec2(19.0f, 19.0f);

    previous_work_size = viewport->WorkSize;
    initialized = true;
}

static void main_window(void)
{
    GC_RuntimeInfo runtime;
    emu_get_runtime(runtime);

    ImGuiIO& io = ImGui::GetIO();

    float framebuffer_scale_x = io.DisplayFramebufferScale.x;
    float framebuffer_scale_y = io.DisplayFramebufferScale.y;

    if (framebuffer_scale_x <= 0.0f)
        framebuffer_scale_x = 1.0f;
    if (framebuffer_scale_y <= 0.0f)
        framebuffer_scale_y = 1.0f;

    float logical_w = io.DisplaySize.x;
    float logical_h = io.DisplaySize.y - (application_show_menu ? (float)gui_main_menu_height : 0.0f);
    int w = (int)logical_w;
    int h = (int)logical_h;
    int physical_w = (int)floorf(logical_w * framebuffer_scale_x);
    int physical_h = (int)floorf(logical_h * framebuffer_scale_y);

    bool key_mapper = emu_key_mapper_is_open();
    int selected_ratio = key_mapper ? 1 : (config_debug.debug ? 0 : config_video.ratio);
    int selected_scale = (key_mapper && (config_video.scale == 3)) ? 2 : config_video.scale;
    float ratio = 0;

    switch (selected_ratio)
    {
        case 1:
            ratio = 4.0f / 3.0f;
            break;
        case 2:
            ratio = 16.0f / 9.0f;
            break;
        case 3:
            ratio = 16.0f / 10.0f;
            break;
        default:
            ratio = (float)runtime.screen_width / (float)runtime.screen_height;
    }

    if (!config_debug.debug && selected_scale == 3)
    {
        ratio = logical_w / logical_h;
    }

    int base_width = (int)runtime.screen_width;
    int base_height = (int)(runtime.screen_height);

    int w_corrected, h_corrected;
    int scale_multiplier = 0;

    if (config_debug.debug)
    {
        scale_multiplier = config_debug.scale;
        w_corrected = key_mapper ? (int)round(base_height * ratio) : base_width;
        h_corrected = base_height;
    }
    else
    {
        if (selected_ratio == 0)
        {
            w_corrected = base_width;
            h_corrected = base_height;
        }
        else
        {
            w_corrected = (int)round(base_height * ratio);
            h_corrected = base_height;
        }

        switch (selected_scale)
        {
        case 0:
        {
            int factor_w = physical_w / w_corrected;
            int factor_h = physical_h / h_corrected;
            scale_multiplier = (factor_w < factor_h) ? factor_w : factor_h;
            break;
        }
        case 1:
            scale_multiplier = config_video.scale_manual;
            break;
        case 2:
            scale_multiplier = 1;
            h_corrected = h;
            w_corrected = (int)round(h * ratio);
            break;
        case 3:
            scale_multiplier = 1;
            w_corrected = w;
            h_corrected = h;
            break;
        default:
            scale_multiplier = 1;
            break;
        }

        if (selected_scale <= 1)
        {
            if (scale_multiplier < 1)
                scale_multiplier = 1;
        }
    }

    float image_w = (float)(w_corrected * scale_multiplier);
    float image_h = (float)(h_corrected * scale_multiplier);

    if (config_debug.debug || selected_scale <= 1)
    {
        image_w /= framebuffer_scale_x;
        image_h /= framebuffer_scale_y;
    }

    int image_logical_width = (int)ceilf(image_w);
    int image_logical_height = (int)ceilf(image_h);
    int image_physical_width = (int)roundf(image_w * framebuffer_scale_x);
    int image_physical_height = (int)roundf(image_h * framebuffer_scale_y);

    if (image_physical_width < 1)
        image_physical_width = 1;
    if (image_physical_height < 1)
        image_physical_height = 1;

    gui_main_window_width = image_logical_width;
    gui_main_window_height = image_logical_height;

    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0.0f, 0.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0.0f);

    ImGuiWindowFlags flags = ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar;
    bool window_visible = false;

    if (config_debug.debug)
    {
        flags |= ImGuiWindowFlags_AlwaysAutoResize;

        ImGui::SetNextWindowPos(ImVec2(631, 26), ImGuiCond_FirstUseEver);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);

        if (output_focus_requested && !output_blocked)
        {
            ImGui::SetNextWindowFocus();
            output_focus_requested = false;
        }

        const char* title = output_captured ? "Output (Keyboard Captured)###debug_output" : "Output###debug_output";
        window_visible = ImGui::Begin(title, &config_debug.show_screen, flags);
        gui_main_window_hovered = ImGui::IsWindowHovered();
        gui_main_window_focused = ImGui::IsWindowFocused(ImGuiFocusedFlags_RootAndChildWindows);
    }
    else
    {
        float window_x = (logical_w - image_w) * 0.5f;
        float window_y = ((logical_h - image_h) * 0.5f) + (application_show_menu ? (float)gui_main_menu_height : 0.0f);

        window_x = roundf(window_x * framebuffer_scale_x) / framebuffer_scale_x;
        window_y = roundf(window_y * framebuffer_scale_y) / framebuffer_scale_y;

        ImGui::SetNextWindowSize(ImVec2(image_w, image_h));
        ImGui::SetNextWindowPos(ImGui::GetMainViewport()->Pos + ImVec2(window_x, window_y));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);

        flags |= ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoBringToFrontOnFocus;

        window_visible = ImGui::Begin(GEARCOLECO_TITLE, 0, flags);
        gui_main_window_hovered = ImGui::IsWindowHovered();
        gui_main_window_focused = ImGui::IsWindowFocused(ImGuiFocusedFlags_RootAndChildWindows);
    }

    ImGuiViewport* output_viewport = ImGui::GetWindowViewport();
    SDL_WindowID output_window_id = output_viewport ? (SDL_WindowID)(intptr_t)output_viewport->PlatformHandle : 0;

    if (output_window_id != 0)
        gui_main_window_sdl_window_id = output_window_id;
    else if (application_sdl_window)
        gui_main_window_sdl_window_id = SDL_GetWindowID(application_sdl_window);

    OglRendererScreenGeometry screen_geometry;
    screen_geometry.physical_width = image_physical_width;
    screen_geometry.physical_height = image_physical_height;
    screen_geometry.framebuffer_scale = framebuffer_scale_x;
    ogl_renderer_set_screen_geometry(&screen_geometry);

    float tex_h = 1.0f;
    float tex_v = 1.0f;
    ogl_renderer_get_screen_uv(&tex_h, &tex_v);

    ImVec2 image_size(image_w, image_h);
    ImVec2 layout_max = ImGui::GetCursorScreenPos() + image_size;
    ImVec2 image_min = gui_snap_to_physical_pixel(ImGui::GetCursorScreenPos());
    ImVec2 image_max = image_min + image_size;

    if (image_w > 0.0f && image_h > 0.0f)
    {
        ImGui::InvisibleButton("##output_image", image_size, ImGuiButtonFlags_MouseButtonLeft |
            ImGuiButtonFlags_MouseButtonRight | ImGuiButtonFlags_MouseButtonMiddle);

        if (ImGui::IsItemActive())
            gui_main_window_hovered = true;
    }
    else
        ImGui::Dummy(image_size);

    if (window_visible)
    {
        ImDrawList* draw_list = ImGui::GetWindowDrawList();
        ImVec2 clip_min = draw_list->GetClipRectMin();
        ImVec2 clip_max = draw_list->GetClipRectMax();

        if (!ImGui::IsWindowDocked())
        {
            if (clip_max.x > layout_max.x - 1.0f)
                clip_max.x = fmaxf(clip_max.x, image_max.x);
            if (clip_max.y > layout_max.y - 1.0f)
                clip_max.y = fmaxf(clip_max.y, image_max.y);
        }

        draw_list->PushClipRect(clip_min, clip_max, false);
        draw_list->AddImage((ImTextureID)(intptr_t)ogl_renderer_get_screen_texture(), image_min, image_max, ImVec2(0, 0), ImVec2(tex_h, tex_v));
        draw_list->PopClipRect();

        if (key_mapper)
            update_key_mapper_pointer(image_min, image_max);

        gui_notifications_render_output(image_min, image_max);

        if (config_video.fps)
            gui_show_fps(image_min, image_max);
    }

    if (config_debug.debug && (emu_get_machine() == GC_MACHINE_ADAM) && ImGui::IsItemHovered())
        ImGui::SetTooltip("Click Output to type on the ADAM keyboard.\nClick a debugger tool to use its keyboard shortcuts.");

    ImGui::End();

    ImGui::PopStyleVar();
    ImGui::PopStyleVar();
    ImGui::PopStyleVar();
}

static void update_output_focus(bool output_was_focused)
{
    if (!config_debug.debug)
    {
        output_debug = false;
        output_focus_requested = false;
        return;
    }

    bool blocked = gui_in_use || gui_dialog_in_use || gui_file_dialog_is_active() ||
        ImGui::IsPopupOpen((const char*)NULL, ImGuiPopupFlags_AnyPopup);
    bool powered = !emu_is_empty();
    bool game_focus = game_focus_is_on();

    if (!output_debug || (powered && !output_powered) || (game_focus && !output_game_focus))
        output_focus_requested = true;

    if (blocked && !output_blocked)
        output_focus_restore = output_was_focused;
    else if (!blocked && output_blocked && output_focus_restore)
        output_focus_requested = true;

    output_debug = true;
    output_blocked = blocked;
    output_powered = powered;
    output_game_focus = game_focus;
}

static void update_key_mapper_pointer(const ImVec2& min, const ImVec2& max)
{
    GC_RuntimeInfo runtime;
    emu_get_runtime(runtime);
    ImVec2 mouse = ImGui::GetMousePos();
    float width = max.x - min.x;
    float height = max.y - min.y;

    if ((width <= 0.0f) || (height <= 0.0f) || !ImGui::IsMousePosValid(&mouse))
        return;

    int x = (int)(((mouse.x - min.x) * (float)runtime.screen_width) / width);
    int y = (int)(((mouse.y - min.y) * (float)runtime.screen_height) / height);
    emu_key_mapper_set_pointer(x, y);

    bool over = gui_main_window_hovered && !gui_in_use;
    u8 buttons = 0;

    if (over && ImGui::IsMouseDown(ImGuiMouseButton_Left))
        buttons |= GC_KEY_MAPPER_BUTTON_LEFT;

    if (over && ImGui::IsMouseDown(ImGuiMouseButton_Right))
        buttons |= GC_KEY_MAPPER_BUTTON_RIGHT;

    emu_key_mapper_set_buttons(buttons);
}

ImVec2 gui_snap_to_physical_pixel(const ImVec2& pos)
{
    ImGuiViewport* viewport = ImGui::GetWindowViewport();
    ImVec2 scale = viewport->FramebufferScale;

    if (scale.x <= 0.0f || scale.y <= 0.0f)
        scale = ImGui::GetIO().DisplayFramebufferScale;

    float x = ceilf(((pos.x - viewport->Pos.x) * scale.x) - 0.5f - 0.01f);
    float y = ceilf(((pos.y - viewport->Pos.y) * scale.y) - 0.5f - 0.01f);

    return ImVec2(viewport->Pos.x + (x / scale.x), viewport->Pos.y + (y / scale.y));
}

static void show_loading_popup(void)
{
    if (!loading_rom_active)
        return;

    if (!emu_is_media_loading())
    {
        gui_finish_loading_rom();
        return;
    }

    gui_dialog_in_use = true;

    ImVec2 center = ImGui::GetMainViewport()->GetCenter();
    const ImGuiStyle& style = ImGui::GetStyle();
    ImVec4 loading_highlight = style.Colors[ImGuiCol_HeaderHovered];
    ImVec4 loading_background = style.Colors[ImGuiCol_PopupBg];
    ImVec4 loading_border = loading_highlight;
    loading_background.w = 0.95f;
    loading_border.w = 0.80f;

    ImGui::SetNextWindowPos(center, ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(0.0f, 0.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(30.0f, 20.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 8.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(10.0f, 12.0f));
    ImGui::PushStyleColor(ImGuiCol_PopupBg, loading_background);
    ImGui::PushStyleColor(ImGuiCol_Border, loading_border);
    ImGui::OpenPopup("##loading");

    if (ImGui::BeginPopupModal("##loading", NULL, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove))
    {
        ImGui::PushFont(gui_roboto_font);

        ImGui::PushStyleColor(ImGuiCol_Text, loading_highlight);
        ImGui::TextUnformatted(ICON_MD_HOURGLASS_EMPTY);
        ImGui::PopStyleColor();

        ImGui::SameLine();
        ImGui::Text("LOADING...");

        ImGui::PopFont();
        ImGui::EndPopup();
    }

    ImGui::PopStyleColor(2);
    ImGui::PopStyleVar(3);
}

static void select_save_slot(int slot)
{
    config_emulator.save_slot = slot;

    char message[32];
    snprintf(message, sizeof(message), "Save slot %d selected", slot + 1);
    gui_notify(gui_NotificationInfo, ICON_MD_SAVE, message, NULL, "slot", gui_NotificationDurationShort);
}

static bool finish_started_content(bool load_symbols)
{
    gui_debug_reset();

    if (load_symbols)
    {
        if (loading_symbol_path[0] != '\0')
            gui_debug_load_symbols_file(loading_symbol_path);
        else
        {
            std::string str(loading_rom_path);
            str = str.substr(0, str.find_last_of("."));
            if (!gui_debug_load_symbols_file((str + ".sym").c_str()))
                gui_debug_load_symbols_file((str + ".noi").c_str());
        }
    }

    gui_debug_auto_load_settings();

    if (config_emulator.start_paused)
    {
        emu_pause();

        for (int i = 0; i < EMU_FRAME_BUFFER_SIZE; i++)
        {
            emu_frame_buffer[i] = 0;
        }
    }

    if (emu_get_machine() == GC_MACHINE_ADAM)
        gui_adam_update_title();
    else if (!emu_is_empty())
    {
        application_update_title_with_rom(emu_get_content_name());
        gui_notify(gui_NotificationSuccess, ICON_MD_VIDEOGAME_ASSET, "ROM loaded", emu_get_content_name());
    }

    return true;
}

static void load_pending_state(void)
{
    if (!pending_state_path.empty())
        gui_action_load_state(pending_state_path.c_str());
    else if (pending_state_slot > 0)
        gui_action_load_state_slot(pending_state_slot);

    pending_state_slot = 0;
    pending_state_path.clear();
}

static void show_error_window(void)
{
    if (error_window_active)
    {
        error_window_active = false;
        ImGui::OpenPopup("Error");
    }

    gui_center_next_window();
    if (ImGui::BeginPopupModal("Error", NULL, ImGuiWindowFlags_AlwaysAutoResize))
    {
        ImGui::Text("%s\n\n", error_message);
        ImGui::Separator();
        if (ImGui::Button("OK"))
        {
            ImGui::CloseCurrentPopup();
        }
        ImGui::EndPopup();
    }
}

static GC_Color color_float_to_int(ImVec4 color)
{
    GC_Color ret;
    ret.red = (u8)(color.x * 255.0f);
    ret.green = (u8)(color.y * 255.0f);
    ret.blue = (u8)(color.z * 255.0f);
    return ret;
}

static ImVec4 color_int_to_float(GC_Color color)
{
    return ImVec4(color.red / 255.0f, color.green / 255.0f, color.blue / 255.0f, 1.0f);
}

static void update_palette(void)
{
    gui_update_palette();
}

void gui_update_palette(void)
{
    if (config_video.palette == 2)
    {
        for (int i = 0; i < 16; i++)
            config_video.color[i] = color_float_to_int(gui_custom_palette[i]);
        emu_palette(config_video.color);
    }
    else
    {
        emu_predefined_palette(config_video.palette);
    }
}

static Cartridge::CartridgeTypes get_mapper(int index)
{
    switch (index)
    {
        case 0:
            return Cartridge::CartridgeNotSupported;
        case 1:
            return Cartridge::CartridgeColecoVision;
        case 2:
            return Cartridge::CartridgeMegaCart;
        case 3:
            return Cartridge::CartridgeActivisionCart;
        case 4:
            return Cartridge::CartridgeOCM;
        default:
            return Cartridge::CartridgeNotSupported;
    }
}

static Cartridge::CartridgeRegions get_region(int index)
{
    //"Auto\0NTSC (60 Hz)\0PAL (50 Hz)\0\0");
    switch (index)
    {
        case 0:
            return Cartridge::CartridgeUnknownRegion;
        case 1:
            return Cartridge::CartridgeNTSC;
        case 2:
            return Cartridge::CartridgePAL;
        default:
            return Cartridge::CartridgeUnknownRegion;
    }
}

static void set_style(void)
{
    ImGuiStyle& style = ImGui::GetStyle();

    style.Alpha = 1.0f;
    style.DisabledAlpha = 0.6000000238418579f;
    style.WindowPadding = ImVec2(8.0f, 8.0f);
    style.WindowRounding = 4.0f;
    style.WindowBorderSize = 1.0f;
    style.WindowMinSize = ImVec2(32.0f, 32.0f);
    style.WindowTitleAlign = ImVec2(0.0f, 0.5f);
    style.WindowMenuButtonPosition = ImGuiDir_Left;
    style.ChildRounding = 0.0f;
    style.ChildBorderSize = 1.0f;
    style.PopupRounding = 4.0f;
    style.PopupBorderSize = 1.0f;
    style.FramePadding = ImVec2(4.0f, 3.0f);
    style.FrameRounding = 2.5f;
    style.FrameBorderSize = 0.0f;
    style.ItemSpacing = ImVec2(8.0f, 4.0f);
    style.ItemInnerSpacing = ImVec2(4.0f, 4.0f);
    style.CellPadding = ImVec2(4.0f, 2.0f);
    style.IndentSpacing = 21.0f;
    style.ColumnsMinSpacing = 6.0f;
    style.ScrollbarSize = 11.0f;
    style.ScrollbarRounding = 2.5f;
    style.GrabMinSize = 10.0f;
    style.GrabRounding = 2.0f;
    style.TabRounding = 3.5f;
    style.TabBorderSize = 0.0f;
    style.TabCloseButtonMinWidthUnselected = 0.0f;
    style.ColorButtonPosition = ImGuiDir_Right;
    style.ButtonTextAlign = ImVec2(0.5f, 0.5f);
    style.SelectableTextAlign = ImVec2(0.0f, 0.0f);

    if (config_emulator.theme == config_Theme_Light)
        set_style_light(style);
    else
        set_style_dark(style);
}

static void set_style_light(ImGuiStyle& style)
{
    ImGui::StyleColorsLight();

    const ImVec4 text = make_color(0x21201C);
    const ImVec4 text_secondary = make_color(0x63635E);
    const ImVec4 window = make_color(0xF9F9F8);
    const ImVec4 child = make_color(0xFDFDFC);
    const ImVec4 popup = make_color(0xFDFDFC);
    const ImVec4 control = make_color(0xF1F0EF);
    const ImVec4 neutral_active = make_color(0xE2E1DE);
    const ImVec4 border_subtle = make_color(0xDAD9D6);
    const ImVec4 border = make_color(0xCFCECA);
    const ImVec4 grab = make_color(0xBCBBB5);
    const ImVec4 grab_hover = make_color(0x82827C);
    const ImVec4 slider_grab = make_color(0x8D8D86);
    const ImVec4 accent_soft = make_color(0xF2E7DD);
    const ImVec4 accent_hover = make_color(0xF0E4D9);
    const ImVec4 accent_selected = make_color(0xEBDACA);
    const ImVec4 accent_edge = make_color(0xCEA37E);
    const ImVec4 accent_ink = make_color(0x815E46);
    const ImVec4 accent_strong = make_color(0x3E332E);
    const ImVec4 accent_bright = make_color(0x93725C);

    style.Colors[ImGuiCol_Text] = text;
    style.Colors[ImGuiCol_TextDisabled] = text_secondary;
    style.Colors[ImGuiCol_WindowBg] = window;
    style.Colors[ImGuiCol_ChildBg] = child;
    style.Colors[ImGuiCol_PopupBg] = popup;
    style.Colors[ImGuiCol_Border] = border;
    style.Colors[ImGuiCol_BorderShadow] = make_color(0x000000, 0.0f);
    style.Colors[ImGuiCol_FrameBg] = control;
    style.Colors[ImGuiCol_FrameBgHovered] = accent_soft;
    style.Colors[ImGuiCol_FrameBgActive] = accent_selected;
    style.Colors[ImGuiCol_TitleBg] = control;
    style.Colors[ImGuiCol_TitleBgActive] = accent_bright;
    style.Colors[ImGuiCol_TitleBgCollapsed] = control;
    style.Colors[ImGuiCol_MenuBarBg] = window;
    style.Colors[ImGuiCol_ScrollbarBg] = window;
    style.Colors[ImGuiCol_ScrollbarGrab] = grab;
    style.Colors[ImGuiCol_ScrollbarGrabHovered] = grab_hover;
    style.Colors[ImGuiCol_ScrollbarGrabActive] = accent_ink;
    style.Colors[ImGuiCol_CheckMark] = accent_ink;
    style.Colors[ImGuiCol_SliderGrab] = slider_grab;
    style.Colors[ImGuiCol_SliderGrabActive] = accent_ink;
    style.Colors[ImGuiCol_Button] = control;
    style.Colors[ImGuiCol_ButtonHovered] = accent_soft;
    style.Colors[ImGuiCol_ButtonActive] = accent_selected;
    style.Colors[ImGuiCol_Header] = control;
    style.Colors[ImGuiCol_HeaderHovered] = accent_soft;
    style.Colors[ImGuiCol_HeaderActive] = accent_selected;
    style.Colors[ImGuiCol_Separator] = border_subtle;
    style.Colors[ImGuiCol_SeparatorHovered] = accent_ink;
    style.Colors[ImGuiCol_SeparatorActive] = accent_ink;
    style.Colors[ImGuiCol_ResizeGrip] = make_color(0xBCBBB5, 0.55f);
    style.Colors[ImGuiCol_ResizeGripHovered] = make_color(0xCEA37E, 0.80f);
    style.Colors[ImGuiCol_ResizeGripActive] = make_color(0x815E46, 0.95f);
    style.Colors[ImGuiCol_Tab] = control;
    style.Colors[ImGuiCol_TabHovered] = accent_soft;
    style.Colors[ImGuiCol_TabActive] = accent_selected;
    style.Colors[ImGuiCol_TabUnfocused] = window;
    style.Colors[ImGuiCol_TabUnfocusedActive] = neutral_active;
    style.Colors[ImGuiCol_PlotLines] = accent_ink;
    style.Colors[ImGuiCol_PlotLinesHovered] = accent_strong;
    style.Colors[ImGuiCol_PlotHistogram] = accent_ink;
    style.Colors[ImGuiCol_PlotHistogramHovered] = accent_strong;
    style.Colors[ImGuiCol_TableHeaderBg] = control;
    style.Colors[ImGuiCol_TableBorderStrong] = border;
    style.Colors[ImGuiCol_TableBorderLight] = border_subtle;
    style.Colors[ImGuiCol_TableRowBg] = make_color(0x000000, 0.0f);
    style.Colors[ImGuiCol_TableRowBgAlt] = make_color(0x21201C, 0.03f);
    style.Colors[ImGuiCol_TextSelectedBg] = accent_hover;
    style.Colors[ImGuiCol_DragDropTarget] = accent_bright;
    style.Colors[ImGuiCol_NavHighlight] = make_color(0x93725C, 0.90f);
    style.Colors[ImGuiCol_NavWindowingHighlight] = make_color(0x21201C, 0.70f);
    style.Colors[ImGuiCol_NavWindowingDimBg] = make_color(0x21201C, 0.20f);
    style.Colors[ImGuiCol_ModalWindowDimBg] = make_color(0x21201C, 0.30f);

    style.Colors[ImGuiCol_DockingPreview] = make_color(0x93725C, 0.45f);
    style.Colors[ImGuiCol_DockingEmptyBg] = ImVec4(
        config_video.background_color_debugger[config_Theme_Light][0],
        config_video.background_color_debugger[config_Theme_Light][1],
        config_video.background_color_debugger[config_Theme_Light][2], 1.0f);
    style.Colors[ImGuiCol_TabSelected] = accent_selected;
    style.Colors[ImGuiCol_TabSelectedOverline] = accent_bright;
    style.Colors[ImGuiCol_TabDimmed] = window;
    style.Colors[ImGuiCol_TabDimmedSelected] = control;
    style.Colors[ImGuiCol_TabDimmedSelectedOverline] = accent_edge;
}

static void set_style_dark(ImGuiStyle& style)
{
    ImGui::StyleColorsDark();

    style.Colors[ImGuiCol_Text] = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    style.Colors[ImGuiCol_TextDisabled] = ImVec4(0.5921568870544434f, 0.5921568870544434f, 0.5921568870544434f, 1.0f);
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.060085229575634f, 0.060085229575634f, 0.06008583307266235f, 1.0f);
    style.Colors[ImGuiCol_ChildBg] = ImVec4(0.05882352963089943f, 0.05882352963089943f, 0.05882352963089943f, 1.0f);
    style.Colors[ImGuiCol_PopupBg] = ImVec4(0.1176470592617989f, 0.1176470592617989f, 0.1176470592617989f, 1.0f);
    style.Colors[ImGuiCol_Border] = ImVec4(0.1802574992179871f, 0.1802556961774826f, 0.1802556961774826f, 1.0f);
    style.Colors[ImGuiCol_BorderShadow] = ImVec4(0.3058823645114899f, 0.3058823645114899f, 0.3058823645114899f, 1.0f);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(0.1843137294054031f, 0.1843137294054031f, 0.1843137294054031f, 1.0f);
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.270386278629303f, 0.2703835666179657f, 0.2703848779201508f, 1.0f);
    style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.5764706f, 0.44705882f, 0.36078431f, 1.0f);
    style.Colors[ImGuiCol_TitleBg] = ImVec4(0.1450980454683304f, 0.1450980454683304f, 0.1490196138620377f, 1.0f);
    style.Colors[ImGuiCol_TitleBgActive] = ImVec4(0.5764706f, 0.44705882f, 0.36078431f, 1.0f);
    style.Colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.1450980454683304f, 0.1450980454683304f, 0.1490196138620377f, 1.0f);
    style.Colors[ImGuiCol_MenuBarBg] = ImVec4(0.1176470592617989f, 0.1176470592617989f, 0.1176470592617989f, 1.0f);
    style.Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.1176470592617989f, 0.1176470592617989f, 0.1176470592617989f, 1.0f);
    style.Colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.6266094446182251f, 0.6266031861305237f, 0.6266063451766968f, 1.0f);
    style.Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.9999899864196777f, 0.9999899864196777f, 1.0f, 1.0f);
    style.Colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.9999899864196777f, 0.9999899864196777f, 1.0f, 1.0f);
    style.Colors[ImGuiCol_CheckMark] = ImVec4(0.5764706f, 0.44705882f, 0.36078431f, 1.0f);
    style.Colors[ImGuiCol_SliderGrab] = ImVec4(0.5764706f, 0.44705882f, 0.36078431f, 1.0f);
    style.Colors[ImGuiCol_SliderGrabActive] = ImVec4(0.8764706f, 0.74705882f, 0.66078431f, 1.0f);
    style.Colors[ImGuiCol_Button] = ImVec4(0.184547483921051f, 0.184547483921051f, 0.1845493316650391f, 1.0f);
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.5764706f, 0.44705882f, 0.36078431f, 1.0f);
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.5764706f, 0.44705882f, 0.36078431f, 1.0f);
    style.Colors[ImGuiCol_Header] = ImVec4(0.1843137294054031f, 0.1843137294054031f, 0.1843137294054031f, 1.0f);
    style.Colors[ImGuiCol_HeaderHovered] = ImVec4(0.5764706f, 0.44705882f, 0.36078431f, 1.0f);
    style.Colors[ImGuiCol_HeaderActive] = ImVec4(0.5764706f, 0.44705882f, 0.36078431f, 1.0f);
    style.Colors[ImGuiCol_Separator] = ImVec4(0.1803921610116959f, 0.1803921610116959f, 0.1803921610116959f, 1.0f);
    style.Colors[ImGuiCol_SeparatorHovered] = ImVec4(0.1803921610116959f, 0.1803921610116959f, 0.1803921610116959f, 1.0f);
    style.Colors[ImGuiCol_SeparatorActive] = ImVec4(0.1803921610116959f, 0.1803921610116959f, 0.1803921610116959f, 1.0f);
    style.Colors[ImGuiCol_ResizeGrip] = ImVec4(0.2489270567893982f, 0.2489245682954788f, 0.2489245682954788f, 1.0f);
    style.Colors[ImGuiCol_ResizeGripHovered] = ImVec4(1.0f, 0.9999899864196777f, 0.9999899864196777f, 1.0f);
    style.Colors[ImGuiCol_ResizeGripActive] = ImVec4(1.0f, 0.9999899864196777f, 0.9999899864196777f, 1.0f);
    style.Colors[ImGuiCol_Tab] = ImVec4(0.1450980454683304f, 0.1450980454683304f, 0.1490196138620377f, 1.0f);
    style.Colors[ImGuiCol_TabHovered] = ImVec4(0.5764706f, 0.44705882f, 0.36078431f, 1.0f);
    style.Colors[ImGuiCol_TabActive] = ImVec4(0.5764706f, 0.44705882f, 0.36078431f, 1.0f);
    style.Colors[ImGuiCol_TabUnfocused] = ImVec4(0.1450980454683304f, 0.1450980454683304f, 0.1490196138620377f, 1.0f);
    style.Colors[ImGuiCol_TabUnfocusedActive] = ImVec4(0.5764706f, 0.44705882f, 0.36078431f, 1.0f);
    style.Colors[ImGuiCol_PlotLines] = ImVec4(0.5764706f, 0.44705882f, 0.36078431f, 1.0f);
    style.Colors[ImGuiCol_PlotLinesHovered] = ImVec4(0.5764706f, 0.44705882f, 0.36078431f, 1.0f);
    style.Colors[ImGuiCol_PlotHistogram] = ImVec4(0.5764706f, 0.44705882f, 0.36078431f, 1.0f);
    style.Colors[ImGuiCol_PlotHistogramHovered] = ImVec4(0.5764706f, 0.44705882f, 0.36078431f, 1.0f);
    style.Colors[ImGuiCol_TableHeaderBg] = ImVec4(0.1882352977991104f, 0.1882352977991104f, 0.2000000029802322f, 1.0f);
    style.Colors[ImGuiCol_TableBorderStrong] = ImVec4(0.3098039329051971f, 0.3098039329051971f, 0.3490196168422699f, 1.0f);
    style.Colors[ImGuiCol_TableBorderLight] = ImVec4(0.2274509817361832f, 0.2274509817361832f, 0.2470588237047195f, 1.0f);
    style.Colors[ImGuiCol_TableRowBg] = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
    style.Colors[ImGuiCol_TableRowBgAlt] = ImVec4(1.0f, 1.0f, 1.0f, 0.05999999865889549f);
    style.Colors[ImGuiCol_TextSelectedBg] = ImVec4(0.5764706f, 0.44705882f, 0.36078431f, 1.0f);
    style.Colors[ImGuiCol_DragDropTarget] = ImVec4(0.1450980454683304f, 0.1450980454683304f, 0.1490196138620377f, 1.0f);
    style.Colors[ImGuiCol_NavHighlight] = ImVec4(0.1450980454683304f, 0.1450980454683304f, 0.1490196138620377f, 1.0f);
    style.Colors[ImGuiCol_NavWindowingHighlight] = ImVec4(1.0f, 1.0f, 1.0f, 0.699999988079071f);
    style.Colors[ImGuiCol_NavWindowingDimBg] = ImVec4(0.800000011920929f, 0.800000011920929f, 0.800000011920929f, 0.2000000029802322f);
    style.Colors[ImGuiCol_ModalWindowDimBg] = ImVec4(0.1450980454683304f, 0.1450980454683304f, 0.1490196138620377f, 0.7f);

    style.Colors[ImGuiCol_DockingPreview] = style.Colors[ImGuiCol_HeaderActive] * ImVec4(1.0f, 1.0f, 1.0f, 0.7f);
    style.Colors[ImGuiCol_DockingEmptyBg] = ImVec4(config_video.background_color_debugger[config_emulator.theme][0], config_video.background_color_debugger[config_emulator.theme][1], config_video.background_color_debugger[config_emulator.theme][2], 1.00f);
    style.Colors[ImGuiCol_TabHovered] = style.Colors[ImGuiCol_HeaderHovered];
    //style.Colors[ImGuiCol_Tab] = lerp(style.Colors[ImGuiCol_Header], style.Colors[ImGuiCol_TitleBgActive], 0.80f);
    style.Colors[ImGuiCol_TabSelected] = lerp(style.Colors[ImGuiCol_HeaderActive], style.Colors[ImGuiCol_TitleBgActive], 0.60f);
    style.Colors[ImGuiCol_TabSelectedOverline] = style.Colors[ImGuiCol_HeaderActive];
    style.Colors[ImGuiCol_TabDimmed] = lerp(style.Colors[ImGuiCol_Tab], style.Colors[ImGuiCol_TitleBg], 0.60f);
    style.Colors[ImGuiCol_TabDimmedSelected] = lerp(style.Colors[ImGuiCol_TabSelected], style.Colors[ImGuiCol_TitleBg], 0.40f);
    style.Colors[ImGuiCol_TabDimmedSelectedOverline] = lerp(style.Colors[ImGuiCol_TabSelected], style.Colors[ImGuiCol_TitleBg], 0.20f);
}

static ImVec4 make_color(unsigned int rgb, float alpha)
{
    return ImVec4(((rgb >> 16) & 0xFF) / 255.0f,
                  ((rgb >> 8) & 0xFF) / 255.0f,
                  (rgb & 0xFF) / 255.0f,
                  alpha);
}

static ImVec4 lerp(const ImVec4& a, const ImVec4& b, float t)
{
    return ImVec4(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.z + (b.z - a.z) * t, a.w + (b.w - a.w) * t);
}
