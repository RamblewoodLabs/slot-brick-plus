/*
 * Gearcoleco - ColecoVision Emulator
 * Copyright (C) 2021  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#define GUI_MENUS_IMPORT
#include "gui_menus.h"
#include "gui.h"
#include "gui_adam.h"
#include "emu_adam.h"
#include "gui_filedialogs.h"
#include "gui_popups.h"
#include "gui_actions.h"
#include "gui_notifications.h"
#include "gui_shader.h"
#include "gui_colors.h"
#include "gui_debug.h"
#include "gui_debug_disassembler.h"
#include "gui_debug_memory.h"
#include "config.h"
#include "application.h"
#include "display.h"
#include "gamepad.h"
#include "sound_queue.h"
#include "emu.h"
#include "game_focus.h"
#include "hotkeys.h"
#include "rewind.h"
#include "ogl_renderer.h"
#include "ogl_shader_chain.h"
#include "shader_preset.h"
#include "utils.h"
#include "gearcoleco.h"

static bool open_rom = false;
static bool open_ram = false;
static bool save_ram = false;
static bool open_state = false;
static bool save_state = false;
static bool open_about = false;
static bool open_load_defaults = false;
static bool save_screenshot = false;
static bool save_vgm = false;
static bool save_video = false;
static bool choose_savestates_path = false;
static bool choose_screenshots_path = false;
static bool choose_video_recordings_path = false;
static bool choose_backup_ram_path = false;
static bool save_debug_settings = false;
static bool load_debug_settings = false;
static bool open_adam_cartridge = false;
static char checked_recent_roms[config_max_recent_roms][4096];
static bool recent_is_cartridge[config_max_recent_roms];
static const GuiColor& service_mcp_http_color = green;
static const GuiColor& service_mcp_stdio_color = amber;
static const GuiColor& video_recording_color = red;
static const GuiColor& vgm_recording_color = red;

static void menu_gearcoleco(void);
static void menu_adam(void);
static void menu_emulator(void);
static void menu_video(void);
static void menu_input(void);
static void menu_audio(void);
static void menu_debug(void);
static void menu_about(void);
static void draw_overscan_menu(const char* label, int* overscan, bool enabled, bool apply);
static void draw_background_color_menu(const char* label, int theme);
static void draw_mcp_status(void);
static void draw_recording_status(const char* status, ImVec4 color, float dot_radius, float dot_width);
static void file_dialogs(void);
static void keyboard_configuration_item(const char* text, SDL_Scancode* key, int player);
static void gamepad_configuration_item(const char* text, int* button, int player);
static void hotkey_configuration_item(const char* text, config_Hotkey* hotkey);
static void hotkey_configuration_menu(bool debug);
static void gamepad_device_selector(int player);
static void draw_savestate_slot_info(int slot);

void gui_init_menus(void)
{
    gui_shortcut_open_rom = false;
}

void gui_main_menu(void)
{
    open_rom = false;
    open_adam_cartridge = false;
    open_ram = false;
    save_ram = false;
    open_state = false;
    save_state = false;
    open_about = false;
    open_load_defaults = false;
    save_screenshot = false;
    save_vgm = false;
    save_video = false;
    choose_savestates_path = false;
    choose_screenshots_path = false;
    choose_video_recordings_path = false;
    gui_main_menu_hovered = false;
    choose_backup_ram_path = false;
    save_debug_settings = false;
    load_debug_settings = false;

    if (application_show_menu && ImGui::BeginMainMenuBar())
    {
        gui_main_menu_hovered = ImGui::IsWindowHovered();

        menu_gearcoleco();
        menu_emulator();
        menu_adam();
        menu_video();
        menu_input();
        menu_audio();
        menu_debug();
        menu_about();
        draw_mcp_status();

        gui_main_menu_height = (int)ImGui::GetWindowSize().y;

        ImGui::EndMainMenuBar();
    }

    file_dialogs();
}

static void menu_gearcoleco(void)
{
    if (ImGui::BeginMenu(GEARCOLECO_TITLE))
    {
        gui_in_use = true;
        bool media_actions_enabled = !emu_is_empty();

        if (ImGui::MenuItem("Open ROM...", config_hotkeys[config_HotkeyIndex_OpenROM].str))
        {
            if (emu_is_bios_loaded())
                open_rom = true;
            else
                gui_adam_open_missing_firmware(false);
        }

        if (ImGui::BeginMenu("Open Recent", !emu_is_busy()))
        {
            for (int i = 0; i < config_max_recent_roms; i++)
            {
                if (config_emulator.recent_roms[i].length() > 0)
                {
                    const char* path = config_emulator.recent_roms[i].c_str();
                    if (strcmp(checked_recent_roms[i], path))
                    {
                        strncpy_fit(checked_recent_roms[i], path, sizeof(checked_recent_roms[i]));
                        EmuDesktopContent content = {};
                        bool valid = emu_adam_classify_content(path, GC_MACHINE_AUTO, &content);
                        recent_is_cartridge[i] = valid && content.type == EmuDesktopContentCartridge;
                        if (valid && (content.type == EmuDesktopContentAdamDisk ||
                            content.type == EmuDesktopContentAdamDataPack))
                        {
                            int slot = content.type == EmuDesktopContentAdamDisk ? 0 : 2;
                            for (int recent = 0; recent < 5; recent++)
                            {
                                std::string& entry = config_emulator.adam_recent_media[slot][recent];
                                if (entry == path)
                                    break;
                                if (entry.empty())
                                {
                                    entry = path;
                                    break;
                                }
                            }
                        }
                        emu_adam_destroy_content(&content);
                    }
                    if (!recent_is_cartridge[i])
                        continue;
                    const char* shortcut = NULL;
                    if (ImGui::MenuItem(config_emulator.recent_roms[i].c_str(), shortcut))
                    {
                        if (emu_is_bios_loaded())
                        {
                            char rom_path[4096];
                            strncpy_fit(rom_path, config_emulator.recent_roms[i].c_str(), sizeof(rom_path));
                            gui_open_rom(rom_path);
                        }
                        else
                            gui_adam_open_missing_firmware(false);
                    }
                }
            }

            ImGui::EndMenu();
        }

        ImGui::Separator();
        ImGui::MenuItem("Enable Softpatching", "", &config_emulator.softpatching);
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Automatically applies a matching .ips patch next to the ROM when loading.");

        ImGui::Separator();
        
        if (ImGui::MenuItem("Reset", config_hotkeys[config_HotkeyIndex_Reset].str, false, media_actions_enabled))
        {
            gui_action_reset();
        }

        if (ImGui::MenuItem("Pause", config_hotkeys[config_HotkeyIndex_Pause].str, &config_emulator.paused, media_actions_enabled))
        {
            gui_action_pause();
        }

        ImGui::Separator();

        if (ImGui::BeginMenu("Fast Forward"))
        {
            if (ImGui::MenuItem("Enabled", config_hotkeys[config_HotkeyIndex_FFWD].str, &config_emulator.ffwd, media_actions_enabled))
            {
                gui_action_ffwd();
            }

            if (ImGui::BeginMenu("Speed"))
            {
                ImGui::PushItemWidth(100.0f);
                ImGui::Combo("##fwd", &config_emulator.ffwd_speed, "X 1.5\0X 2\0X 2.5\0X 3\0Unlimited\0\0");
                ImGui::PopItemWidth();
                ImGui::EndMenu();
            }

            ImGui::EndMenu();
        }

        if (ImGui::BeginMenu("Rewind"))
        {
            if (ImGui::MenuItem("Enabled", config_hotkeys[config_HotkeyIndex_Rewind].str, &config_rewind.enabled))
                rewind_reset();

            ImGui::PushItemWidth(140.0f);
            ImGui::SliderFloat("Speed", &config_rewind.speed, 1.0f, 8.0f, "%.0fx");
            ImGui::PopItemWidth();

            ImGui::EndMenu();
        }

        if (ImGui::BeginMenu("Run-Ahead"))
        {
            ImGui::PushItemWidth(140.0f);
            ImGui::Combo("##runahead", &config_emulator.runahead, "Disabled\0" "1 Frame\0" "2 Frames\0" "3 Frames\0\0");
            ImGui::PopItemWidth();

            if (ImGui::IsItemHovered())
            {
                ImGui::BeginTooltip();
                ImGui::Text("Reduces input lag by speculatively running extra frames each update.");
                ImGui::Text("Every frame multiplies CPU cost, so use the lowest value that feels right.");
                ImGui::Text("Ignored while fast-forwarding.");
                ImGui::EndTooltip();
            }

            ImGui::EndMenu();
        }

        ImGui::Separator();

        if (ImGui::BeginMenu("RAM"))
        {
            bool has_save_data = media_actions_enabled && emu_get_core()->GetMemory()->GetMapper() && emu_get_core()->GetMemory()->GetMapper()->GetSaveDataSize() > 0;

            if (ImGui::MenuItem("Save As...", NULL, false, has_save_data))
            {
                save_ram = true;
            }

            if (ImGui::MenuItem("Load From...", NULL, false, has_save_data))
            {
                open_ram = true;
            }

            ImGui::EndMenu();
        }

        if (ImGui::BeginMenu("Savestates"))
        {
            if (ImGui::MenuItem("Save As...", "", false, media_actions_enabled))
            {
                save_state = true;
            }

            if (ImGui::MenuItem("Load From...", "", false, media_actions_enabled))
            {
                open_state = true;
            }

            ImGui::Separator();

            if (ImGui::BeginMenu("Slot"))
            {
                ImGui::PushItemWidth(100.0f);
                ImGui::Combo("##slot", &config_emulator.save_slot, "Slot 1\0Slot 2\0Slot 3\0Slot 4\0Slot 5\0\0");
                ImGui::PopItemWidth();

                ImGui::Separator();
                draw_savestate_slot_info(config_emulator.save_slot);

                ImGui::EndMenu();
            }

            if (ImGui::MenuItem("Save", config_hotkeys[config_HotkeyIndex_SaveState].str, false, media_actions_enabled))
            {
                gui_action_save_state(NULL);
            }

            if (ImGui::MenuItem("Load", config_hotkeys[config_HotkeyIndex_LoadState].str, false, media_actions_enabled))
            {
                gui_action_load_state(NULL);
            }
            if (ImGui::IsItemHovered())
            {
                ImGui::BeginTooltip();
                ImGui::Text("Slot: %d", config_emulator.save_slot + 1);
                ImGui::Separator();
                draw_savestate_slot_info(config_emulator.save_slot);
                ImGui::EndTooltip();
            }

            ImGui::EndMenu();
        }

        ImGui::Separator();

        if (ImGui::BeginMenu("Screenshots"))
        {
            if (ImGui::MenuItem("Save As...", "", false, media_actions_enabled))
            {
                save_screenshot = true;
            }

            if (ImGui::MenuItem("Save", config_hotkeys[config_HotkeyIndex_Screenshot].str, false, media_actions_enabled))
            {
                gui_action_save_screenshot(NULL);
            }

            ImGui::EndMenu();
        }

        if (ImGui::BeginMenu("Video Recording"))
        {
            bool is_recording = emu_is_video_recording();

            if (ImGui::MenuItem("Start Recording As...", "", false, !is_recording && media_actions_enabled))
            {
                save_video = true;
            }

            if (ImGui::MenuItem("Start Recording", config_hotkeys[config_HotkeyIndex_VideoRecording].str, false, !is_recording && media_actions_enabled))
            {
                gui_action_start_video_recording(NULL);
            }

            if (ImGui::MenuItem("Stop Recording", config_hotkeys[config_HotkeyIndex_VideoRecording].str, false, is_recording))
            {
                gui_action_stop_video_recording();
            }

            ImGui::Separator();

            if (ImGui::BeginMenu("Scale", !is_recording))
            {
                ImGui::PushItemWidth(100.0f);
                ImGui::SliderInt("##video_recording_scale", &config_video.recording_scale, 1, 20, "%dx");
                ImGui::PopItemWidth();
                ImGui::EndMenu();
            }

            if (ImGui::BeginMenu("Aspect Ratio", !is_recording))
            {
                ImGui::PushItemWidth(190.0f);
                ImGui::Combo("##video_recording_ratio", &config_video.recording_ratio, "Follow Screen\0Square Pixels (1:1 PAR)\0Standard (4:3 DAR)\0Wide (16:9 DAR)\0Wide (16:10 DAR)\0\0");
                ImGui::PopItemWidth();
                ImGui::EndMenu();
            }

            if (ImGui::BeginMenu("Quality", !is_recording))
            {
                ImGui::PushItemWidth(200.0f);
                ImGui::Combo("##video_recording_quality", &config_video.recording_quality, "Low\0Medium\0High\0Lossless (Uncompressed)\0Lossless (Compressed)\0\0");
                ImGui::PopItemWidth();
                if (ImGui::IsItemHovered())
                {
                    ImGui::BeginTooltip();
                    ImGui::Text("Low and Medium halve the color resolution, best used at 2x or higher.");
                    ImGui::Text("Lossless (Uncompressed) produces very large files.");
                    ImGui::Text("Lossless (Compressed) stores PNG frames, it needs an FFmpeg based player like VLC or mpv.");
                    ImGui::EndTooltip();
                }
                ImGui::EndMenu();
            }

            ImGui::EndMenu();
        }

        ImGui::Separator();

        if (ImGui::MenuItem("Load Default Settings", NULL, false, !gui_is_rom_loading() && !emu_is_busy()))
        {
            open_load_defaults = true;
        }

        ImGui::Separator();

        if (ImGui::MenuItem("Quit", config_hotkeys[config_HotkeyIndex_Quit].str))
        {
            application_trigger_quit();
        }

        ImGui::EndMenu();
    }
}

static void menu_adam(void)
{
    if (gui_adam_menu_requested())
        ImGui::OpenPopup("ADAM");
    if (!ImGui::BeginMenu("ADAM"))
        return;

    gui_in_use = true;
    bool adam_running = !emu_is_empty() && emu_get_machine() == GC_MACHINE_ADAM;
    ImGui::BeginDisabled(emu_is_busy() || gui_is_rom_loading() || gui_file_dialog_is_active());
    if (ImGui::MenuItem(adam_running ? "Computer Reset" : "Power On"))
        gui_adam_start();
    if (ImGui::IsItemHovered())
        ImGui::SetTooltip(adam_running ? "Resets the computer and boots from inserted media, keeping all drives mounted." :
            "Powers on ADAM. It boots from inserted media, or opens SmartWriter when none is bootable.");
    if (adam_running)
    {
        if (ImGui::MenuItem("Power Off"))
            gui_adam_power_off();
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Stops ADAM and saves modified media. Images remain inserted for the next Power On.");
    }
    ImGui::Separator();
    gui_adam_media_menu();
    ImGui::MenuItem("Remember Media Changes", NULL,
        &config_emulator.adam_media_persistence);
    if (ImGui::IsItemHovered())
        ImGui::SetTooltip("Applies to newly inserted images. Changes are saved in a separate copy; original images are preserved.");
    ImGui::Separator();
    gui_adam_controller_menu();
    ImGui::EndDisabled();
    ImGui::Separator();
    ImGui::MenuItem("Printer Output", NULL, &config_debug.show_adam_printer, adam_running);
    if (ImGui::BeginMenu("Keyboard"))
    {
        gui_adam_keyboard_menu();
        ImGui::EndMenu();
    }
    ImGui::Separator();
    gui_adam_firmware_menu("EOS ROM", GC_ADAM_FIRMWARE_EOS);
    gui_adam_firmware_menu("SmartWriter ROM", GC_ADAM_FIRMWARE_SMARTWRITER);

    // ImGui::Separator();

    // if (ImGui::MenuItem("Open Cartridge..."))
    //     open_adam_cartridge = true;
    // if (ImGui::IsItemHovered())
    //     ImGui::SetTooltip("Run a ColecoVision cartridge using ADAM hardware.");
    ImGui::EndMenu();
}

static void menu_emulator(void)
{
    if (ImGui::BeginMenu("Emulator"))
    {
        gui_in_use = true;
        bool adam_running = !emu_is_empty() && (emu_get_machine() == GC_MACHINE_ADAM);
        bool cartridge_options = !adam_running ||
            (emu_get_core()->GetContentType() == GC_CONTENT_CARTRIDGE);

        if (ImGui::BeginMenu("Directories"))
        {
            if (ImGui::BeginMenu("Save States"))
            {
                ImGui::PushItemWidth(220.0f);
                if (ImGui::Combo("##savestate_option", &config_emulator.savestates_dir_option, "Default Location\0Same as ROM\0Custom Location\0\0"))
                {
                    update_savestates_data();
                }

                switch ((Directory_Location)config_emulator.savestates_dir_option)
                {
                    case Directory_Location_Default:
                    {
                        ImGui::Text("%s", config_root_path);
                        break;
                    }
                    case Directory_Location_ROM:
                    {
                        if (!emu_is_empty())
                        {
                            char directory[4096];
                            get_directory(emu_get_content_path(), directory, sizeof(directory));
                            ImGui::Text("%s", directory);
                        }
                        break;
                    }
                    case Directory_Location_Custom:
                    {
                        if (ImGui::MenuItem("Choose..."))
                        {
                            choose_savestates_path = true;
                        }

                        ImGui::PushItemWidth(450);
                        if (ImGui::InputText("##savestate_path", gui_savestates_path, IM_ARRAYSIZE(gui_savestates_path), ImGuiInputTextFlags_AutoSelectAll))
                        {
                            config_emulator.savestates_path.assign(gui_savestates_path);
                            update_savestates_data();
                        }
                        ImGui::PopItemWidth();
                        break;
                    }
                }

                ImGui::EndMenu();
            }

            if (ImGui::BeginMenu("Save Files"))
            {
                ImGui::PushItemWidth(220.0f);
                ImGui::Combo("##savefiles_option", &config_emulator.savefiles_dir_option, "Default Location\0Same as ROM\0Custom Location\0\0");

                switch ((Directory_Location)config_emulator.savefiles_dir_option)
                {
                    case Directory_Location_Default:
                    {
                        ImGui::Text("%s", config_root_path);
                        break;
                    }
                    case Directory_Location_ROM:
                    {
                        if (!emu_is_empty())
                        {
                            char directory[4096];
                            get_directory(emu_get_content_path(), directory, sizeof(directory));
                            ImGui::Text("%s", directory);
                        }
                        break;
                    }
                    case Directory_Location_Custom:
                    {
                        if (ImGui::MenuItem("Choose..."))
                        {
                            choose_backup_ram_path = true;
                        }

                        ImGui::PushItemWidth(450);
                        if (ImGui::InputText("##savefiles_path", gui_savefiles_path, IM_ARRAYSIZE(gui_savefiles_path), ImGuiInputTextFlags_AutoSelectAll))
                        {
                            config_emulator.savefiles_path.assign(gui_savefiles_path);
                        }
                        ImGui::PopItemWidth();
                        break;
                    }
                }

                ImGui::EndMenu();
            }

            if (ImGui::BeginMenu("Screenshots"))
            {
                ImGui::PushItemWidth(220.0f);
                ImGui::Combo("##screenshots_option", &config_emulator.screenshots_dir_option, "Default Location\0Same as ROM\0Custom Location\0\0");

                switch ((Directory_Location)config_emulator.screenshots_dir_option)
                {
                    case Directory_Location_Default:
                    {
                        ImGui::Text("%s", config_root_path);
                        break;
                    }
                    case Directory_Location_ROM:
                    {
                        if (!emu_is_empty())
                        {
                            char directory[4096];
                            get_directory(emu_get_content_path(), directory, sizeof(directory));
                            ImGui::Text("%s", directory);
                        }
                        break;
                    }
                    case Directory_Location_Custom:
                    {
                        if (ImGui::MenuItem("Choose..."))
                        {
                            choose_screenshots_path = true;
                        }

                        ImGui::PushItemWidth(450);
                        if (ImGui::InputText("##screenshots_path", gui_screenshots_path, IM_ARRAYSIZE(gui_screenshots_path), ImGuiInputTextFlags_AutoSelectAll))
                        {
                            config_emulator.screenshots_path.assign(gui_screenshots_path);
                        }
                        ImGui::PopItemWidth();
                        break;
                    }
                }

                ImGui::EndMenu();
            }

            if (ImGui::BeginMenu("Video Recordings"))
            {
                ImGui::PushItemWidth(220.0f);
                ImGui::Combo("##video_recordings_option", &config_emulator.video_recordings_dir_option, "Default Location\0Same as ROM\0Custom Location\0\0");

                switch ((Directory_Location)config_emulator.video_recordings_dir_option)
                {
                    case Directory_Location_Default:
                    {
                        ImGui::Text("%s", config_root_path);
                        break;
                    }
                    case Directory_Location_ROM:
                    {
                        if (!emu_is_empty())
                        {
                            char directory[4096];
                            get_directory(emu_get_content_path(), directory, sizeof(directory));
                            ImGui::Text("%s", directory);
                        }
                        break;
                    }
                    case Directory_Location_Custom:
                    {
                        if (ImGui::MenuItem("Choose..."))
                        {
                            choose_video_recordings_path = true;
                        }

                        ImGui::PushItemWidth(450);
                        if (ImGui::InputText("##video_recordings_path", gui_video_recordings_path, IM_ARRAYSIZE(gui_video_recordings_path), ImGuiInputTextFlags_AutoSelectAll))
                        {
                            config_emulator.video_recordings_path.assign(gui_video_recordings_path);
                        }
                        ImGui::PopItemWidth();
                        break;
                    }
                }

                ImGui::EndMenu();
            }

            ImGui::EndMenu();
        }

        ImGui::Separator();

        ImGui::BeginDisabled(!cartridge_options);
        if (ImGui::BeginMenu("Mapper"))
        {
            ImGui::PushItemWidth(160.0f);
            ImGui::Combo("##emu_mapper", &config_emulator.mapper, "Auto\0Standard\0MegaCart\0Activision\0OCM\0\0");
            ImGui::PopItemWidth();
            ImGui::EndMenu();
        }
        ImGui::EndDisabled();
        if (!cartridge_options && ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled))
            ImGui::SetTooltip("Mapper selection applies to cartridge content, not ADAM media or SmartWriter.");

        if (ImGui::BeginMenu("Refresh Rate"))
        {
            ImGui::PushItemWidth(130.0f);
            if (ImGui::Combo("##emu_rate", &config_emulator.region, "Auto\0NTSC (60 Hz)\0PAL (50 Hz)\0\0"))
            {
                if (config_emulator.region > 0)
                {
                    config_emulator.ffwd = false;
                    config_audio.sync = true;
                }
            }
            ImGui::PopItemWidth();
            ImGui::EndMenu();
        }

        ImGui::Separator();

        gui_adam_firmware_menu("BIOS", GC_ADAM_FIRMWARE_OS7);

        ImGui::Separator();

        ImGui::MenuItem("Start Paused", "", &config_emulator.start_paused);
        ImGui::MenuItem("Pause When Inactive", "", &config_emulator.pause_when_inactive);
        if (ImGui::MenuItem("Allow Screen Saver", "", &config_emulator.allow_screensaver))
        {
            if (config_emulator.allow_screensaver)
                SDL_EnableScreenSaver();
            else
                SDL_DisableScreenSaver();
        }

        ImGui::Separator();

        ImGui::MenuItem("Show Content Info", "", &config_emulator.show_info);

        if (ImGui::BeginMenu("Notifications"))
        {
            ImGui::MenuItem("Enabled", "", &config_emulator.show_notifications);

            if (ImGui::BeginMenu("Duration"))
            {
                ImGui::SliderInt("##notification_duration", &config_emulator.notification_duration, 3, 10, "Seconds = %d",
                    ImGuiSliderFlags_AlwaysClamp);
                ImGui::EndMenu();
            }

            ImGui::EndMenu();
        }

        ImGui::Separator();

        if (ImGui::BeginMenu("Hotkeys"))
        {
            hotkey_configuration_menu(false);
            ImGui::EndMenu();
        }

        if (ImGui::BeginMenu("Debug Hotkeys"))
        {
            hotkey_configuration_menu(true);
            ImGui::EndMenu();
        }

        ImGui::Separator();

        ImGui::MenuItem("Single Instance", "", &config_debug.single_instance);
        if (ImGui::IsItemHovered())
        {
            ImGui::BeginTooltip();
            ImGui::Text("RESTART REQUIRED");
            ImGui::NewLine();
            ImGui::Text("When enabled, opening a ROM while another instance is running");
            ImGui::Text("will send the ROM to the running instance instead of");
            ImGui::Text("starting a new one.");
            ImGui::EndTooltip();
        }

        ImGui::EndMenu();
    }
}

static void menu_video(void)
{
    if (ImGui::BeginMenu("Video"))
    {
        gui_in_use = true;

        bool is_recording = emu_is_video_recording();

        if (ImGui::MenuItem("Full Screen", config_hotkeys[config_HotkeyIndex_Fullscreen].str, &config_emulator.fullscreen, !is_recording))
        {
            application_trigger_fullscreen(config_emulator.fullscreen);
        }

#if !defined(__APPLE__)
        if (ImGui::BeginMenu("Fullscreen Mode", !is_recording))
        {
            ImGui::PushItemWidth(130.0f);
            if (ImGui::Combo("##fullscreen_mode", &config_emulator.fullscreen_mode, "Borderless\0Exclusive\0\0") &&
                config_emulator.fullscreen)
            {
                application_trigger_fullscreen(true);
            }
            ImGui::PopItemWidth();
            ImGui::EndMenu();
        }
#endif

        ImGui::Separator();

        ImGui::MenuItem("Always Show Menu", config_hotkeys[config_HotkeyIndex_ShowMainMenu].str, &config_emulator.always_show_menu);
        if (ImGui::IsItemHovered())
        {
            ImGui::BeginTooltip();
            ImGui::Text("This option will enable menu even in fullscreen.");
            ImGui::Text("Menu always shows in debug mode.");
            ImGui::EndTooltip();
        }

        if (ImGui::MenuItem("Resize Window to Content", NULL, false, !is_recording))
        {
            if (!config_debug.debug)
            {
                application_trigger_fit_to_content(gui_main_window_width, gui_main_window_height + gui_main_menu_height);
            }
        }

        ImGui::Separator();

        if (ImGui::BeginMenu("Scale"))
        {
            ImGui::PushItemWidth(250.0f);
            ImGui::Combo("##scale", &config_video.scale, "Integer Scale (Auto)\0Integer Scale (Manual)\0Scale to Window Height\0Scale to Window Width & Height\0\0");
            if (config_video.scale == 1)
                ImGui::SliderInt("##scale_manual", &config_video.scale_manual, 1, 20);
            ImGui::PopItemWidth();
            ImGui::EndMenu();
        }

        if (ImGui::BeginMenu("Aspect Ratio"))
        {
            ImGui::PushItemWidth(200.0f);
            ImGui::Combo("##ratio", &config_video.ratio, "Square Pixels (1:1 PAR)\0Standard (4:3 DAR)\0Wide (16:9 DAR)\0Wide (16:10 DAR)\0\0");
            ImGui::PopItemWidth();
            ImGui::EndMenu();
        }

        draw_overscan_menu("Overscan", &config_video.overscan, true, !config_debug.debug);

        ImGui::Separator();

        if (ImGui::BeginMenu("Vertical Sync"))
        {
#if defined(_WIN32)
            ImGui::PushItemWidth(220.0f);
            if (ImGui::Combo("##sync_mode", &config_video.sync_mode, "Disabled\0Fixed Vertical Sync\0Variable Refresh Rate (VRR)\0\0"))
#else
            ImGui::PushItemWidth(100.0f);
            if (ImGui::Combo("##sync_mode", &config_video.sync_mode, "Disabled\0Enabled\0\0"))
#endif
            {
                if (config_video.sync_mode != config_VideoSync_Disabled)
                {
                    config_audio.sync = true;
                    config_emulator.ffwd = false;
                    emu_audio_reset();
                }

                display_use_vsync_if_enabled();
            }
            ImGui::PopItemWidth();

#if defined(_WIN32)
            if (ImGui::IsItemHovered())
            {
                ImGui::BeginTooltip();
                ImGui::Text("Disabled: do not synchronize presentation to the monitor.");
                ImGui::Text("Fixed Vertical Sync: use normal VSync.");
                ImGui::Text("VRR: present at the emulator frame rate.");
                ImGui::Text("\nVRR requires fullscreen, a VRR display, and G-SYNC,");
                ImGui::Text("FreeSync, or Adaptive Sync enabled in your monitor and GPU driver settings.");
                ImGui::EndTooltip();
            }
#endif
            ImGui::EndMenu();
        }

        ImGui::MenuItem("Show FPS", "", &config_video.fps);

        ImGui::Separator();

        gui_shader_menu();

        ImGui::Separator();

        if (ImGui::BeginMenu("Video Chip"))
        {
            ImGui::PushItemWidth(150.0f);
            ImGui::Combo("##video_chip", &config_video.video_chip,
                "Auto\0TMS9918A\0F18A\0\0");
            ImGui::PopItemWidth();
            ImGui::EndMenu();
        }

        if (ImGui::MenuItem("Disable Sprite Limit", "", &config_video.sprite_limit))
        {
            emu_video_no_sprite_limit(config_video.sprite_limit);
        }

        if (ImGui::BeginMenu("Palette"))
        {
            ImGui::PushItemWidth(130.0f);
            if (ImGui::Combo("##palette", &config_video.palette, "Coleco\0TMS9918\0Custom\0\0", 11))
            {
                gui_update_palette();
            }
            ImGui::PopItemWidth();
            ImGui::EndMenu();
        }

        if (ImGui::BeginMenu("Custom Palette"))
        {
            for (int i = 0; i < 16; i++)
            {
                char text[10] = {0};
                snprintf(text, sizeof(text), "Color #%d", i);
                if (ImGui::ColorEdit3(text, (float*)&gui_custom_palette[i], ImGuiColorEditFlags_NoInputs))
                {
                    gui_update_palette();
                }
            }

            ImGui::EndMenu();
        }

        ImGui::Separator();

        if (ImGui::BeginMenu("Theme"))
        {
            ImGui::PushItemWidth(100.0f);
            if (ImGui::Combo("##theme", &config_emulator.theme, "Light\0Dark\0\0"))
            {
                gui_set_style();
            }
            ImGui::PopItemWidth();
            ImGui::EndMenu();
        }

        if (ImGui::BeginMenu("Background Color"))
        {
            draw_background_color_menu("Dark Theme", config_Theme_Dark);
            draw_background_color_menu("Light Theme", config_Theme_Light);

            ImGui::EndMenu();
        }

        ImGui::EndMenu();
    }
}

static void draw_overscan_menu(const char* label, int* overscan, bool enabled, bool apply)
{
    if (ImGui::BeginMenu(label, enabled))
    {
        ImGui::PushItemWidth(150.0f);
        if (ImGui::Combo("##overscan", overscan, "Disabled\0Top+Bottom\0Full (284 width)\0Full (320 width)\0\0") && apply)
        {
            emu_set_overscan(*overscan);
        }
        ImGui::PopItemWidth();
        ImGui::EndMenu();
    }
}

static void draw_background_color_menu(const char* label, int theme)
{
    if (ImGui::BeginMenu(label))
    {
        ImGui::PushID(theme);

        ImGui::ColorEdit3("##normal_bg", config_video.background_color[theme], ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_Float);
        ImGui::SameLine();
        ImGui::Text("Normal Background");

        ImGui::Separator();

        if (ImGui::ColorEdit3("##debugger_bg", config_video.background_color_debugger[theme], ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_Float))
        {
            if (config_emulator.theme == theme)
                gui_set_style();
        }
        ImGui::SameLine();
        ImGui::Text("Debugger Background");

        ImGui::PopID();
        ImGui::EndMenu();
    }
}

static void menu_input(void)
{
    if (ImGui::BeginMenu("Input"))
    {
        gui_in_use = true;
        bool adam_running = !emu_is_empty() && emu_get_machine() == GC_MACHINE_ADAM;

        if (ImGui::MenuItem("Game Focus", config_hotkeys[config_HotkeyIndex_GameFocus].str, false, !emu_is_empty()))
            game_focus_set(true);

        if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled))
        {
            ImGui::BeginTooltip();
            ImGui::Text("Locks the mouse in the window and turns hotkeys off,");
            ImGui::Text("except Game Focus, Fullscreen and the keyboard mapper's.");
            ImGui::Text("Going fullscreen also enters it.");
            ImGui::EndTooltip();
        }

        ImGui::Separator();

        if (ImGui::BeginMenu("Keyboard Configuration"))
        {
            if (ImGui::BeginMenu("Player 1"))
            {
                ImGui::TextDisabled("Keyboard Player 1");
                ImGui::Separator();
                keyboard_configuration_item("Left:", &config_input[0].key_left, 0);
                keyboard_configuration_item("Right:", &config_input[0].key_right, 0);
                keyboard_configuration_item("Up:", &config_input[0].key_up, 0);
                keyboard_configuration_item("Down:", &config_input[0].key_down, 0);
                keyboard_configuration_item("Yellow (Left):", &config_input[0].key_left_button, 0);
                keyboard_configuration_item("Red (Right):", &config_input[0].key_right_button, 0);
                keyboard_configuration_item("Purple:", &config_input[0].key_purple, 0);
                keyboard_configuration_item("Blue:", &config_input[0].key_blue, 0);
                keyboard_configuration_item("Keypad 0:", &config_input[0].key_0, 0);
                keyboard_configuration_item("Keypad 1:", &config_input[0].key_1, 0);
                keyboard_configuration_item("Keypad 2:", &config_input[0].key_2, 0);
                keyboard_configuration_item("Keypad 3:", &config_input[0].key_3, 0);
                keyboard_configuration_item("Keypad 4:", &config_input[0].key_4, 0);
                keyboard_configuration_item("Keypad 5:", &config_input[0].key_5, 0);
                keyboard_configuration_item("Keypad 6:", &config_input[0].key_6, 0);
                keyboard_configuration_item("Keypad 7:", &config_input[0].key_7, 0);
                keyboard_configuration_item("Keypad 8:", &config_input[0].key_8, 0);
                keyboard_configuration_item("Keypad 9:", &config_input[0].key_9, 0);
                keyboard_configuration_item("Keypad *:", &config_input[0].key_asterisk, 0);
                keyboard_configuration_item("Keypad #:", &config_input[0].key_hash, 0);

                gui_popup_modal_keyboard();

                ImGui::EndMenu();
            }

            if (ImGui::BeginMenu("Player 2"))
            {
                ImGui::TextDisabled("Keyboard Player 2");
                ImGui::Separator();
                keyboard_configuration_item("Left:", &config_input[1].key_left, 1);
                keyboard_configuration_item("Right:", &config_input[1].key_right, 1);
                keyboard_configuration_item("Up:", &config_input[1].key_up, 1);
                keyboard_configuration_item("Down:", &config_input[1].key_down, 1);
                keyboard_configuration_item("Yellow (Left):", &config_input[1].key_left_button, 1);
                keyboard_configuration_item("Red (Right):", &config_input[1].key_right_button, 1);
                keyboard_configuration_item("Purple:", &config_input[1].key_purple, 1);
                keyboard_configuration_item("Blue:", &config_input[1].key_blue, 1);
                keyboard_configuration_item("Keypad 0:", &config_input[1].key_0, 1);
                keyboard_configuration_item("Keypad 1:", &config_input[1].key_1, 1);
                keyboard_configuration_item("Keypad 2:", &config_input[1].key_2, 1);
                keyboard_configuration_item("Keypad 3:", &config_input[1].key_3, 1);
                keyboard_configuration_item("Keypad 4:", &config_input[1].key_4, 1);
                keyboard_configuration_item("Keypad 5:", &config_input[1].key_5, 1);
                keyboard_configuration_item("Keypad 6:", &config_input[1].key_6, 1);
                keyboard_configuration_item("Keypad 7:", &config_input[1].key_7, 1);
                keyboard_configuration_item("Keypad 8:", &config_input[1].key_8, 1);
                keyboard_configuration_item("Keypad 9:", &config_input[1].key_9, 1);
                keyboard_configuration_item("Keypad *:", &config_input[1].key_asterisk, 1);
                keyboard_configuration_item("Keypad #:", &config_input[1].key_hash, 1);

                gui_popup_modal_keyboard();

                ImGui::EndMenu();
            }

            ImGui::EndMenu();
        }

        ImGui::Separator();

        if (ImGui::BeginMenu("Gamepads"))
        {
            if (ImGui::BeginMenu("Player 1"))
            {
                if (adam_running)
                    ImGui::TextDisabled("Connection: ADAM > Controller 1");
                else
                    ImGui::MenuItem("Enable Gamepad P1", "", &config_input[0].gamepad);

                if (ImGui::BeginMenu("Device"))
                {
                    gamepad_device_selector(0);
                    ImGui::EndMenu();
                }

                if (ImGui::BeginMenu("Directional Controls"))
                {
                    ImGui::PushItemWidth(200.0f);
                    ImGui::Combo("##directional", &config_input[0].gamepad_directional,
                        "D-pad\0Left Analog Stick\0D-pad + Left Analog Stick\0\0");
                    ImGui::PopItemWidth();
                    ImGui::EndMenu();
                }

                if (ImGui::BeginMenu("Button Configuration"))
                {
                    ImGui::TextDisabled("Gamepad Player 1");
                    ImGui::Separator();
                    gamepad_configuration_item("Yellow (Left):", &config_input[0].gamepad_left_button, 0);
                    gamepad_configuration_item("Red (Right):", &config_input[0].gamepad_right_button, 0);
                    gamepad_configuration_item("Purple:", &config_input[0].gamepad_purple, 0);
                    gamepad_configuration_item("Blue:", &config_input[0].gamepad_blue, 0);
                    gamepad_configuration_item("Keypad 0:", &config_input[0].gamepad_0, 0);
                    gamepad_configuration_item("Keypad 1:", &config_input[0].gamepad_1, 0);
                    gamepad_configuration_item("Keypad 2:", &config_input[0].gamepad_2, 0);
                    gamepad_configuration_item("Keypad 3:", &config_input[0].gamepad_3, 0);
                    gamepad_configuration_item("Keypad 4:", &config_input[0].gamepad_4, 0);
                    gamepad_configuration_item("Keypad 5:", &config_input[0].gamepad_5, 0);
                    gamepad_configuration_item("Keypad 6:", &config_input[0].gamepad_6, 0);
                    gamepad_configuration_item("Keypad 7:", &config_input[0].gamepad_7, 0);
                    gamepad_configuration_item("Keypad 8:", &config_input[0].gamepad_8, 0);
                    gamepad_configuration_item("Keypad 9:", &config_input[0].gamepad_9, 0);
                    gamepad_configuration_item("Asterisk:", &config_input[0].gamepad_asterisk, 0);
                    gamepad_configuration_item("Hash:", &config_input[0].gamepad_hash, 0);

                    gui_popup_modal_gamepad(0);

                    ImGui::EndMenu();
                }

                if (ImGui::BeginMenu("Shortcut Configuration"))
                {
                    ImGui::TextDisabled("Gamepad Player 1 - Shortcuts");
                    ImGui::Separator();

                    for (int i = 0; i < config_HotkeyIndex_COUNT; i++)
                    {
                        if ((hotkey_definitions[i].flags & HOTKEY_FLAG_GAMEPAD) == 0)
                            continue;

                        char label[64];
                        snprintf(label, sizeof(label), "%s:", hotkey_definitions[i].label);
                        gamepad_configuration_item(label, &config_input_gamepad_shortcuts[0].gamepad_shortcuts[i], 0);
                    }

                    gui_popup_modal_gamepad(0);

                    ImGui::EndMenu();
                }

                ImGui::EndMenu();
            }

            if (ImGui::BeginMenu("Player 2"))
            {
                if (adam_running)
                    ImGui::TextDisabled("Connection: ADAM > Controller 2");
                else
                    ImGui::MenuItem("Enable Gamepad P2", "", &config_input[1].gamepad);

                if (ImGui::BeginMenu("Device"))
                {
                    gamepad_device_selector(1);
                    ImGui::EndMenu();
                }

                if (ImGui::BeginMenu("Directional Controls"))
                {
                    ImGui::PushItemWidth(200.0f);
                    ImGui::Combo("##directional", &config_input[1].gamepad_directional,
                        "D-pad\0Left Analog Stick\0D-pad + Left Analog Stick\0\0");
                    ImGui::PopItemWidth();
                    ImGui::EndMenu();
                }

                if (ImGui::BeginMenu("Button Configuration"))
                {
                    ImGui::TextDisabled("Gamepad Player 2");
                    ImGui::Separator();
                    gamepad_configuration_item("Yellow (Left):", &config_input[1].gamepad_left_button, 1);
                    gamepad_configuration_item("Red (Right):", &config_input[1].gamepad_right_button, 1);
                    gamepad_configuration_item("Purple:", &config_input[1].gamepad_purple, 1);
                    gamepad_configuration_item("Blue:", &config_input[1].gamepad_blue, 1);
                    gamepad_configuration_item("Keypad 0:", &config_input[1].gamepad_0, 1);
                    gamepad_configuration_item("Keypad 1:", &config_input[1].gamepad_1, 1);
                    gamepad_configuration_item("Keypad 2:", &config_input[1].gamepad_2, 1);
                    gamepad_configuration_item("Keypad 3:", &config_input[1].gamepad_3, 1);
                    gamepad_configuration_item("Keypad 4:", &config_input[1].gamepad_4, 1);
                    gamepad_configuration_item("Keypad 5:", &config_input[1].gamepad_5, 1);
                    gamepad_configuration_item("Keypad 6:", &config_input[1].gamepad_6, 1);
                    gamepad_configuration_item("Keypad 7:", &config_input[1].gamepad_7, 1);
                    gamepad_configuration_item("Keypad 8:", &config_input[1].gamepad_8, 1);
                    gamepad_configuration_item("Keypad 9:", &config_input[1].gamepad_9, 1);
                    gamepad_configuration_item("Asterisk:", &config_input[1].gamepad_asterisk, 1);
                    gamepad_configuration_item("Hash:", &config_input[1].gamepad_hash, 1);

                    gui_popup_modal_gamepad(1);

                    ImGui::EndMenu();
                }

                if (ImGui::BeginMenu("Shortcut Configuration"))
                {
                    ImGui::TextDisabled("Gamepad Player 2 - Shortcuts");
                    ImGui::Separator();

                    for (int i = 0; i < config_HotkeyIndex_COUNT; i++)
                    {
                        if ((hotkey_definitions[i].flags & HOTKEY_FLAG_GAMEPAD) == 0)
                            continue;

                        char label[64];
                        snprintf(label, sizeof(label), "%s:", hotkey_definitions[i].label);
                        gamepad_configuration_item(label, &config_input_gamepad_shortcuts[1].gamepad_shortcuts[i], 1);
                    }

                    gui_popup_modal_gamepad(1);

                    ImGui::EndMenu();
                }

                ImGui::EndMenu();
            }

            ImGui::EndMenu();
        }

        ImGui::Separator();

        if (ImGui::BeginMenu("Spinners"))
        {
            ImGui::Combo("##spinner", &config_emulator.spinner, "Disabled\0Super Action Controller\0Steering Wheel\0Roller Controller\0\0", 4);
            if (ImGui::IsItemHovered())
            {
                ImGui::SetTooltip("MAKE SURE THIS IS DISABLED FOR NORMAL GAMES\n\n - SAC Spinner for P1 is controlled with mouse movement.\n - SAC Spinner for P2 is controlled with mouse wheel.\n - Steering Wheel is controlled with mouse movement.\n - Roller Controller is controlled with mouse movement and mouse buttons.");
            }
            ImGui::SliderInt("##spinner_sensitivity", &config_emulator.spinner_sensitivity, 1, 10, "Sensitivity = %d");

            ImGui::EndMenu();
        }

        ImGui::Separator();

        bool allow_up_down = config_input[0].allow_up_down && config_input[1].allow_up_down;

        if (ImGui::MenuItem("Allow Up+Down / Left+Right", "", &allow_up_down))
        {
            for (int i = 0; i < GC_MAX_GAMEPADS; i++)
                config_input[i].allow_up_down = allow_up_down;
        }
        if (ImGui::IsItemHovered())
        {
            ImGui::BeginTooltip();
            ImGui::Text("Allow pressing, quickly alternating, or holding");
            ImGui::Text("both left and right or up and down directions.");
            ImGui::Text("This may cause movement glitches in certain games.");
            ImGui::EndTooltip();
        }

        if (ImGui::MenuItem("Allow Shared Gamepads", "", &config_emulator.allow_shared_gamepads))
        {
            if (!config_emulator.allow_shared_gamepads)
                gamepad_remove_duplicates();
        }
        if (ImGui::IsItemHovered())
        {
            ImGui::BeginTooltip();
            ImGui::Text("Let one gamepad control several players at the same time.");
            ImGui::Text("Choose it in the Device menu of each player.");
            ImGui::EndTooltip();
        }

        ImGui::EndMenu();
    }
}

static void menu_audio(void)
{
    if (ImGui::BeginMenu("Audio"))
    {
        gui_in_use = true;

        bool mute = !config_audio.enable;

        if (ImGui::MenuItem("Mute All Audio", config_hotkeys[config_HotkeyIndex_Mute].str, &mute))
        {
            config_audio.enable = !mute;
            emu_audio_mute(mute);
        }

        // if (ImGui::MenuItem("Sync With Emulator", "", &config_audio.sync))
        // {
        //     config_emulator.ffwd = false;

        //     if (!config_audio.sync)
        //     {
        //         config_video.sync_mode = config_VideoSync_Disabled;
        //         display_disable_vsync();
        //     }
        // }

        ImGui::Separator();

        if (ImGui::BeginMenu("Master Volume", config_audio.enable))
        {
            ImGui::PushItemWidth(200.0f);
            if (ImGui::SliderFloat("##master_volume", &config_audio.master_volume, 0.0f, 2.0f, "Volume = %.2f", ImGuiSliderFlags_AlwaysClamp))
            {
                emu_audio_set_master_volume(config_audio.master_volume);
            }
            ImGui::PopItemWidth();
            if (ImGui::IsItemHovered())
            {
                ImGui::BeginTooltip();
                ImGui::Text("Anything above 1.00 may cause clipping.");
                ImGui::EndTooltip();
            }
            ImGui::EndMenu();
        }

        ImGui::Separator();

        if (ImGui::BeginMenu("Buffer Size", config_audio.enable))
        {
            ImGui::PushItemWidth(150.0f);
            if (ImGui::SliderInt("##buffer_count", &config_audio.buffer_count, 2, 5, "Buffers = %d"))
            {
                emu_audio_restart();
            }
            ImGui::PopItemWidth();
            if (ImGui::IsItemHovered())
            {
                ImGui::BeginTooltip();
                ImGui::Text("Audio latency: %.0f ms", sound_queue_get_target_latency_ms());
                ImGui::Text("\nLower values reduce audio latency.");
                ImGui::Text("Higher values prevent audio underruns.");
                ImGui::Text("Enabling VSync may force higher buffer counts.");

                ImGui::EndTooltip();
            }
            ImGui::EndMenu();
        }

#ifndef GEARCOLECO_DISABLE_VGMRECORDER
        ImGui::Separator();

        if (ImGui::BeginMenu("VGM Recorder"))
        {
            bool is_recording = emu_is_vgm_recording();

            if (ImGui::MenuItem("Start Recording...", "", false, !is_recording && !emu_is_empty()))
            {
                save_vgm = true;
            }

            if (ImGui::MenuItem("Stop Recording", "", false, is_recording))
            {
                emu_stop_vgm_recording();
                gui_notify(gui_NotificationInfo, ICON_MD_STOP, "VGM recording stopped", NULL, "vgm");
            }

            ImGui::EndMenu();
        }
#endif

        ImGui::EndMenu();
    }
}

static void menu_debug(void)
{
#if !defined(GEARCOLECO_DISABLE_DISASSEMBLER)
    if (ImGui::BeginMenu("Debug"))
    {
        gui_in_use = true;

        if (ImGui::MenuItem("Enable", "", &config_debug.debug))
        {
            emu_set_overscan(config_debug.debug ? config_debug.overscan : config_video.overscan);

            if (config_debug.debug)
                emu_debug_step_over();
            else
                emu_debug_continue();
        }

        ImGui::Separator();

        if (ImGui::MenuItem("Save Debug Settings...", "", false, config_debug.debug))
        {
            save_debug_settings = true;
        }

        if (ImGui::MenuItem("Load Debug Settings...", "", false, config_debug.debug))
        {
            load_debug_settings = true;
        }

        ImGui::MenuItem("Auto Save/Load Debug Settings", "", &config_debug.auto_debug_settings, config_debug.debug);

        ImGui::Separator();

        if (ImGui::MenuItem(emu_get_machine() == GC_MACHINE_ADAM ? "Computer Reset" : "Reload ROM", config_hotkeys[config_HotkeyIndex_ReloadROM].str, false, config_debug.debug && !emu_is_empty()))
        {
            gui_action_reload_rom();
        }

        ImGui::Separator();

        if (ImGui::BeginMenu("MCP Server", config_debug.debug))
        {
            bool mcp_running = emu_mcp_is_running();
            int transport_mode = emu_mcp_get_transport_mode();
            bool http_running = mcp_running && (transport_mode == 1);
            bool stdio_running = mcp_running && (transport_mode == 0);

            if (ImGui::MenuItem("Start HTTP Server", "", false, !mcp_running))
            {
                if (strlen(gui_mcp_http_address) == 0)
                    strncpy_fit(gui_mcp_http_address, "127.0.0.1", sizeof(gui_mcp_http_address));
                config_emulator.mcp_http_address = gui_mcp_http_address;
                emu_mcp_set_transport(1, config_emulator.mcp_tcp_port, config_emulator.mcp_http_address.c_str());
                emu_mcp_start();
            }

            if (ImGui::MenuItem("Stop HTTP Server", "", false, http_running))
            {
                emu_mcp_stop();
            }

            ImGui::Separator();

            if (stdio_running)
                ImGui::TextColored(service_mcp_stdio_color, "STDIO mode active");
            else if (http_running)
                ImGui::TextColored(service_mcp_http_color, "Listening on %s:%d",
                    emu_mcp_get_http_address(), emu_mcp_get_http_port());
            else
                ImGui::TextColored(red, "Stopped");

            ImGui::Separator();

            ImGui::Text("HTTP Address:");
            ImGui::SameLine();
            ImGui::SetNextItemWidth(120);
            if (ImGui::InputText("##mcp_address", gui_mcp_http_address, IM_ARRAYSIZE(gui_mcp_http_address), ImGuiInputTextFlags_AutoSelectAll))
                config_emulator.mcp_http_address = gui_mcp_http_address;

            ImGui::Text("HTTP Port:");
            ImGui::SameLine();
            ImGui::SetNextItemWidth(50);
            if (ImGui::InputInt("##mcp_port", &config_emulator.mcp_tcp_port, 0, 0))
            {
                if (config_emulator.mcp_tcp_port < 1)
                    config_emulator.mcp_tcp_port = 1;
                if (config_emulator.mcp_tcp_port > 65535)
                    config_emulator.mcp_tcp_port = 65535;
            }

            ImGui::EndMenu();
        }

        ImGui::Separator();

        if (ImGui::BeginMenu("Debug Output Screen", config_debug.debug))
        {
            ImGui::MenuItem("Show Output Screen", "", &config_debug.show_screen, config_debug.debug);

            if (ImGui::BeginMenu("Scale", config_debug.debug))
            {
                ImGui::PushItemWidth(200.0f);
                ImGui::SliderInt("##debug_scale", &config_debug.scale, 1, 10);
                ImGui::PopItemWidth();
                ImGui::EndMenu();
            }

            draw_overscan_menu("Overscan", &config_debug.overscan, config_debug.debug, config_debug.debug);

            ImGui::EndMenu();
        }

        ImGui::Separator();

        ImGui::MenuItem("Show Disassembler", "", &config_debug.show_disassembler, config_debug.debug);
        ImGui::MenuItem("Show Memory Editor", "", &config_debug.show_memory, config_debug.debug);
        ImGui::MenuItem("Show Trace Logger", "", &config_debug.show_trace_logger, config_debug.debug);

        ImGui::Separator();

        if (ImGui::BeginMenu("CPU", config_debug.debug))
        {
            ImGui::MenuItem("Show Z80", "", &config_debug.show_processor);
            ImGui::MenuItem("Show Call Stack", "", &config_debug.show_call_stack);
            ImGui::MenuItem("Show Breakpoints", "", &config_debug.show_breakpoints);
            ImGui::MenuItem("Show Symbols", "", &config_debug.show_symbols);
            ImGui::MenuItem("Show Profiler", "", &config_debug.show_profiler);
            ImGui::EndMenu();
        }

        if (ImGui::BeginMenu("Video", config_debug.debug))
        {
            bool f18a_active = emu_get_core()->GetVideoChip() == GC_VIDEO_CHIP_F18A;

            if (ImGui::BeginMenu("TMS9918A"))
            {
                ImGui::MenuItem("Show Name Table", "", &config_debug.show_tms9918a_nametable,
                    !f18a_active);
                ImGui::MenuItem("Show Pattern Table", "", &config_debug.show_tms9918a_patterns,
                    !f18a_active);
                ImGui::MenuItem("Show Sprites", "", &config_debug.show_tms9918a_sprites,
                    !f18a_active);
                ImGui::MenuItem("Show Palettes", "", &config_debug.show_tms9918a_palettes,
                    !f18a_active);
                ImGui::MenuItem("Show Registers", "", &config_debug.show_tms9918a_regs,
                    !f18a_active);
                ImGui::EndMenu();
            }

            if (ImGui::BeginMenu("F18A"))
            {
                ImGui::MenuItem("Show Name Tables", "", &config_debug.show_f18a_nametables,
                    f18a_active);
                ImGui::MenuItem("Show Pattern Table", "", &config_debug.show_f18a_patterns,
                    f18a_active);
                ImGui::MenuItem("Show Sprites", "", &config_debug.show_f18a_sprites,
                    f18a_active);
                ImGui::MenuItem("Show Palette RAM", "", &config_debug.show_f18a_palette,
                    f18a_active);
                ImGui::MenuItem("Show Registers", "", &config_debug.show_f18a_regs,
                    f18a_active);
                ImGui::MenuItem("Show Extended Registers", "",
                    &config_debug.show_f18a_extended_regs, f18a_active);
                ImGui::EndMenu();
            }

            ImGui::EndMenu();
        }

        if (ImGui::BeginMenu("Audio", config_debug.debug))
        {
            ImGui::MenuItem("Show PSG", "", &config_debug.show_psg, config_debug.debug);
            bool adam_running = !emu_is_empty() && (emu_get_machine() == GC_MACHINE_ADAM);
            ImGui::MenuItem("Show AY-3-8910 (SGM)", "", &config_debug.show_ay8910,
                config_debug.debug && !adam_running);
            if (adam_running && ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled))
                ImGui::SetTooltip("The SGM AY-3-8910 is not part of the ADAM runtime.");
            ImGui::EndMenu();
        }

        if (ImGui::BeginMenu("ADAM", config_debug.debug))
        {
            ImGui::BeginDisabled(emu_is_empty() || emu_get_machine() != GC_MACHINE_ADAM);
            ImGui::MenuItem("Show Ports", "", &config_debug.show_adam_system);
            ImGui::MenuItem("Show ADAMnet", "", &config_debug.show_adam_net);
            ImGui::EndDisabled();
            ImGui::EndMenu();
        }

        ImGui::Separator();

        ImGui::MenuItem("Show Rewind", "", &config_debug.show_rewind, config_debug.debug);

#if defined(__APPLE__) || defined(_WIN32)
        ImGui::Separator();
        ImGui::MenuItem("Multi-Viewport", "", &config_debug.multi_viewport, config_debug.debug);
        if (ImGui::IsItemHovered())
        {
            ImGui::BeginTooltip();
            ImGui::Text("RESTART REQUIRED");
            ImGui::NewLine();
            ImGui::Text("Enables docking of debug windows outside of main window.");
            ImGui::EndTooltip();
        }
#endif

        ImGui::Separator();

        if (ImGui::BeginMenu("Font", config_debug.debug))
        {
            if (ImGui::BeginMenu("Type"))
            {
                ImGui::PushItemWidth(140.0f);
                if (ImGui::Combo("##font_type", &config_debug.font_type, "ProggyForever\0ProggyClean\0\0"))
                {
                    gui_default_font = gui_default_fonts[config_debug.font_type][config_debug.font_size];
                }
                ImGui::PopItemWidth();
                ImGui::EndMenu();
            }

            if (ImGui::BeginMenu("Size"))
            {
                ImGui::PushItemWidth(110.0f);
                if (ImGui::Combo("##font_size", &config_debug.font_size, "Small\0Medium\0Big\0Large\0\0"))
                {
                    gui_default_font = gui_default_fonts[config_debug.font_type][config_debug.font_size];
                }
                ImGui::PopItemWidth();
                ImGui::EndMenu();
            }

            ImGui::EndMenu();
        }

        ImGui::EndMenu();
    }
#endif
}

static void menu_about(void)
{
    if (ImGui::BeginMenu("About"))
    {
        gui_in_use = true;

        if (ImGui::MenuItem("About " GEARCOLECO_TITLE " " GEARCOLECO_VERSION " ..."))
        {
            open_about = true;
        }
        ImGui::EndMenu();
    }
}

static void draw_mcp_status(void)
{
    bool video_recording = emu_is_video_recording();
    bool vgm_recording = emu_is_vgm_recording();
    bool mcp_running = emu_mcp_is_running();

    if (!video_recording && !vgm_recording && !mcp_running)
        return;

    const char* video_recording_status = "REC VIDEO";
    const char* vgm_recording_status = "REC VGM";
    char mcp_status[128];
    bool show_mcp = false;
    ImVec4 mcp_color = service_mcp_http_color;

    if (mcp_running)
    {
        int transport_mode = emu_mcp_get_transport_mode();
        if (transport_mode == 0)
        {
            snprintf(mcp_status, sizeof(mcp_status), "MCP: STDIO");
            mcp_color = service_mcp_stdio_color;
            show_mcp = true;
        }
        else if (transport_mode == 1)
        {
            snprintf(mcp_status, sizeof(mcp_status), "MCP: HTTP (%s:%d)", config_emulator.mcp_http_address.c_str(), config_emulator.mcp_tcp_port);
            show_mcp = true;
        }
    }

    ImGuiStyle& style = ImGui::GetStyle();
    float spacing = style.ItemSpacing.x * 2.0f;
    float dot_radius = ImGui::GetFontSize() * 0.22f;
    float dot_width = (dot_radius * 2.0f) + style.ItemInnerSpacing.x;
    float text_width = 0.0f;

    if (video_recording)
        text_width += dot_width + ImGui::CalcTextSize(video_recording_status).x;
    if (vgm_recording)
    {
        if (text_width > 0.0f)
            text_width += spacing;
        text_width += dot_width + ImGui::CalcTextSize(vgm_recording_status).x;
    }
    if (show_mcp)
    {
        if (text_width > 0.0f)
            text_width += spacing;
        text_width += ImGui::CalcTextSize(mcp_status).x;
    }

    float status_x = ImGui::GetWindowWidth() - text_width - style.ItemSpacing.x - 10.0f;
    float cursor_x = ImGui::GetCursorPosX();

    if (status_x <= cursor_x + style.ItemSpacing.x)
        return;

    ImGui::SameLine(status_x);
    ImGui::AlignTextToFramePadding();

    if (video_recording)
        draw_recording_status(video_recording_status, video_recording_color, dot_radius, dot_width);

    if (vgm_recording)
    {
        if (video_recording)
            ImGui::SameLine(0.0f, spacing);

        draw_recording_status(vgm_recording_status, vgm_recording_color, dot_radius, dot_width);
    }

    if (show_mcp)
    {
        if (video_recording || vgm_recording)
            ImGui::SameLine(0.0f, spacing);

        ImGui::TextColored(mcp_color, "%s", mcp_status);
    }
}

static void draw_recording_status(const char* status, ImVec4 color, float dot_radius, float dot_width)
{
    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + dot_width);
    ImGui::TextColored(color, "%s", status);

    ImVec2 text_min = ImGui::GetItemRectMin();
    ImVec2 text_max = ImGui::GetItemRectMax();
    ImVec2 dot_center = ImVec2(text_min.x - dot_width + dot_radius, (text_min.y + text_max.y) * 0.5f);
    ImGui::GetWindowDrawList()->AddCircleFilled(dot_center, dot_radius, ImGui::GetColorU32(color));
}

static void file_dialogs(void)
{
    gui_file_dialog_process_results();

    if (open_rom || gui_shortcut_open_rom)
    {
        gui_shortcut_open_rom = false;
        if (emu_is_bios_loaded())
            gui_file_dialog_open_rom();
        else
            gui_adam_open_missing_firmware(false);
    }
    if (open_adam_cartridge)
        gui_file_dialog_open_rom(true);
    if (open_ram)
        gui_file_dialog_load_ram();
    if (save_ram)
        gui_file_dialog_save_ram();
    if (open_state)
        gui_file_dialog_load_state();
    if (save_state)
        gui_file_dialog_save_state();
    if (save_screenshot)
        gui_file_dialog_save_screenshot();
    if (save_vgm)
        gui_file_dialog_save_vgm();
    if (save_video)
        gui_file_dialog_save_video();
    if (choose_savestates_path)
        gui_file_dialog_choose_savestate_path();
    if (choose_screenshots_path)
        gui_file_dialog_choose_screenshot_path();
    if (choose_video_recordings_path)
        gui_file_dialog_choose_video_recording_path();
    if (choose_backup_ram_path)
        gui_file_dialog_choose_saves_path();
    if (save_debug_settings)
        gui_file_dialog_save_debug_settings();
    if (load_debug_settings)
        gui_file_dialog_load_debug_settings();
    if (open_about)
    {
        gui_dialog_in_use = true;
        ImGui::OpenPopup("About " GEARCOLECO_TITLE);
    }

    if (open_load_defaults)
    {
        gui_dialog_in_use = true;
        ImGui::OpenPopup("Load Default Settings");
    }

    gui_popup_modal_about();
    gui_popup_modal_load_defaults();
}

static void keyboard_configuration_item(const char* text, SDL_Scancode* key, int player)
{
    ImGui::Text("%s", text);
    ImGui::SameLine(120);

    char button_label[256];
    snprintf(button_label, 256, "%s##%s%d", SDL_GetKeyName(SDL_GetKeyFromScancode(*key, SDL_KMOD_NONE, false)), text, player);

    if (ImGui::Button(button_label, ImVec2(90,0)))
    {
        gui_configured_key = key;
        ImGui::OpenPopup("Keyboard Configuration");
    }

    ImGui::SameLine();

    char remove_label[256];
    snprintf(remove_label, sizeof(remove_label), "X##rk%s%d", text, player);

    if (ImGui::Button(remove_label))
    {
        *key = SDL_SCANCODE_UNKNOWN;
    }
}

static void gamepad_configuration_item(const char* text, int* button, int player)
{
    ImGui::Text("%s", text);
    ImGui::SameLine(130);

    const char* button_name = "";

    if (*button == SDL_GAMEPAD_BUTTON_INVALID)
    {
        button_name = "";
    }
    else if (*button >= 0 && *button < SDL_GAMEPAD_BUTTON_COUNT)
    {
        static const char* gamepad_names[21] = {"A", "B", "X" ,"Y", "BACK", "GUIDE", "START", "L3", "R3", "L1", "R1", "UP", "DOWN", "LEFT", "RIGHT", "MISC", "PAD1", "PAD2", "PAD3", "PAD4", "TOUCH"};
        button_name = gamepad_names[*button];
    }
    else if (*button >= GAMEPAD_VBTN_AXIS_BASE)
    {
        int axis = *button - GAMEPAD_VBTN_AXIS_BASE;
        if (axis == SDL_GAMEPAD_AXIS_LEFT_TRIGGER)
            button_name = "L2";
        else if (axis == SDL_GAMEPAD_AXIS_RIGHT_TRIGGER)
            button_name = "R2";
        else
            button_name = "??";
    }

    char button_label[256];
    snprintf(button_label, sizeof(button_label), "%s##%s%d", button_name, text, player);

    if (ImGui::Button(button_label, ImVec2(70,0)))
    {
        gui_configured_button = button;
        ImGui::OpenPopup("Gamepad Configuration");
    }

    ImGui::SameLine();

    char remove_label[256];
    snprintf(remove_label, sizeof(remove_label), "X##rg%s%d", text, player);

    if (ImGui::Button(remove_label))
    {
        *button = SDL_GAMEPAD_BUTTON_INVALID;
    }
}

static void hotkey_configuration_item(const char* text, config_Hotkey* hotkey)
{
    ImGui::Text("%s", text);
    ImGui::SameLine(200);

    char button_label[256];
    snprintf(button_label, sizeof(button_label), "%s##%s", hotkey->str[0] != '\0' ? hotkey->str : "<None>", text);

    if (ImGui::Button(button_label, ImVec2(150,0)))
    {
        gui_configured_hotkey = hotkey;
        ImGui::OpenPopup("Hotkey Configuration");
    }

    ImGui::SameLine();

    char remove_label[256];
    snprintf(remove_label, sizeof(remove_label), "X##rh%s", text);

    if (ImGui::Button(remove_label))
    {
        hotkey->key = SDL_SCANCODE_UNKNOWN;
        hotkey->mod = SDL_KMOD_NONE;
        config_update_hotkey_string(hotkey);
    }
}

static void hotkey_configuration_menu(bool debug)
{
    for (int i = 0; i < config_HotkeyIndex_COUNT; i++)
    {
        if (((hotkey_definitions[i].flags & HOTKEY_FLAG_DEBUG) != 0) != debug)
            continue;

        char label[64];
        snprintf(label, sizeof(label), "%s:", hotkey_definitions[i].label);
        hotkey_configuration_item(label, &config_hotkeys[i]);
    }

    ImGui::Separator();

    if (ImGui::MenuItem("Reset to Defaults"))
        hotkeys_reset_defaults(debug);

    gui_popup_modal_hotkey();
}

static void gamepad_device_selector(int player)
{
    if (player < 0 || player >= GC_MAX_GAMEPADS)
        return;

    const int max_detected_gamepads = 32;
    SDL_JoystickID id_map[max_detected_gamepads];
    id_map[0] = 0;
    int count = 1;

    std::string items;
    items.reserve(4096);
    items.append("<None>");
    items.push_back('\0');
    float text_width = ImGui::CalcTextSize("<None>").x;

    Gamepad_Detected_Info detected[max_detected_gamepads];
    int num_detected = gamepad_get_detected(detected, max_detected_gamepads);

    SDL_JoystickID current_id = 0;
    if (IsValidPointer(gamepad_controller[player]))
        current_id = SDL_GetJoystickID(SDL_GetGamepadJoystick(gamepad_controller[player]));

    int selected = 0;

    for (int i = 0; i < num_detected && count < max_detected_gamepads; i++)
    {
        const char* name = detected[i].name;
        if (!IsValidPointer(name))
            name = "Unknown Gamepad";

        id_map[count] = detected[i].id;

        if (current_id == detected[i].id)
            selected = count;

        size_t len = strlen(detected[i].guid_str);
        const char* id_8 = detected[i].guid_str + (len > 8 ? len - 8 : 0);

        char label[192];
        snprintf(label, sizeof(label), "%s (ID: %s)", name, id_8);

        items.append(label);
        items.push_back('\0');
        text_width = MAX(text_width, ImGui::CalcTextSize(label).x);
        count++;
    }

    items.push_back('\0');

    char label[32];
    snprintf(label, sizeof(label), "##device_player%d", player + 1);

    ImGui::PushItemWidth(text_width + (ImGui::GetStyle().FramePadding.x * 2.0f) + ImGui::GetFrameHeight());

    if (ImGui::Combo(label, &selected, items.c_str()))
    {
        SDL_JoystickID instance_id = id_map[selected];
        gamepad_assign(player, instance_id);
    }

    ImGui::PopItemWidth();
}

static void draw_savestate_slot_info(int slot)
{
    if (emu_savestates[slot].rom_name[0] != 0)
    {
        if (emu_savestates[slot].version < GC_SAVESTATE_MIN_VERSION || emu_savestates[slot].version > GC_SAVESTATE_VERSION)
        {
            if (emu_savestates[slot].version == GC_SAVESTATE_VERSION_V1)
            {
                ImGui::TextColored(yellow, "This save state is from an older version");
            }
            else
            {
                ImGui::TextColored(red, "This save state is from an older version and will not work");
                if (emu_savestates[slot].emu_build[0] != 0)
                    ImGui::TextColored(red, "Use %s - %s", GEARCOLECO_TITLE, emu_savestates[slot].emu_build);
            }
            ImGui::Separator();
        }

        ImGui::Text("%s", emu_savestates[slot].rom_name);
        char date[64];
        get_date_time_string(emu_savestates[slot].timestamp, date, sizeof(date));
        ImGui::Text("%s", date);

        if (IsValidPointer(emu_savestates_screenshots[slot].data))
        {
            float width = (float)emu_savestates_screenshots[slot].width;
            float height = (float)emu_savestates_screenshots[slot].height;
            ImGui::Image((ImTextureID)(intptr_t)ogl_renderer_emu_savestates, ImVec2((height / 3.0f) * 4.0f, height), ImVec2(0, 0), ImVec2(width / (float)SYSTEM_TEXTURE_WIDTH, height / (float)SYSTEM_TEXTURE_HEIGHT));
        }
    }
    else
    {
        ImGui::TextColored(gray, "Slot %d is empty", slot + 1);
    }
}
