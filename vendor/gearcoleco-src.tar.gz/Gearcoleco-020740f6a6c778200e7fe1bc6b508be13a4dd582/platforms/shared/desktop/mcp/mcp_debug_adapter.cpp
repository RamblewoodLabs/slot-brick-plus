/*
 * Gearcoleco - ColecoVision Emulator
 * Copyright (C) 2013  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#include "mcp_debug_adapter.h"
#include "Adam.h"
#include "AdamNet.h"
#include "F18AGPU.h"
#include "Input.h"
#include "KeyMap.h"
#include "KeyMapper.h"
#include "log.h"
#include "../utils.h"
#include "../emu.h"
#include "../gui.h"
#include "../gui_actions.h"
#include "../gui_adam.h"
#include "../gui_debug_disassembler.h"
#include "../gui_debug_memory.h"
#include "../gui_debug_memeditor.h"
#include "../gui_debug_rewind.h"
#include "../gui_debug_trace_logger.h"
#include "../gui_debug_profiler.h"
#include "../trace_logger_formatter.h"
#include "../config.h"
#include "../events.h"
#include "../rewind.h"
#include "../video_recorder.h"
#include "../runahead.h"
#include <cstring>
#include <cctype>
#include <cmath>
#include <sstream>
#include <iomanip>
#include <vector>
#include <algorithm>

struct DisassemblerBookmark
{
    u16 address;
    char name[32];
};

static std::string AdamHex(u64 value, int width)
{
    std::ostringstream text;
    text << std::hex << std::uppercase << std::setfill('0') << std::setw(width) << value;
    return text.str();
}

static const char* AdamMemorySourceName(int source)
{
    switch ((Adam::MemorySource)source)
    {
        case Adam::MemorySourceRAM: return "ram";
        case Adam::MemorySourceOS7: return "os7";
        case Adam::MemorySourceEOS: return "eos";
        case Adam::MemorySourceSmartWriter: return "smartwriter";
        case Adam::MemorySourceCartridge: return "cartridge";
        case Adam::MemorySourceOpenBus:
        default: return "open_bus";
    }
}

static const char* AdamControllerStateName(int state)
{
    switch ((GC_AdamNetControllerState)state)
    {
        case GC_ADAMNET_CONTROLLER_INITIALIZING: return "initializing";
        case GC_ADAMNET_CONTROLLER_IDLE: return "idle";
        case GC_ADAMNET_CONTROLLER_BUSY: return "busy";
        default: return "unknown";
    }
}

static const char* AdamCommandStatusName(u8 value)
{
    switch (value)
    {
        case AdamNet::CommandIdle: return "idle";
        case AdamNet::CommandStatus: return "status";
        case AdamNet::CommandSoftReset: return "soft_reset";
        case AdamNet::CommandWrite: return "write";
        case AdamNet::CommandRead: return "read";
        case AdamNet::ResponseSuccess: return "success";
        case AdamNet::ResponsePrinterBusy: return "printer_busy";
        case AdamNet::ResponseKeyboardEmpty: return "keyboard_empty";
        case AdamNet::ResponseDeviceError: return "device_error";
        case AdamNet::ResponseTimeout: return "timeout";
        default: return (value >= 0x80) && (value <= 0x85) ? "pcb_response" : "unknown";
    }
}

static const char* AdamMediaTypeName(int type)
{
    switch ((GC_AdamMediaType)type)
    {
        case GC_ADAM_MEDIA_DATA_PACK: return "data_pack";
        case GC_ADAM_MEDIA_DISK: return "disk";
        case GC_ADAM_MEDIA_NONE:
        default: return "none";
    }
}

static const char* AdamContentTypeName(int type)
{
    switch ((GC_ContentType)type)
    {
        case GC_CONTENT_CARTRIDGE: return "cartridge";
        case GC_CONTENT_ADAM_DATA_PACK: return "data_pack";
        case GC_CONTENT_ADAM_DISK: return "disk";
        case GC_CONTENT_NONE:
        default: return "none";
    }
}

static const char* AdamDCBDeviceTypeName(u8 type)
{
    if (type == 0)
        return "character";
    if (type == 1)
        return "block";
    return "unknown";
}

static u8 AdamNodeStatusValue(u8 value, u8 device_id)
{
    const AdamNet::DeviceMetadata* device = AdamNet::GetDeviceMetadata(device_id);
    u8 shift = IsValidPointer(device) ? device->status_shift : 0;
    return (value >> shift) & 0x0F;
}

static const char* AdamNodeStatusName(u8 value)
{
    switch (value)
    {
        case 0: return "ready";
        case 1: return "crc_error";
        case 2: return "block_not_found";
        case 3: return "no_media";
        case 4: return "no_device";
        case 5: return "write_protected";
        default: return "unknown";
    }
}

static const char* AdamMediaSlotName(int slot)
{
    static const char* names[GC_ADAM_MEDIA_SLOT_COUNT] =
    {
        "disk_1", "disk_2", "data_pack_1", "data_pack_2"
    };
    return (slot >= 0) && (slot < GC_ADAM_MEDIA_SLOT_COUNT) ? names[slot] : "none";
}

static std::string AdamKeyName(int key)
{
    static const char* names[] =
    {
        "space", "minus", "plus", "caret", "semicolon", "quote", "open_bracket",
        "close_bracket", "backslash", "comma", "period", "slash", "return", "escape",
        "backspace", "tab", "home", "smart_1", "smart_2", "smart_3", "smart_4",
        "smart_5", "smart_6", "wild_card", "undo", "move", "store", "insert", "print",
        "clear", "delete", "up", "right", "down", "left", "shift", "control", "lock"
    };

    if ((key >= GC_ADAM_KEY_A) && (key <= GC_ADAM_KEY_Z))
        return std::string(1, (char)('a' + key - GC_ADAM_KEY_A));
    if ((key >= GC_ADAM_KEY_0) && (key <= GC_ADAM_KEY_9))
        return std::string(1, (char)('0' + key - GC_ADAM_KEY_0));
    if ((key >= GC_ADAM_KEY_SPACE) && (key < GC_ADAM_KEY_COUNT))
        return names[key - GC_ADAM_KEY_SPACE];
    return "none";
}

static json AdamFirmwareError(bool adam)
{
    json result;
    result["error"] = adam ? "ADAM firmware is missing or invalid" :
        "ColecoVision OS-7 firmware is missing or invalid";
    result["error_code"] = "missing_or_invalid_firmware";
    result["machine"] = adam ? "ADAM" : "ColecoVision";
    json firmware_info = json::array();
    int count = adam ? GC_ADAM_FIRMWARE_COUNT : 1;
    for (int i = 0; i < count; i++)
    {
        GC_AdamFirmware firmware = (GC_AdamFirmware)i;
        const Adam::FirmwareMetadata* metadata = Adam::GetFirmwareMetadata(firmware);
        char path[4096];
        size_t actual_size = 0;
        u32 crc = 0;
        emu_get_adam_firmware_path(firmware, path, sizeof(path));
        bool valid = emu_inspect_adam_firmware(firmware, path, &actual_size, &crc);
        std::ostringstream crc_text;
        crc_text << std::hex << std::uppercase << std::setfill('0') << std::setw(8) << crc;
        firmware_info.push_back({
            {"role", metadata->role_name},
            {"path", path},
            {"expected_size", metadata->size},
            {"actual_size", actual_size},
            {"crc32", actual_size > 0 ? crc_text.str() : ""},
            {"valid", valid},
            {"known_revision", valid && (crc == metadata->crc)}
        });
    }
    result["firmware"] = firmware_info;
    return result;
}

static int MemoryEditorOffsetToDisplayAddress(const MemoryAreaInfo& info, int offset)
{
    return offset + (int)info.display_base;
}

static int MemoryEditorDisplayAddressToOffset(const MemoryAreaInfo& info, int address)
{
    return address - (int)info.display_base;
}

static bool NormalizeMemoryAreaAddress(const MemoryAreaInfo& info, u32 address, u32* offset)
{
    if (!IsValidPointer(offset) || (!IsValidPointer(info.data) && !info.virtual_area) ||
        (info.size == 0))
        return false;

    u64 display_start = info.display_base;
    u64 display_end = display_start + info.size;

    if ((u64)address >= display_start && (u64)address < display_end)
    {
        *offset = address - info.display_base;
        return true;
    }

    if (address < info.size)
    {
        *offset = address;
        return true;
    }

    return false;
}

void DebugAdapter::Pause()
{
    emu_debug_break();
}

void DebugAdapter::Resume()
{
    emu_debug_continue();
}

void DebugAdapter::StepInto()
{
    emu_debug_step_into();
}

void DebugAdapter::StepOver()
{
    emu_debug_step_over();
}

void DebugAdapter::StepOut()
{
    emu_debug_step_out();
}

void DebugAdapter::StepFrame(int frames)
{
    emu_debug_step_frames(frames);
}

void DebugAdapter::Reset()
{
    emu_reset(gui_get_force_configuration());
}

json DebugAdapter::GetDebugStatus()
{
    json result;

    if (!m_core)
    {
        result["error"] = "Core not initialized";
        return result;
    }

    bool is_paused = emu_is_debug_idle();

    result["paused"] = is_paused;

    if (is_paused)
    {
        Processor* cpu = m_core->GetProcessor();
        u16 pc = cpu->GetState()->PC->GetValue();

        bool at_breakpoint = cpu->BreakpointHit();

        result["at_breakpoint"] = at_breakpoint;

        std::ostringstream pc_ss;
        pc_ss << std::hex << std::uppercase << std::setfill('0') << std::setw(4) << pc;
        result["pc"] = pc_ss.str();
    }
    else
    {
        result["at_breakpoint"] = false;
    }

    return result;
}

void DebugAdapter::SetBreakpoint(u16 address, int type, bool read, bool write, bool execute)
{
    Processor* cpu = m_core->GetProcessor();

    char buffer[16];
    snprintf(buffer, sizeof(buffer), "%04X", address);

    if (type == Processor::GC_BREAKPOINT_TYPE_ROMRAM && execute && !read && !write)
    {
        cpu->AddBreakpoint(address);
    }
    else
    {
        cpu->AddBreakpoint(type, buffer, read, write, execute);
    }
}

void DebugAdapter::SetBreakpointRange(u16 start_address, u16 end_address, int type, bool read, bool write, bool execute)
{
    Processor* cpu = m_core->GetProcessor();

    char buffer[16];
    snprintf(buffer, sizeof(buffer), "%04X-%04X", start_address, end_address);

    cpu->AddBreakpoint(type, buffer, read, write, execute);
}

void DebugAdapter::ClearBreakpointByAddress(u16 address, int type, u16 end_address)
{
    Processor* cpu = m_core->GetProcessor();
    std::vector<Processor::GC_Breakpoint>* breakpoints = cpu->GetBreakpoints();

    for (int i = (int)breakpoints->size() - 1; i >= 0; i--)
    {
        Processor::GC_Breakpoint& bp = (*breakpoints)[i];

        if (bp.type != type)
            continue;

        if (end_address > 0 && end_address >= address)
        {
            if (bp.range && bp.address1 == address && bp.address2 == end_address)
                breakpoints->erase(breakpoints->begin() + i);
        }
        else
        {
            if (!bp.range && bp.address1 == address)
                breakpoints->erase(breakpoints->begin() + i);
        }
    }
}

std::vector<BreakpointInfo> DebugAdapter::ListBreakpoints()
{
    std::vector<BreakpointInfo> result;
    Processor* cpu = m_core->GetProcessor();
    std::vector<Processor::GC_Breakpoint>* breakpoints = cpu->GetBreakpoints();

    for (const Processor::GC_Breakpoint& brk : *breakpoints)
    {
        BreakpointInfo info;
        info.enabled = brk.enabled;
        info.address1 = brk.address1;
        info.address2 = brk.address2;
        info.read = brk.read;
        info.write = brk.write;
        info.execute = brk.execute;
        info.range = brk.range;
        info.type_name = GetBreakpointTypeName(brk.type);
        result.push_back(info);
    }

    return result;
}

void DebugAdapter::SetRegister(const std::string& name, u32 value)
{
    Processor* cpu = m_core->GetProcessor();
    Processor::ProcessorState* state = cpu->GetState();

    if (name == "AF")
        state->AF->SetValue((u16)value);
    else if (name == "BC")
        state->BC->SetValue((u16)value);
    else if (name == "DE")
        state->DE->SetValue((u16)value);
    else if (name == "HL")
        state->HL->SetValue((u16)value);
    else if (name == "AF'" || name == "AF2")
        state->AF2->SetValue((u16)value);
    else if (name == "BC'" || name == "BC2")
        state->BC2->SetValue((u16)value);
    else if (name == "DE'" || name == "DE2")
        state->DE2->SetValue((u16)value);
    else if (name == "HL'" || name == "HL2")
        state->HL2->SetValue((u16)value);
    else if (name == "IX")
        state->IX->SetValue((u16)value);
    else if (name == "IY")
        state->IY->SetValue((u16)value);
    else if (name == "SP")
        state->SP->SetValue((u16)value);
    else if (name == "PC")
        state->PC->SetValue((u16)value);
    else if (name == "WZ")
        state->WZ->SetValue((u16)value);
    else if (name == "A")
        state->AF->SetHigh((u8)value);
    else if (name == "F")
        state->AF->SetLow((u8)value);
    else if (name == "B")
        state->BC->SetHigh((u8)value);
    else if (name == "C")
        state->BC->SetLow((u8)value);
    else if (name == "D")
        state->DE->SetHigh((u8)value);
    else if (name == "E")
        state->DE->SetLow((u8)value);
    else if (name == "H")
        state->HL->SetHigh((u8)value);
    else if (name == "L")
        state->HL->SetLow((u8)value);
    else if (name == "I")
        *state->I = (u8)value;
    else if (name == "R")
        *state->R = (u8)value;
}

std::vector<MemoryAreaInfo> DebugAdapter::ListMemoryAreas()
{
    std::vector<MemoryAreaInfo> result;

    for (int i = 0; i < MEMORY_EDITOR_MAX; i++)
    {
        MemoryAreaInfo info = GetMemoryAreaInfo(i);
        if ((info.data != NULL || info.virtual_area) && info.size > 0)
        {
            result.push_back(info);
        }
    }

    return result;
}

std::vector<u8> DebugAdapter::ReadMemoryArea(int area, u32 offset, size_t size)
{
    std::vector<u8> result;
    MemoryAreaInfo info = GetMemoryAreaInfo(area);

    if ((info.data == NULL && !info.virtual_area) || offset >= info.size)
        return result;

    u32 bytes_to_read = (u32)size;
    if (offset + bytes_to_read > info.size)
        bytes_to_read = info.size - offset;

    for (u32 i = 0; i < bytes_to_read; i++)
    {
        if (info.virtual_area)
            result.push_back(m_core->GetAdam()->DebugReadMemory((u16)(offset + i)));
        else
            result.push_back(info.data[offset + i]);
    }

    return result;
}

size_t DebugAdapter::WriteMemoryArea(int area, u32 offset, const std::vector<u8>& data)
{
    MemoryAreaInfo info = GetMemoryAreaInfo(area);

    if ((info.data == NULL && !info.virtual_area) || offset >= info.size)
        return 0;

    size_t bytes_to_write = data.size();
    if (offset + bytes_to_write > info.size)
        bytes_to_write = info.size - offset;

    if (info.virtual_area)
    {
        for (size_t i = 0; i < bytes_to_write; i++)
            if (!m_core->GetAdam()->CanWriteMemory((u16)(offset + i)))
                return 0;
    }

    for (size_t i = 0; i < bytes_to_write; i++)
    {
        if (info.virtual_area)
        {
            if (!m_core->GetAdam()->DebugWriteMemory((u16)(offset + i), data[i]))
                return i;
        }
        else
            info.data[offset + i] = data[i];
    }
    return bytes_to_write;
}

std::vector<DisasmLine> DebugAdapter::GetDisassembly(u16 start_address, u16 end_address, int bank, bool resolve_symbols)
{
    std::vector<DisasmLine> result;
    Memory* memory = m_core->GetMemory();

    bool use_explicit_bank = (bank >= 0 && bank <= 0xFF);

    // Scan backwards to find any instruction that might span into our range
    u16 scan_start = start_address;
    const int MAX_INSTRUCTION_SIZE = 7;

    for (int lookback = 1; lookback < MAX_INSTRUCTION_SIZE && scan_start > 0; lookback++)
    {
        u16 check_addr = start_address - lookback;

        if (use_explicit_bank)
        {
            u16 start_offset = start_address & 0x1FFF;
            if (lookback > start_offset)
                break;
            check_addr = (start_address & 0xE000) | (start_offset - lookback);
        }

        GC_Disassembler_Record* record = NULL;

        if (use_explicit_bank)
        {
            record = memory->GetDisassemblerRecord(check_addr, (u8)bank);
        }
        else
        {
            record = memory->GetDisassemblerRecord(check_addr);
        }

        if (IsValidPointer(record) && record->name[0] != 0)
        {
            u16 instr_end = check_addr + record->size - 1;
            if (instr_end >= start_address)
            {
                scan_start = check_addr;
                break;
            }
        }
    }

    u32 addr = scan_start;

    while (addr <= (u32)end_address)
    {
        GC_Disassembler_Record* record = NULL;

        if (use_explicit_bank)
            record = memory->GetDisassemblerRecord((u16)addr, (u8)bank);
        else
            record = memory->GetDisassemblerRecord((u16)addr);

        if (IsValidPointer(record) && record->name[0] != 0)
        {
            DisasmLine line;
            line.address = (u16)addr;
            line.bank = record->bank;
            line.name = record->name;
            strip_color_tags(line.name);
            line.bytes = record->bytes;
            line.segment = record->segment;
            line.size = record->size;
            line.jump = record->jump;
            line.jump_address = record->jump_address;
            line.subroutine = record->subroutine;
            line.irq = record->irq;

            if (resolve_symbols)
            {
                std::string instr = line.name;
                if (!gui_debug_resolve_symbol(record, instr, "", ""))
                    gui_debug_resolve_label(record, instr, "", "");
                line.name = instr;
            }

            result.push_back(line);

            u32 next_addr;

            if (use_explicit_bank)
            {
                u16 offset_in_bank = (u16)addr & 0x1FFF;
                offset_in_bank += (u16)record->size;
                if (offset_in_bank >= 0x2000)
                {
                    break;
                }
                next_addr = ((u16)addr & 0xE000) | offset_in_bank;
            }
            else
            {
                next_addr = addr + (u32)record->size;
            }

            if ((record->size == 0) || (next_addr <= addr))
                next_addr = addr + 1;

            addr = next_addr;
        }
        else
        {
            addr++;
        }
    }

    return result;
}

const char* DebugAdapter::GetBreakpointTypeName(int type)
{
    switch (type)
    {
        case Processor::GC_BREAKPOINT_TYPE_ROMRAM:
            return "ROM/RAM";
        case Processor::GC_BREAKPOINT_TYPE_VRAM:
            return "VRAM";
        case Processor::GC_BREAKPOINT_TYPE_VDP_REGISTER:
            return "VDP REG";
        default:
            return "UNKNOWN";
    }
}

MemoryAreaInfo DebugAdapter::GetMemoryAreaInfo(int area)
{
    MemoryAreaInfo info;
    info.id = area;
    info.data = NULL;
    info.size = 0;
    info.display_base = 0;
    info.virtual_area = false;

    Memory* memory = m_core->GetMemory();
    Cartridge* cart = m_core->GetCartridge();
    Video* video = m_core->GetVideo();

    switch (area)
    {
        case MEMORY_EDITOR_BIOS:
            if (m_core->GetMachine() == GC_MACHINE_ADAM)
                break;
            info.name = "BIOS";
            info.data = memory->GetBios();
            info.size = 0x2000;
            break;
        case MEMORY_EDITOR_RAM:
            if (m_core->GetMachine() == GC_MACHINE_ADAM)
                break;
            info.name = "RAM";
            info.data = memory->GetRam();
            info.size = 0x400;
            info.display_base = 0x6000;
            break;
        case MEMORY_EDITOR_SGM_RAM:
            if (m_core->GetMachine() == GC_MACHINE_ADAM)
                break;
            info.name = "SGM RAM";
            info.data = memory->GetSGMRam();
            info.size = 0x8000;
            break;
        case MEMORY_EDITOR_VRAM:
            info.name = "VRAM";
            info.data = video->GetVRAM();
            info.size = 0x4000;
            break;
        case MEMORY_EDITOR_ROM:
            info.name = "FULL ROM";
            info.data = cart->GetROM();
            info.size = cart->GetROMSize();
            break;
        case MEMORY_EDITOR_ADAM_MAPPED:
            if (m_core->GetMachine() != GC_MACHINE_ADAM)
                break;
            info.name = "CPU MAP";
            info.size = 0x10000;
            info.virtual_area = true;
            break;
        case MEMORY_EDITOR_ADAM_RAM:
            if (m_core->GetMachine() != GC_MACHINE_ADAM)
                break;
            info.name = "ADAM RAM";
            info.data = m_core->GetAdam()->GetMainRAM();
            info.size = Adam::kMainRAMSize;
            break;
        default:
            break;
    }

    return info;
}

json DebugAdapter::GetMediaInfo()
{
    json info;

    info["emulator"] = GEARCOLECO_TITLE;
    info["emulator_version"] = GEARCOLECO_VERSION;
    info["ready"] = m_core->IsReady();

    if (m_core->GetMachine() == GC_MACHINE_ADAM)
    {
        static const char* slot_names[GC_ADAM_MEDIA_SLOT_COUNT] = {
            "disk_1", "disk_2", "data_pack_1", "data_pack_2"
        };
        static const char* content_names[] = {
            "none", "cartridge", "data_pack", "disk"
        };

        info["machine"] = "ADAM";
        info["boot_mode"] = m_core->GetAdamBootMode() == GC_ADAM_BOOT_CARTRIDGE ?
            "cartridge" : "computer";
        int content_type = (int)m_core->GetContentType();
        info["content_type"] = (content_type >= 0 && content_type < 4) ?
            content_names[content_type] : "unknown";
        info["file_path"] = emu_get_content_path();
        info["file_name"] = emu_get_content_name();
        info["is_pal"] = false;

        json firmware = json::array();
        for (int i = 0; i < GC_ADAM_FIRMWARE_COUNT; i++)
        {
            const Adam::FirmwareMetadata* metadata =
                Adam::GetFirmwareMetadata((GC_AdamFirmware)i);
            std::ostringstream crc;
            crc << std::hex << std::uppercase << std::setfill('0') << std::setw(8)
                << m_core->GetAdam()->GetFirmwareCRC((GC_AdamFirmware)i);
            firmware.push_back({
                {"role", metadata->role_name},
                {"loaded", m_core->GetAdam()->GetFirmwareCRC((GC_AdamFirmware)i) != 0},
                {"crc", crc.str()}
            });
        }
        info["firmware"] = firmware;

        json devices = json::array();
        for (int i = 0; i < AdamNet::GetDeviceCount(); i++)
        {
            const AdamNet::DeviceMetadata* device = AdamNet::GetDeviceMetadataByIndex(i);
            std::ostringstream id;
            id << std::hex << std::uppercase << std::setfill('0') << std::setw(2)
                << (int)device->id;
            const char* type = device->type == AdamNet::DeviceKeyboard ? "keyboard" :
                (device->type == AdamNet::DevicePrinter ? "printer" :
                (device->type == AdamNet::DeviceDisk ? "disk" : "data_pack"));
            const char* timing = device->timing == AdamNet::TimingKeyboard ? "keyboard" :
                (device->timing == AdamNet::TimingPrinter ? "printer" :
                (device->timing == AdamNet::TimingFloppy ? "floppy" : "data_pack"));
            devices.push_back({
                {"id", id.str()},
                {"name", device->name},
                {"type", type},
                {"slot", device->slot},
                {"max_transfer", device->max_transfer},
                {"timing", timing}
            });
        }
        info["adamnet_devices"] = devices;

        json media = json::array();
        for (int i = 0; i < GC_ADAM_MEDIA_SLOT_COUNT; i++)
        {
            Emu_AdamMediaInfo media_info;
            emu_get_adam_media_info((GC_AdamMediaSlot)i, &media_info);
            std::ostringstream crc;
            crc << std::hex << std::uppercase << std::setfill('0') << std::setw(8)
                << media_info.base_crc;
            media.push_back({
                {"slot", slot_names[i]},
                {"inserted", media_info.inserted},
                {"type", media_info.type == GC_ADAM_MEDIA_DATA_PACK ? "data_pack" :
                    (media_info.type == GC_ADAM_MEDIA_DISK ? "disk" : "none")},
                {"size", media_info.size},
                {"write_protected", media_info.write_protected},
                {"dirty", media_info.dirty},
                {"state_owned", media_info.state_owned},
                {"base_crc", crc.str()},
                {"source_path", media_info.path},
                {"working_path", media_info.working_path}
            });
        }
        info["media"] = media;
        return info;
    }

    Cartridge* cart = m_core->GetCartridge();
    info["machine"] = "ColecoVision";
    info["file_path"] = cart->GetFilePath();
    info["file_name"] = cart->GetFileName();
    info["file_directory"] = cart->GetFileDirectory();

    std::ostringstream crc_ss;
    crc_ss << std::hex << std::uppercase << std::setfill('0') << std::setw(8) << cart->GetCRC();
    info["crc"] = crc_ss.str();

    info["is_pal"] = cart->IsPAL();
    info["has_sram"] = cart->HasSRAM();
    info["valid_rom"] = cart->IsValidROM();
    info["rom_size"] = cart->GetROMSize();
    info["rom_bank_count"] = cart->GetROMBankCount();
    info["softpatch_applied"] = cart->IsSoftpatchApplied();
    if (cart->IsSoftpatchApplied())
        info["softpatch_path"] = cart->GetSoftpatchPath();

    Cartridge::CartridgeTypes type = cart->GetType();
    const char* type_names[] = {
        "ColecoVision", "MegaCart", "Activision", "OCM", "Not Supported"
    };
    int type_idx = (int)type;
    if (type_idx >= 0 && type_idx < (int)(sizeof(type_names) / sizeof(type_names[0])))
        info["cartridge_type"] = type_names[type_idx];
    else
        info["cartridge_type"] = "Unknown";

    return info;
}

json DebugAdapter::GetAdamStatus()
{
    if (!m_core || !m_core->IsReady() || (m_core->GetMachine() != GC_MACHINE_ADAM))
        return {{"error", "ADAM is not running"}};

    GC_AdamDebugState state;
    if (!m_core->GetAdamDebugState(&state))
        return {{"error", "Unable to read ADAM state"}};

    json result = {
        {"machine", "ADAM"},
        {"boot_mode", state.boot_mode == GC_ADAM_BOOT_CARTRIDGE ? "cartridge" : "computer"},
        {"content_type", AdamContentTypeName(state.content_type)},
        {"master_clock_cycles", state.master_clock_cycles},
        {"mapping_generation", state.mapping_generation},
        {"mioc", {
            {"value", state.mioc},
            {"hex", AdamHex(state.mioc, 2)},
            {"lower_selector", state.mioc & 0x03},
            {"upper_selector", (state.mioc >> 2) & 0x03}
        }},
        {"control", {
            {"value", state.control},
            {"hex", AdamHex(state.control, 2)},
            {"adamnet_reset", state.adamnet_reset},
            {"eos_enabled", state.eos_enabled}
        }}
    };

    json firmware = json::array();
    for (int index = 0; index < GC_ADAM_FIRMWARE_COUNT; index++)
    {
        const Adam::FirmwareMetadata* metadata =
            Adam::GetFirmwareMetadata((GC_AdamFirmware)index);
        const GC_AdamDebugFirmwareState* debug_firmware = &state.firmware[index];
        firmware.push_back({
            {"role", metadata->role_name},
            {"loaded", debug_firmware->loaded},
            {"size", debug_firmware->size},
            {"crc32", AdamHex(debug_firmware->crc, 8)},
            {"known_revision", debug_firmware->known}
        });
    }
    result["firmware"] = firmware;

    json memory_map = json::array();
    for (int index = 0; index < GC_ADAM_DEBUG_PAGE_COUNT; index++)
    {
        const GC_AdamDebugMemoryPage* page = &state.pages[index];
        json mapped_page = {
            {"start", AdamHex(page->start, 4)},
            {"end", AdamHex(page->end, 4)},
            {"read_source", AdamMemorySourceName(page->read_source)},
            {"write_destination", page->write_source == Adam::MemorySourceOpenBus ?
                "none" : AdamMemorySourceName(page->write_source)},
            {"debug_writable", page->writable}
        };
        if (page->read_source != Adam::MemorySourceOpenBus)
            mapped_page["read_offset"] = AdamHex(page->read_offset, 4);
        if (page->write_source == Adam::MemorySourceRAM)
            mapped_page["write_offset"] = AdamHex(page->write_offset, 4);
        if (page->cartridge_bank >= 0)
            mapped_page["cartridge_bank"] = page->cartridge_bank;
        memory_map.push_back(mapped_page);
    }
    result["memory_map"] = memory_map;
    return result;
}

json DebugAdapter::GetAdamNetStatus()
{
    if (!m_core || !m_core->IsReady() || (m_core->GetMachine() != GC_MACHINE_ADAM))
        return {{"error", "ADAM is not running"}};

    GC_AdamDebugState state;
    if (!m_core->GetAdamDebugState(&state))
        return {{"error", "Unable to read ADAM state"}};

    json result = {
        {"controller_state", AdamControllerStateName(state.controller_state)},
        {"pcb", {
            {"address", AdamHex(state.pcb_address, 4)},
            {"command_status", state.pcb_command_status},
            {"command_status_hex", AdamHex(state.pcb_command_status, 2)},
            {"command_status_name", AdamCommandStatusName(state.pcb_command_status)},
            {"configured_dcb_count", state.configured_dcb_count}
        }},
        {"next_scan_index", state.next_scan_index},
        {"cycles_until_event", state.cycles_until_event}
    };

    json transfer = {
        {"active", state.transfer_active}
    };
    if (state.transfer_active)
    {
        transfer["kind"] = state.transfer_pcb ? "pcb" : "dcb";
        transfer["command"] = state.transfer_command;
        transfer["command_hex"] = AdamHex(state.transfer_command, 2);
        transfer["command_name"] = AdamCommandStatusName(state.transfer_command);
        transfer["error"] = state.transfer_error;
        if (state.transfer_pcb)
        {
            transfer["target_pcb_address"] = AdamHex(state.transfer_pcb_address, 4);
            transfer["configured_dcb_count"] = state.transfer_pcb_count;
        }
        else
        {
            const AdamNet::DeviceMetadata* device =
                AdamNet::GetDeviceMetadata(state.transfer_device);
            transfer["dcb"] = state.transfer_dcb;
            transfer["device_id"] = AdamHex(state.transfer_device, 2);
            transfer["device_name"] = IsValidPointer(device) ? device->name : "Unknown";
            transfer["media_slot"] = IsValidPointer(device) ?
                AdamMediaSlotName(device->slot) : "none";
            transfer["block"] = state.transfer_block;
            transfer["dma_buffer"] = AdamHex(state.transfer_buffer, 4);
            transfer["length"] = state.transfer_length;
            transfer["captured_media_generation"] = state.transfer_media_generation;
        }
    }
    result["active_transfer"] = transfer;

    json dcbs = json::array();
    for (int index = 0; index < GC_ADAM_DEBUG_DCB_COUNT; index++)
    {
        const GC_AdamDebugDCB* dcb = &state.dcbs[index];
        const AdamNet::DeviceMetadata* device = AdamNet::GetDeviceMetadata(dcb->device);
        u8 node_status = AdamNodeStatusValue(dcb->node_status, dcb->device);
        dcbs.push_back({
            {"index", index},
            {"command_status", dcb->command_status},
            {"command_status_hex", AdamHex(dcb->command_status, 2)},
            {"command_status_name", AdamCommandStatusName(dcb->command_status)},
            {"device_id", AdamHex(dcb->device, 2)},
            {"device_name", IsValidPointer(device) ? device->name : "Unknown"},
            {"buffer", AdamHex(dcb->buffer, 4)},
            {"length", dcb->length},
            {"block", dcb->block},
            {"retry", dcb->retry},
            {"max_length", dcb->max_length},
            {"device_type", dcb->device_type},
            {"device_type_name", AdamDCBDeviceTypeName(dcb->device_type)},
            {"node_status", AdamHex(dcb->node_status, 2)},
            {"node_status_value", node_status},
            {"node_status_name", AdamNodeStatusName(node_status)}
        });
    }
    result["dcbs"] = dcbs;
    result["keyboard"] = {
        {"fifo_count", state.keyboard_fifo_count},
        {"fifo_capacity", AdamNet::kKeyboardFIFOSize},
        {"overflow", state.keyboard_overflow},
        {"lock", state.keyboard_lock},
        {"modifiers", {
            {"shift", state.keyboard_shift},
            {"control", state.keyboard_control},
            {"home", state.keyboard_home}
        }},
        {"repeat_key", AdamKeyName(state.keyboard_repeat_key)},
        {"repeat_cycles", state.keyboard_repeat_cycles}
    };
    return result;
}

json DebugAdapter::ListAdamMedia()
{
    if (!m_core || !m_core->IsReady() || (m_core->GetMachine() != GC_MACHINE_ADAM))
        return {{"error", "ADAM is not running"}};

    GC_AdamDebugState state;
    if (!m_core->GetAdamDebugState(&state))
        return {{"error", "Unable to read ADAM state"}};

    json media = json::array();
    for (int slot = 0; slot < GC_ADAM_MEDIA_SLOT_COUNT; slot++)
    {
        const GC_AdamDebugMediaState* core_media = &state.media[slot];
        Emu_AdamMediaInfo host_media = {};
        emu_get_adam_media_info((GC_AdamMediaSlot)slot, &host_media);
        media.push_back({
            {"slot", AdamMediaSlotName(slot)},
            {"inserted", core_media->inserted},
            {"type", AdamMediaTypeName(core_media->type)},
            {"capacity", core_media->size},
            {"block_count", core_media->block_count},
            {"position", core_media->position},
            {"generation", core_media->generation},
            {"cache_valid", core_media->cache_valid},
            {"cached_block", core_media->cached_block},
            {"cached_generation", core_media->cached_generation},
            {"write_protected", core_media->write_protected},
            {"dirty", core_media->dirty},
            {"base_crc32", AdamHex(core_media->base_crc, 8)},
            {"source_path", host_media.path},
            {"working_path", host_media.working_path},
            {"state_owned", host_media.state_owned}
        });
    }

    return {{"count", GC_ADAM_MEDIA_SLOT_COUNT}, {"media", media}};
}

json DebugAdapter::GetAdamPrinterOutput()
{
    if (!m_core || !m_core->IsReady() || (m_core->GetMachine() != GC_MACHINE_ADAM))
        return {{"error", "ADAM is not running"}};

    AdamNet* adam_net = m_core->GetAdam()->GetAdamNet();
    const u8* data = adam_net->GetPrinterData();
    int size = adam_net->GetPrinterSize();
    std::string text;
    std::ostringstream hex;
    text.reserve((size_t)size);
    for (int i = 0; i < size; i++)
    {
        u8 value = data[i];
        if (value == '\r')
        {
            if ((i + 1 >= size) || (data[i + 1] != '\n'))
                text.push_back('\n');
        }
        else if ((value == '\n') || (value == '\t') || ((value >= 0x20) && (value < 0x7F)))
            text.push_back((char)value);
        else
            text.push_back('.');

        if (i > 0)
            hex << ' ';
        hex << std::hex << std::uppercase << std::setfill('0') << std::setw(2) << (int)value;
    }

    return {{"size", size}, {"capacity", AdamNet::kPrinterSpoolSize},
        {"text", text}, {"hex", hex.str()}};
}

json DebugAdapter::ClearAdamPrinterOutput()
{
    if (!m_core || !m_core->IsReady() || (m_core->GetMachine() != GC_MACHINE_ADAM))
        return {{"error", "ADAM is not running"}};

    m_core->GetAdam()->GetAdamNet()->ClearPrinter();
    return {{"success", true}};
}

json DebugAdapter::ListRecentMedia()
{
    json result;
    json recent_media = json::array();

    for (int index = 0; index < config_max_recent_roms; index++)
    {
        const std::string& path = config_emulator.recent_roms[index];

        if (path.empty())
            continue;

        json entry;
        entry["index"] = index;
        entry["file_path"] = path;
        entry["file_name"] = get_filename(path.c_str());
        recent_media.push_back(entry);
    }

    result["count"] = recent_media.size();
    result["recent_media"] = recent_media;

    return result;
}

json DebugAdapter::GetZ80Status()
{
    json status;
    Processor* cpu = m_core->GetProcessor();
    Processor::ProcessorState* state = cpu->GetState();
    Memory* memory = m_core->GetMemory();

    std::ostringstream ss;
    ss << std::hex << std::uppercase << std::setfill('0');

    // Main register pairs
    ss << std::setw(4) << state->AF->GetValue();
    status["AF"] = ss.str(); ss.str("");

    ss << std::setw(4) << state->BC->GetValue();
    status["BC"] = ss.str(); ss.str("");

    ss << std::setw(4) << state->DE->GetValue();
    status["DE"] = ss.str(); ss.str("");

    ss << std::setw(4) << state->HL->GetValue();
    status["HL"] = ss.str(); ss.str("");

    // Shadow register pairs
    ss << std::setw(4) << state->AF2->GetValue();
    status["AF'"] = ss.str(); ss.str("");

    ss << std::setw(4) << state->BC2->GetValue();
    status["BC'"] = ss.str(); ss.str("");

    ss << std::setw(4) << state->DE2->GetValue();
    status["DE'"] = ss.str(); ss.str("");

    ss << std::setw(4) << state->HL2->GetValue();
    status["HL'"] = ss.str(); ss.str("");

    // Index, stack, PC
    ss << std::setw(4) << state->IX->GetValue();
    status["IX"] = ss.str(); ss.str("");

    ss << std::setw(4) << state->IY->GetValue();
    status["IY"] = ss.str(); ss.str("");

    ss << std::setw(4) << state->SP->GetValue();
    status["SP"] = ss.str(); ss.str("");

    ss << std::setw(4) << state->PC->GetValue();
    status["PC"] = ss.str(); ss.str("");

    ss << std::setw(4) << state->WZ->GetValue();
    status["WZ"] = ss.str(); ss.str("");

    // Individual 8-bit registers
    u8 a = state->AF->GetHigh();
    u8 f = state->AF->GetLow();

    ss << std::setw(2) << (int)a;
    status["A"] = ss.str(); ss.str("");

    ss << std::setw(2) << (int)f;
    status["F"] = ss.str(); ss.str("");

    ss << std::setw(2) << (int)state->BC->GetHigh();
    status["B"] = ss.str(); ss.str("");

    ss << std::setw(2) << (int)state->BC->GetLow();
    status["C"] = ss.str(); ss.str("");

    ss << std::setw(2) << (int)state->DE->GetHigh();
    status["D"] = ss.str(); ss.str("");

    ss << std::setw(2) << (int)state->DE->GetLow();
    status["E"] = ss.str(); ss.str("");

    ss << std::setw(2) << (int)state->HL->GetHigh();
    status["H"] = ss.str(); ss.str("");

    ss << std::setw(2) << (int)state->HL->GetLow();
    status["L"] = ss.str(); ss.str("");

    ss << std::setw(2) << (int)*state->I;
    status["I"] = ss.str(); ss.str("");

    ss << std::setw(2) << (int)*state->R;
    status["R"] = ss.str(); ss.str("");

    // Flags decoded from F register
    status["flag_S"] = (f & 0x80) != 0;
    status["flag_Z"] = (f & 0x40) != 0;
    status["flag_Y"] = (f & 0x20) != 0;
    status["flag_H"] = (f & 0x10) != 0;
    status["flag_X"] = (f & 0x08) != 0;
    status["flag_PV"] = (f & 0x04) != 0;
    status["flag_N"] = (f & 0x02) != 0;
    status["flag_C"] = (f & 0x01) != 0;

    // Physical PC and bank
    ss << std::setw(6) << memory->GetPhysicalAddress(state->PC->GetValue());
    status["physical_PC"] = ss.str(); ss.str("");

    ss << std::setw(2) << (int)memory->GetBank(state->PC->GetValue());
    status["bank"] = ss.str(); ss.str("");

    // Interrupt state
    status["IFF1"] = *state->IFF1;
    status["IFF2"] = *state->IFF2;
    status["IM"] = *state->InterruptMode;
    status["Halt"] = *state->Halt;
    status["INT"] = *state->INT;
    status["NMI"] = *state->NMI;

    return status;
}

json DebugAdapter::GetVDPRegisters()
{
    json registers = json::array();
    Video* video = m_core->GetVideo();
    u8* regs = video->GetRegisters();

    const char* reg_names[] = {
        "CONTROL 0", "CONTROL 1", "NAME TABLE",
        "COLOR TABLE", "PATTERN TABLE", "SPRITE ATTR",
        "SPRITE PAT", "BACKDROP COLOR"
    };

    for (int i = 0; i < 8; i++)
    {
        json reg = json::array();
        reg.push_back(i);

        std::ostringstream ss;
        ss << std::hex << std::uppercase << std::setfill('0') << std::setw(2) << (int)regs[i];
        reg.push_back(ss.str());
        reg.push_back(reg_names[i]);

        registers.push_back(reg);
    }

    if (video->IsF18AHardware())
    {
        const int f18a_indexes[] = { 10, 11, 15, 19, 24, 25, 26, 27, 28, 29, 30, 31,
            32, 33, 34, 35, 36, 47, 48, 49, 50, 51, 54, 55, 56, 57 };
        const char* f18a_names[] = { "T2 NAME TABLE", "T2 COLOR TABLE", "STATUS SELECT",
            "LINE INTERRUPT", "PALETTE SELECT", "T2 HSCROLL", "T2 VSCROLL", "T1 HSCROLL",
            "T1 VSCROLL", "PAGE SIZE", "SPRITE MAX", "BITMAP CONTROL", "BITMAP BASE",
            "BITMAP X", "BITMAP Y", "BITMAP WIDTH", "BITMAP HEIGHT", "DATA PORT MODE",
            "VRAM INCREMENT", "ECM MODE", "F18A CONTROL", "SPRITE STOP", "GPU PC MSB",
            "GPU PC LSB", "GPU CONTROL", "F18A UNLOCK" };

        for (int i = 0; i < (int)(sizeof(f18a_indexes) / sizeof(f18a_indexes[0])); i++)
        {
            json reg = json::array();
            int index = f18a_indexes[i];
            reg.push_back(index);
            std::ostringstream ss;
            ss << std::hex << std::uppercase << std::setfill('0') << std::setw(2) << (int)regs[index];
            reg.push_back(ss.str());
            reg.push_back(f18a_names[i]);
            registers.push_back(reg);
        }
    }

    json decoded;
    decoded["screen_enabled"] = (regs[1] & 0x40) != 0;
    decoded["nmi_enabled"] = (regs[1] & 0x20) != 0;
    decoded["sprite_size_16x16"] = (regs[1] & 0x02) != 0;
    decoded["sprite_magnification"] = (regs[1] & 0x01) != 0;
    decoded["external_video"] = (regs[0] & 0x01) != 0;
    decoded["tms9918_mode"] = video->GetMode();
    decoded["name_table_addr"] = (regs[2] & 0x0F) << 10;
    decoded["color_table_addr"] = regs[3] << 6;
    decoded["pattern_table_addr"] = (regs[4] & 0x07) << 11;
    decoded["sprite_attr_addr"] = (regs[5] & 0x7F) << 7;
    decoded["sprite_pattern_addr"] = (regs[6] & 0x07) << 11;
    decoded["backdrop_color"] = regs[7] & 0x0F;
    decoded["text_color"] = (regs[7] >> 4) & 0x0F;
    decoded["video_chip"] = video->IsF18AHardware() ? "F18A V1.9" : "TMS9918A";
    decoded["f18a_unlocked"] = video->IsF18AUnlocked();
    decoded["screen_width"] = video->GetScreenWidth();
    decoded["screen_height"] = video->GetScreenHeight();

    json result;
    result["fields"] = json::array({"index", "value", "description"});
    result["registers"] = registers;
    result["decoded"] = decoded;

    return result;
}

json DebugAdapter::GetVDPStatus()
{
    json status;
    Video* video = m_core->GetVideo();

    u8 flags = video->GetStatusReg();

    status["status_flags"] = flags;
    status["frame_interrupt"] = (flags & 0x80) != 0;
    status["sprite_overflow"] = (flags & 0x40) != 0;
    status["sprite_collision"] = (flags & 0x20) != 0;
    status["fifth_sprite"] = flags & 0x1F;

    status["tms9918_mode"] = video->GetMode();
    status["render_line"] = video->GetRenderLine();
    status["cycle_counter"] = video->GetCycleCounter();
    status["display_enabled"] = (video->GetRegisters()[1] & 0x40) != 0;
    status["is_pal"] = video->IsPAL();

    if (video->IsF18AHardware())
    {
        json f18a_status = json::array();
        for (int i = 0; i < 16; i++)
            f18a_status.push_back(video->GetF18AStatusRegister(i));
        status["f18a_status"] = f18a_status;
        status["f18a_unlocked"] = video->IsF18AUnlocked();
        status["gpu_pc"] = video->GetF18AGPU()->GetPC();
        status["gpu_status"] = video->GetF18AGPU()->GetStatus();
        status["gpu_running"] = video->GetF18AGPU()->IsRunning();
    }

    return status;
}

json DebugAdapter::GetPSGStatus()
{
    json status;
    Audio* audio = m_core->GetAudio();
    Sms_Apu* psg = audio->GetPSG();
    Sms_Apu_State psg_state = psg->GetState();

    GC_RuntimeInfo runtime;
    m_core->GetRuntimeInfo(runtime);
    int master_clock = (runtime.region == Region_PAL) ? GC_MASTER_CLOCK_PAL : GC_MASTER_CLOCK_NTSC;

    std::ostringstream ss;
    ss << std::hex << std::uppercase << std::setfill('0');

    json channels = json::array();
    for (int c = 0; c < 4; c++)
    {
        Sms_Apu_State::Channel* ch = &psg_state.channels[c];
        json channel;

        channel["index"] = c;
        channel["type"] = (c < 3) ? "tone" : "noise";
        channel["volume_reg"] = ch->volume_reg;
        channel["mute"] = *ch->mute;

        if (ch->volume_reg == 15)
            channel["volume_info"] = "OFF";
        else if (ch->volume_reg == 0)
            channel["volume_info"] = "MAX";
        else
        {
            char buf[32];
            snprintf(buf, sizeof(buf), "-%.1f dB", ch->volume_reg * 2.0f);
            channel["volume_info"] = buf;
        }

        if (c < 3)
        {
            int raw_period = ch->period >> 4;
            channel["period"] = raw_period;
            channel["phase"] = ch->phase;

            if (raw_period > 0)
            {
                float freq_hz = (float)master_clock / (32.0f * raw_period);
                channel["frequency_hz"] = freq_hz;
            }
            else
            {
                channel["frequency_hz"] = 0.0f;
            }
        }
        else
        {
            static const char* noise_rate_names[4] = { "N/512", "N/1024", "N/2048", "Tone 3" };
            channel["noise_white"] = psg_state.noise_white;
            channel["noise_rate"] = psg_state.noise_rate;
            channel["noise_rate_name"] = noise_rate_names[psg_state.noise_rate];
            channel["noise_shifter"] = psg_state.noise_shifter;

            if (psg_state.noise_rate < 3)
            {
                static const int noise_dividers[3] = { 512, 1024, 2048 };
                float freq_hz = (float)master_clock / (float)noise_dividers[psg_state.noise_rate];
                channel["frequency_hz"] = freq_hz;
            }
            else
            {
                int ch3_raw = psg_state.channels[2].period >> 4;
                if (ch3_raw > 0)
                {
                    float freq_hz = (float)master_clock / (32.0f * ch3_raw);
                    channel["frequency_hz"] = freq_hz;
                }
            }
        }

        channels.push_back(channel);
    }

    status["channels"] = channels;
    status["latch"] = psg_state.latch;

    ss << std::setw(2) << psg_state.ggstereo;
    status["gg_stereo"] = ss.str(); ss.str("");

    status["noise_feedback"] = psg_state.noise_feedback;

    return status;
}

json DebugAdapter::GetAY8910Status()
{
    json status;
    Audio* audio = m_core->GetAudio();
    AY8910* ay = audio->GetAY8910();

    const u8* regs = ay->GetRegisters();
    const u16* tone_periods = ay->GetTonePeriods();
    const u8* amplitudes = ay->GetAmplitudes();
    const bool* tone_disable = ay->GetToneDisable();
    const bool* noise_disable = ay->GetNoiseDisable();
    const bool* envelope_mode = ay->GetEnvelopeMode();
    int clock_rate = ay->GetClockRate();

    json channels = json::array();
    for (int c = 0; c < 3; c++)
    {
        json channel;
        channel["index"] = c;
        channel["name"] = std::string(1, (char)('A' + c));
        channel["tone_enabled"] = !tone_disable[c];
        channel["noise_enabled"] = !noise_disable[c];
        channel["envelope_enabled"] = envelope_mode[c];
        channel["tone_period"] = tone_periods[c];
        channel["tone_reg_lo"] = regs[c * 2];
        channel["tone_reg_hi"] = regs[c * 2 + 1] & 0x0F;
        channel["amplitude"] = amplitudes[c];
        channel["amplitude_reg"] = regs[8 + c];

        bool* mute = ay->GetChannelMute(c);
        channel["mute"] = mute ? *mute : false;

        if (tone_periods[c] > 0 && clock_rate > 0)
            channel["frequency_hz"] = (float)clock_rate / (16.0f * tone_periods[c]);
        else
            channel["frequency_hz"] = 0.0f;

        channels.push_back(channel);
    }
    status["channels"] = channels;

    json noise;
    noise["period"] = ay->GetNoisePeriod();
    noise["period_reg"] = regs[6];
    noise["lfsr"] = ay->GetNoiseShift() & 0x1FFFF;
    if (ay->GetNoisePeriod() > 0 && clock_rate > 0)
        noise["frequency_hz"] = (float)clock_rate / (16.0f * ay->GetNoisePeriod());
    else
        noise["frequency_hz"] = 0.0f;
    status["noise"] = noise;

    json envelope;
    envelope["period"] = ay->GetEnvelopePeriod();
    envelope["period_lo"] = regs[11];
    envelope["period_hi"] = regs[12];
    envelope["shape"] = regs[13] & 0x0F;
    envelope["step"] = ay->GetEnvelopeStep();
    envelope["volume"] = ay->GetEnvelopeVolume();
    if (ay->GetEnvelopePeriod() > 0 && clock_rate > 0)
        envelope["frequency_hz"] = (float)clock_rate / (256.0f * ay->GetEnvelopePeriod());
    else
        envelope["frequency_hz"] = 0.0f;
    status["envelope"] = envelope;

    std::ostringstream ss;
    ss << std::hex << std::uppercase << std::setfill('0');

    json registers = json::array();
    for (int i = 0; i < 16; i++)
    {
        ss << std::setw(2) << (int)regs[i];
        registers.push_back(ss.str());
        ss.str("");
    }
    status["registers"] = registers;
    status["selected_register"] = ay->GetSelectedRegister();
    status["mixer"] = regs[7];

    return status;
}

json DebugAdapter::GetScreenshot()
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    GC_RuntimeInfo runtime;
    m_core->GetRuntimeInfo(runtime);

    unsigned char* png_buffer = NULL;
    int png_size = emu_get_screenshot_png(&png_buffer);

    if (png_size == 0 || !png_buffer)
    {
        result["error"] = "Failed to capture screenshot";
        return result;
    }

    std::string base64_png = base64_encode(png_buffer, png_size);
    free(png_buffer);

    result["__mcp_image"] = true;
    result["data"] = base64_png;
    result["mimeType"] = "image/png";
    result["width"] = runtime.screen_width;
    result["height"] = runtime.screen_height;

    return result;
}

static const char* const k_video_recording_ratios[] = { "screen", "square", "4:3", "16:9", "16:10" };
static const char* const k_video_recording_qualities[] = { "low", "medium", "high", "lossless", "lossless_compressed" };
static const int k_video_recording_ratio_count = sizeof(k_video_recording_ratios) / sizeof(k_video_recording_ratios[0]);
static const int k_video_recording_quality_count = sizeof(k_video_recording_qualities) / sizeof(k_video_recording_qualities[0]);

static int find_video_recording_option(const std::string& value, const char* const* options, int count)
{
    for (int i = 0; i < count; i++)
    {
        if (value == options[i])
            return i;
    }
    return -1;
}

json DebugAdapter::StartVideoRecording(const std::string& file_path, int scale, const std::string& aspect_ratio, const std::string& quality)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        Log("[MCP] StartVideoRecording failed: No media loaded");
        return result;
    }

    if (emu_is_video_recording())
    {
        result["error"] = "Video recording is already active";
        return result;
    }

    int ratio = aspect_ratio.empty() ? config_video.recording_ratio : find_video_recording_option(aspect_ratio, k_video_recording_ratios, k_video_recording_ratio_count);
    int quality_index = quality.empty() ? config_video.recording_quality : find_video_recording_option(quality, k_video_recording_qualities, k_video_recording_quality_count);

    if ((scale != 0) && ((scale < 1) || (scale > 20)))
    {
        result["error"] = "Invalid scale";
        return result;
    }

    if ((ratio < 0) || (quality_index < 0))
    {
        result["error"] = "Invalid aspect ratio or quality";
        return result;
    }

    if (scale != 0)
        config_video.recording_scale = scale;
    config_video.recording_ratio = ratio;
    config_video.recording_quality = quality_index;

    if (!gui_action_start_video_recording(file_path.empty() ? NULL : file_path.c_str()))
    {
        result["error"] = "Failed to start video recording";
        Log("[MCP] StartVideoRecording failed: %s", file_path.c_str());
        return result;
    }

    result["success"] = true;
    result["file_path"] = video_recorder_get_file_path();
    result["scale"] = config_video.recording_scale;
    result["aspect_ratio"] = k_video_recording_ratios[config_video.recording_ratio];
    result["quality"] = k_video_recording_qualities[config_video.recording_quality];

    return result;
}

json DebugAdapter::StopVideoRecording()
{
    json result;

    if (!emu_is_video_recording())
    {
        result["error"] = "Video recording is not active";
        return result;
    }

    std::string file_path = video_recorder_get_file_path();
    u32 frames = video_recorder_get_frame_count();

    gui_action_stop_video_recording();

    result["success"] = true;
    result["file_path"] = file_path;
    result["frames"] = frames;

    return result;
}

json DebugAdapter::StartLoadMedia(const std::string& file_path)
{
    json result;

    if (file_path.empty())
    {
        result["error"] = "File path is required";
        Log("[MCP] LoadMedia failed: File path is required");
        return result;
    }

    if (!gui_load_rom(file_path.c_str()))
    {
        result["error"] = "Another media load is already in progress";
        Log("[MCP] LoadMedia failed: load already in progress");
        return result;
    }

    result["file_path"] = file_path;

    return result;
}

bool DebugAdapter::IsMediaLoading() const
{
    return gui_is_rom_loading() && emu_is_media_loading();
}

json DebugAdapter::FinishLoadMedia(const std::string& file_path)
{
    json result;

    if ((gui_is_rom_loading() && !gui_finish_loading_rom()) || !emu_get_last_load_result())
    {
        if ((emu_get_last_load_machine() == GC_MACHINE_ADAM) &&
            !emu_are_adam_firmware_paths_valid())
        {
            return AdamFirmwareError(true);
        }
        result["error"] = "Failed to load media file";
        result["error_code"] = "media_load_failed";
        result["detected_machine"] = emu_get_last_load_machine() == GC_MACHINE_ADAM ?
            "ADAM" : (emu_get_last_load_machine() == GC_MACHINE_COLECOVISION ?
            "ColecoVision" : "Unknown");
        Log("[MCP] LoadMedia failed: %s", file_path.c_str());
        return result;
    }

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "Failed to load media file";
        Log("[MCP] LoadMedia failed: %s", file_path.c_str());
        return result;
    }

    result["success"] = true;
    result["file_path"] = file_path;
    result["content_name"] = emu_get_content_name();
    result["machine"] = m_core->GetMachine() == GC_MACHINE_ADAM ? "ADAM" : "ColecoVision";
    result["is_pal"] = m_core->GetMachine() != GC_MACHINE_ADAM &&
        m_core->GetCartridge()->IsPAL();
    if (m_core->GetMachine() == GC_MACHINE_COLECOVISION)
    {
        result["softpatch_applied"] = m_core->GetCartridge()->IsSoftpatchApplied();
        if (m_core->GetCartridge()->IsSoftpatchApplied())
            result["softpatch_path"] = m_core->GetCartridge()->GetSoftpatchPath();
    }

    return result;
}

json DebugAdapter::StartAdam()
{
    if (gui_is_rom_loading())
        return {{"error", "Another media load is already in progress"},
            {"error_code", "load_in_progress"}};
    if (!emu_are_adam_firmware_paths_valid())
        return AdamFirmwareError(true);
    if (!gui_start_adam())
        return {{"error", "Unable to start ADAM"}, {"error_code", "adam_start_failed"}};

    return {
        {"success", true},
        {"machine", "ADAM"},
        {"boot_mode", "computer"},
        {"content_name", emu_get_content_name()}
    };
}

json DebugAdapter::LoadBios(const std::string& file_path, GC_AdamFirmware firmware)
{
    json result;

    if (file_path.empty())
    {
        result["error"] = "File path is required";
        Log("[MCP] LoadBios failed: File path is required");
        return result;
    }

    if (gui_is_rom_loading() || emu_is_busy())
    {
        result["error"] = "Another media load is already in progress";
        result["error_code"] = "load_in_progress";
        return result;
    }

    const Adam::FirmwareMetadata* metadata = Adam::GetFirmwareMetadata(firmware);
    size_t actual_size = 0;
    u32 crc = 0;
    bool valid = emu_inspect_adam_firmware(firmware, file_path.c_str(), &actual_size, &crc);

    if (actual_size == 0)
    {
        result["error"] = "Failed to load BIOS file: file not found or empty";
        Log("[MCP] LoadBios failed: file not found or empty: %s", file_path.c_str());
        return result;
    }

    if (!valid)
    {
        result["error"] = std::string("Failed to load BIOS file: invalid ") + metadata->role_name + " size";
        result["expected_size"] = metadata->size;
        result["actual_size"] = actual_size;
        Log("[MCP] LoadBios failed: invalid size: %s", file_path.c_str());
        return result;
    }

    if (!gui_adam_apply_firmware_path(firmware, file_path.c_str()))
    {
        result["error"] = "Failed to load BIOS file";
        Log("[MCP] LoadBios failed: %s", file_path.c_str());
        return result;
    }

    bool known_revision = crc == metadata->crc;

    result["success"] = true;
    result["file_path"] = file_path;
    result["role"] = metadata->role_name;
    result["size"] = actual_size;
    result["crc32"] = AdamHex(crc, 8);
    result["known_revision"] = known_revision;

    if (!emu_is_empty() && (emu_get_machine() == GC_MACHINE_ADAM))
        result["note"] = "ADAM is running; firmware will be used on next ADAM power-on";

    if (!known_revision)
        result["warning"] = std::string("CRC does not match the known ") + metadata->role_name + " revision (" +
            AdamHex(metadata->crc, 8) + ")";

    return result;
}

json DebugAdapter::LoadSymbols(const std::string& file_path)
{
    json result;

    if (file_path.empty())
    {
        result["error"] = "File path is required";
        Log("[MCP] LoadSymbols failed: File path is required");
        return result;
    }

    gui_debug_load_symbols_file(file_path.c_str());

    result["success"] = true;
    result["file_path"] = file_path;

    return result;
}

json DebugAdapter::ListSaveStateSlots()
{
    json result;
    json slots = json::array();
    json empty_slots = json::array();

    update_savestates_data();

    for (int i = 0; i < 5; i++)
    {
        json slot;
        slot["slot"] = i + 1;

        if (emu_savestates[i].rom_name[0] != 0)
        {
            slot["rom_name"] = emu_savestates[i].rom_name;
            slot["timestamp"] = emu_savestates[i].timestamp;
            slot["version"] = emu_savestates[i].version;
            slot["valid"] = (emu_savestates[i].version >= GC_SAVESTATE_MIN_VERSION && emu_savestates[i].version <= GC_SAVESTATE_VERSION);
            slot["has_screenshot"] = IsValidPointer(emu_savestates_screenshots[i].data);

            if (emu_savestates[i].emu_build[0] != 0)
                slot["emu_build"] = emu_savestates[i].emu_build;

            slots.push_back(slot);
        }
        else
        {
            empty_slots.push_back(i + 1);
        }
    }

    result["current_slot"] = config_emulator.save_slot + 1;
    result["empty_slots"] = empty_slots;
    result["slots"] = slots;

    return result;
}

json DebugAdapter::SelectSaveStateSlot(int slot)
{
    json result;

    if (slot < 1 || slot > 5)
    {
        result["error"] = "Invalid slot number (must be 1-5)";
        Log("[MCP] SelectSaveStateSlot failed: Invalid slot %d", slot);
        return result;
    }

    config_emulator.save_slot = slot - 1;

    result["success"] = true;
    result["slot"] = slot;

    return result;
}

json DebugAdapter::SaveState()
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        Log("[MCP] SaveState failed: No media loaded");
        return result;
    }

    int slot = config_emulator.save_slot + 1;
    if (!emu_save_state_slot(slot))
    {
        result["error"] = "Failed to save state slot";
        Log("[MCP] SaveState failed: Slot %d", slot);
        return result;
    }

    result["success"] = true;
    result["slot"] = slot;
    result["content_name"] = emu_get_content_name();

    return result;
}

json DebugAdapter::LoadState()
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        Log("[MCP] LoadState failed: No media loaded");
        return result;
    }

    int slot = config_emulator.save_slot + 1;

    update_savestates_data();

    if (emu_savestates[config_emulator.save_slot].rom_name[0] == 0)
    {
        result["error"] = "Save state slot is empty";
        Log("[MCP] LoadState failed: Slot %d is empty", slot);
        return result;
    }

    if (!emu_load_state_slot(slot))
    {
        result["error"] = "Failed to load state slot";
        Log("[MCP] LoadState failed: Slot %d", slot);
        return result;
    }

    result["success"] = true;
    result["slot"] = slot;

    return result;
}

json DebugAdapter::SaveStateFile(const std::string& file_path)
{
    json result;

    if (file_path.empty())
    {
        result["error"] = "File path is required";
        Log("[MCP] SaveStateFile failed: File path is required");
        return result;
    }

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        Log("[MCP] SaveStateFile failed: No media loaded");
        return result;
    }

    if (!m_core->SaveState(file_path.c_str(), -1, m_core->GetMachine() == GC_MACHINE_ADAM))
    {
        result["error"] = "Failed to save state file";
        Log("[MCP] SaveStateFile failed: %s", file_path.c_str());
        return result;
    }

    result["success"] = true;
    result["file_path"] = file_path;

    return result;
}

json DebugAdapter::LoadStateFile(const std::string& file_path)
{
    json result;

    if (file_path.empty())
    {
        result["error"] = "File path is required";
        Log("[MCP] LoadStateFile failed: File path is required");
        return result;
    }

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        Log("[MCP] LoadStateFile failed: No media loaded");
        return result;
    }

    if (!m_core->LoadState(file_path.c_str()))
    {
        result["error"] = "Failed to load state file";
        Log("[MCP] LoadStateFile failed: %s", file_path.c_str());
        return result;
    }

    emu_debug_state_restored();
    emu_reconcile_adam_media_after_state_load();
    emu_restore_adam_state_screenshot(file_path.c_str());
    events_sync_input();
    rewind_reset();
    runahead_reset();

    result["success"] = true;
    result["file_path"] = file_path;

    return result;
}

json DebugAdapter::SetFastForwardSpeed(int speed)
{
    json result;

    if (speed < 0 || speed > 4)
    {
        result["error"] = "Invalid speed (must be 0-4: 0=1.5x, 1=2x, 2=2.5x, 3=3x, 4=Unlimited)";
        Log("[MCP] SetFastForwardSpeed failed: Invalid speed %d", speed);
        return result;
    }

    config_emulator.ffwd_speed = speed;

    result["success"] = true;
    result["speed"] = speed;

    const char* speed_names[] = {"1.5x", "2x", "2.5x", "3x", "Unlimited"};
    result["speed_name"] = speed_names[speed];

    return result;
}

json DebugAdapter::ToggleFastForward(bool enabled)
{
    json result;

    config_emulator.ffwd = enabled;
    gui_action_ffwd();

    result["success"] = true;
    result["enabled"] = enabled;
    result["speed"] = config_emulator.ffwd_speed;

    return result;
}

json DebugAdapter::GetRewindStatus()
{
    json result;

    result["active"] = rewind_is_active();
    result["snapshot_count"] = rewind_get_snapshot_count();
    result["capacity"] = rewind_get_capacity();
    result["frames_per_snapshot"] = rewind_get_frames_per_snapshot();
    result["memory_usage"] = rewind_get_memory_usage();
    result["enabled"] = config_rewind.enabled;
    result["buffer_seconds"] = config_rewind.buffer_seconds;
    result["speed"] = config_rewind.speed;

    return result;
}

json DebugAdapter::RewindSeek(int snapshot)
{
    json result;

    int count = rewind_get_snapshot_count();
    if (snapshot < 0 || snapshot >= count)
    {
        result["error"] = "Invalid snapshot index";
        return result;
    }

    bool success = gui_debug_rewind_seek(snapshot);
    result["success"] = success;
    result["snapshot"] = snapshot;
    result["total_snapshots"] = count;

    return result;
}

json DebugAdapter::ControllerButton(int player, const std::string& button, const std::string& action)
{
    json result;

    if (action != "press" && action != "release" && action != "press_and_release")
    {
        result["error"] = "Invalid action (must be: press, release, press_and_release)";
        return result;
    }

    if (player < 1 || player > 2)
    {
        result["error"] = "Invalid player number (must be 1-2)";
        return result;
    }
    GC_Controllers joypad = static_cast<GC_Controllers>(player - 1);

    std::string button_lower = button;
    std::transform(button_lower.begin(), button_lower.end(), button_lower.begin(), ::tolower);

    GC_Keys key = Key_Up; // default to a valid key, overwritten below
    bool found = false;
    if (button_lower == "up") { key = Key_Up; found = true; }
    else if (button_lower == "down") { key = Key_Down; found = true; }
    else if (button_lower == "left") { key = Key_Left; found = true; }
    else if (button_lower == "right") { key = Key_Right; found = true; }
    else if (button_lower == "1") { key = Keypad_1; found = true; }
    else if (button_lower == "2") { key = Keypad_2; found = true; }
    else if (button_lower == "3") { key = Keypad_3; found = true; }
    else if (button_lower == "4") { key = Keypad_4; found = true; }
    else if (button_lower == "5") { key = Keypad_5; found = true; }
    else if (button_lower == "6") { key = Keypad_6; found = true; }
    else if (button_lower == "7") { key = Keypad_7; found = true; }
    else if (button_lower == "8") { key = Keypad_8; found = true; }
    else if (button_lower == "9") { key = Keypad_9; found = true; }
    else if (button_lower == "0") { key = Keypad_0; found = true; }
    else if (button_lower == "asterisk" || button_lower == "*") { key = Keypad_Asterisk; found = true; }
    else if (button_lower == "hash" || button_lower == "#") { key = Keypad_Hash; found = true; }
    else if (button_lower == "left_button" || button_lower == "yellow" || button_lower == "fire1") { key = Key_Left_Button; found = true; }
    else if (button_lower == "right_button" || button_lower == "red" || button_lower == "fire2") { key = Key_Right_Button; found = true; }
    else if (button_lower == "blue") { key = Key_Blue; found = true; }
    else if (button_lower == "purple") { key = Key_Purple; found = true; }

    if (!found)
    {
        result["error"] = "Invalid button name (up, down, left, right, 0-9, asterisk, hash, left_button, right_button, yellow, red, fire1, fire2, blue, purple)";
        return result;
    }

    if (action == "press")
    {
        emu_key_pressed(joypad, key);
    }
    else if (action == "release")
    {
        emu_key_released(joypad, key);
    }
    else if (action == "press_and_release")
    {
        emu_key_pressed(joypad, key);
        result["__delayed_release"] = true;
    }

    result["success"] = true;
    result["player"] = player;
    result["button"] = button;
    result["action"] = action;

    return result;
}

json DebugAdapter::AdamKeyboard(const std::string& key, const std::string& action)
{
    if (!m_core || !m_core->IsReady() || (m_core->GetMachine() != GC_MACHINE_ADAM))
        return {{"error", "ADAM is not running"}};
    if ((action != "press") && (action != "release") && (action != "tap"))
        return {{"error", "Invalid action (must be: press, release, tap)"}};

    std::string key_name = key;
    std::transform(key_name.begin(), key_name.end(), key_name.begin(), ::tolower);
    GC_AdamKey adam_key = GC_ADAM_KEY_COUNT;
    if ((key_name.length() == 1) && (key_name[0] >= 'a') && (key_name[0] <= 'z'))
        adam_key = (GC_AdamKey)(GC_ADAM_KEY_A + key_name[0] - 'a');
    else if ((key_name.length() == 1) && (key_name[0] >= '0') && (key_name[0] <= '9'))
        adam_key = (GC_AdamKey)(GC_ADAM_KEY_0 + key_name[0] - '0');
    else
    {
        static const char* names[] = {
            "space", "minus", "plus", "caret", "semicolon", "quote", "open_bracket",
            "close_bracket", "backslash", "comma", "period", "slash", "return",
            "escape", "backspace", "tab", "home", "smart_1", "smart_2", "smart_3",
            "smart_4", "smart_5", "smart_6", "wild_card", "undo", "move", "store",
            "insert", "print", "clear", "delete", "up", "right", "down", "left",
            "shift", "control", "lock"
        };
        for (int i = 0; i < (int)(sizeof(names) / sizeof(names[0])); i++)
        {
            if (key_name == names[i])
            {
                adam_key = (GC_AdamKey)(GC_ADAM_KEY_SPACE + i);
                break;
            }
        }
        if (key_name == "enter") adam_key = GC_ADAM_KEY_RETURN;
        else if (key_name == "esc") adam_key = GC_ADAM_KEY_ESCAPE;
        else if (key_name == "ctrl") adam_key = GC_ADAM_KEY_CONTROL;
    }

    if (adam_key == GC_ADAM_KEY_COUNT)
        return {{"error", "Invalid ADAM key name"}};

    if ((action == "press") || (action == "tap"))
        emu_adam_key_pressed(adam_key);
    if ((action == "release") || (action == "tap"))
        emu_adam_key_released(adam_key);
    return {{"success", true}, {"key", key_name}, {"action", action}};
}

static json KeyMapLayer(KeyMap* key_map, GC_KeyMapLayer layer)
{
    json entries = json::object();

    for (int usage = 0; usage < GC_HOST_KEY_COUNT; usage++)
    {
        const GC_KeyMapEntry& entry = key_map->GetLayerEntry(layer, (u16)usage);
        const char* name = KeyMap::GetHostKeyName((u16)usage);

        if (entry.set && IsValidPointer(name))
            entries[name] = KeyMap::FormatTargets(entry);
    }

    return entries;
}

json DebugAdapter::GetKeyMap()
{
    KeyMap* key_map = m_core->GetKeyMap();
    bool reached[GC_ADAM_KEY_COUNT] = { };
    json remapped = json::object();

    for (int usage = 0; usage < GC_HOST_KEY_COUNT; usage++)
    {
        GC_KeyMapLayer layer = GC_KEY_MAP_BUILT_IN;
        const GC_KeyMapEntry& entry = key_map->GetEntry((u16)usage, &layer);
        const char* name = KeyMap::GetHostKeyName((u16)usage);

        for (int i = 0; i < entry.count; i++)
            reached[entry.keys[i]] = true;

        if ((layer != GC_KEY_MAP_BUILT_IN) && IsValidPointer(name))
            remapped[name] = KeyMap::FormatTargets(entry);
    }

    json unreachable = json::array();

    for (int key = 0; key < GC_ADAM_KEY_COUNT; key++)
    {
        const char* name = KeyMap::GetKeyName((GC_AdamKey)key);

        if (IsValidPointer(name) && !reached[key])
            unreachable.push_back(name);
    }

    json result;
    result["enabled"] = key_map->IsEnabled();
    result["mapper_open"] = m_core->GetKeyMapper()->IsOpen();
    result["file"] = emu_key_map_get_path();
    result["user"] = KeyMapLayer(key_map, GC_KEY_MAP_USER);
    result["remapped"] = remapped;
    result["unreachable"] = unreachable;
    return result;
}

json DebugAdapter::SetKeyBinding(const std::string& host, const std::string& keys)
{
    if (!m_core || !m_core->IsReady() || (m_core->GetMachine() != GC_MACHINE_ADAM))
        return {{"error", "ADAM is not running"}};

    KeyMap* key_map = m_core->GetKeyMap();
    u16 usage = 0;
    GC_KeyMapEntry entry;
    std::string error;

    if (keys == "default")
    {
        int found = KeyMap::FindHostKey(host.c_str());

        if (found < 0)
            return {{"error", "Unknown host key " + host}};

        GC_KeyMapEntry empty;
        memset(&empty, 0, sizeof(empty));
        key_map->SetEntry(GC_KEY_MAP_USER, (u16)found, empty);
        key_map->SetChanged(true);
        usage = (u16)found;
    }
    else
    {
        if (!KeyMap::ParseEntry(host, keys, &usage, &entry, &error))
            return {{"error", error}};

        GC_AdamKey targets[GC_KEY_MAP_TARGETS];

        for (int i = 0; i < entry.count; i++)
            targets[i] = (GC_AdamKey)entry.keys[i];

        key_map->Bind(usage, targets, entry.count);
    }

    emu_key_map_save();
    return {{"success", true}, {"host", KeyMap::GetHostKeyName(usage)},
        {"keys", KeyMap::FormatTargets(key_map->GetEntry(usage))}, {"file", emu_key_map_get_path()}};
}

json DebugAdapter::SetKeyMapping(bool enabled)
{
    if (m_core->GetKeyMap()->IsEnabled() != enabled)
        emu_key_mapping_toggle();

    return {{"success", true}, {"enabled", m_core->GetKeyMap()->IsEnabled()}};
}

json DebugAdapter::HostKey(const std::string& key, const std::string& action)
{
    if (!m_core || !m_core->IsReady() || (m_core->GetMachine() != GC_MACHINE_ADAM))
        return {{"error", "ADAM is not running"}};

    std::string name = key;
    std::transform(name.begin(), name.end(), name.begin(), ::tolower);
    int usage = KeyMap::FindHostKey(name.c_str());

    if (usage < 0)
        return {{"error", "Unknown host key '" + key + "'"}};

    bool delayed_release = false;

    if (action == "press")
        emu_adam_host_key_pressed(usage);
    else if (action == "release")
        emu_adam_host_key_released(usage);
    else if (action == "press_and_release")
    {
        emu_adam_host_key_pressed(usage);

        if (m_core->GetKeyMapper()->IsOpen())
            emu_adam_host_key_released(usage);
        else
            delayed_release = true;
    }
    else
        return {{"error", "Invalid action (must be: press, release, press_and_release)"}};

    json result = {{"success", true}, {"key", KeyMap::GetHostKeyName((u16)usage)}, {"action", action},
        {"drives", KeyMap::FormatTargets(m_core->GetKeyMap()->GetEntry((u16)usage))}};

    if (delayed_release)
        result["__delayed_host_release"] = usage;

    return result;
}

json DebugAdapter::SetKeyMapperOpen(bool open)
{
    if (!m_core || !m_core->IsReady() || (m_core->GetMachine() != GC_MACHINE_ADAM))
        return {{"error", "ADAM is not running"}};

    if (emu_key_mapper_is_open() != open)
        emu_key_mapper_toggle();

    return {{"success", true}, {"open", emu_key_mapper_is_open()}};
}

json DebugAdapter::GetInputState()
{
    static const char* button_names[] = {
        "up", "down", "left", "right", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
        "asterisk", "hash", "left_button", "right_button", "blue", "purple"
    };
    static const GC_Keys button_keys[] = {
        Key_Up, Key_Down, Key_Left, Key_Right, Keypad_0, Keypad_1, Keypad_2, Keypad_3, Keypad_4, Keypad_5,
        Keypad_6, Keypad_7, Keypad_8, Keypad_9, Keypad_Asterisk, Keypad_Hash, Key_Left_Button, Key_Right_Button,
        Key_Blue, Key_Purple
    };

    json players = json::array();
    Input* input = m_core->GetInput();

    for (int player = 0; player < 2; player++)
    {
        json pressed = json::array();
        GC_Controllers controller = static_cast<GC_Controllers>(player);

        for (size_t i = 0; i < sizeof(button_keys) / sizeof(button_keys[0]); i++)
        {
            if (input->IsKeyPressed(controller, button_keys[i]))
                pressed.push_back(button_names[i]);
        }

        players.push_back({{"player", player + 1}, {"pressed", pressed}});
    }

    return {{"players", players}};
}

json DebugAdapter::ListSprites()
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    Video* video = m_core->GetVideo();
    u8* vram = video->GetVRAM();
    u8* regs = video->GetRegisters();

    bool sprite_16x16 = (regs[1] & 0x02) != 0;
    int sprite_height = sprite_16x16 ? 16 : 8;

    json sprites = json::array();

    u16 sat_addr = (regs[5] & 0x7F) << 7;

    for (int s = 0; s < GC_MAX_SPRITES; s++)
    {
        u8 y = vram[sat_addr + s * 4];
        if (y == 0xD0) break;
        u8 x = vram[sat_addr + s * 4 + 1];
        u8 pattern = vram[sat_addr + s * 4 + 2];
        u8 color_ec = vram[sat_addr + s * 4 + 3];

        json sprite_info;
        sprite_info["index"] = s;
        sprite_info["x"] = (int)x;
        sprite_info["y"] = (int)y;
        sprite_info["pattern"] = (int)pattern;
        sprite_info["color"] = (int)(color_ec & 0x0F);
        sprite_info["early_clock"] = (color_ec & 0x80) != 0;
        sprite_info["size"] = std::string(sprite_16x16 ? "16x" : "8x") + std::to_string(sprite_height);

        sprites.push_back(sprite_info);
    }

    result["sprites"] = sprites;

    return result;
}

json DebugAdapter::GetSpriteImage(int sprite_index)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    if (sprite_index < 0 || sprite_index >= GC_MAX_SPRITES)
    {
        result["error"] = "Invalid sprite index (must be 0-31)";
        return result;
    }

    unsigned char* png_buffer = NULL;
    int png_size = emu_get_sprite_png(sprite_index, &png_buffer);

    if (png_size == 0 || !png_buffer)
    {
        result["error"] = "Failed to capture sprite";
        return result;
    }

    Video* video = m_core->GetVideo();
    u8* regs = video->GetRegisters();
    bool sprite_16x16 = (regs[1] & 0x02) != 0;
    int width = sprite_16x16 ? 16 : 8;
    int height = sprite_16x16 ? 16 : 8;

    std::string base64_png = base64_encode(png_buffer, png_size);
    free(png_buffer);

    result["__mcp_image"] = true;
    result["data"] = base64_png;
    result["mimeType"] = "image/png";
    result["width"] = width;
    result["height"] = height;
    result["sprite_index"] = sprite_index;

    return result;
}

// Disassembler operations

json DebugAdapter::RunToAddress(u16 address)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    gui_debug_runto_address(address);

    result["success"] = true;
    result["address"] = address;

    return result;
}

json DebugAdapter::AddDisassemblerBookmark(u16 address, const std::string& name)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    gui_debug_add_disassembler_bookmark(address, name.c_str());

    result["success"] = true;
    result["address"] = address;
    result["name"] = name.empty() ? "auto-generated" : name;

    return result;
}

json DebugAdapter::RemoveDisassemblerBookmark(u16 address)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    gui_debug_remove_disassembler_bookmark(address);

    result["success"] = true;
    result["address"] = address;

    return result;
}

json DebugAdapter::AddSymbol(u8 bank, u16 address, const std::string& name)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    char symbol[128];
    snprintf(symbol, sizeof(symbol), "%02X:%04X %s", bank, address, name.c_str());
    gui_debug_add_symbol(symbol);

    result["success"] = true;
    result["bank"] = bank;
    result["address"] = address;
    result["name"] = name;

    return result;
}

json DebugAdapter::RemoveSymbol(u8 bank, u16 address)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    gui_debug_remove_symbol(bank, address);

    result["success"] = true;
    result["bank"] = bank;
    result["address"] = address;

    return result;
}

// Memory editor operations

json DebugAdapter::SelectMemoryRange(int editor, int start_address, int end_address)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    if (editor < 0 || editor >= MEMORY_EDITOR_MAX)
    {
        result["error"] = "Invalid editor number";
        return result;
    }

    MemoryAreaInfo info = GetMemoryAreaInfo(editor);
    if ((!IsValidPointer(info.data) && !info.virtual_area) || info.size == 0)
    {
        result["error"] = "Memory area unavailable";
        return result;
    }

    u32 start_offset = 0;
    u32 end_offset = 0;
    if (!NormalizeMemoryAreaAddress(info, (u32)start_address, &start_offset) ||
        !NormalizeMemoryAreaAddress(info, (u32)end_address, &end_offset))
    {
        result["error"] = "Selection range outside memory area";
        return result;
    }

    if (start_offset > end_offset)
        std::swap(start_offset, end_offset);

    u32 display_start = info.display_base + start_offset;
    u32 display_end = info.display_base + end_offset;

    if (!gui_debug_memory_select_range(editor, (int)display_start, (int)display_end))
    {
        result["error"] = "Unable to apply memory selection";
        return result;
    }

    int actual_start = -1;
    int actual_end = -1;
    gui_debug_memory_get_selection(editor, &actual_start, &actual_end);
    if (actual_start < 0 || actual_end < actual_start || (u32)actual_end >= info.size)
    {
        result["error"] = "Unable to read applied memory selection";
        return result;
    }

    u32 actual_display_start = info.display_base + (u32)actual_start;
    u32 actual_display_end = info.display_base + (u32)actual_end;

    std::ostringstream start_ss, end_ss;
    start_ss << std::hex << std::uppercase << std::setfill('0') << std::setw(4) << actual_display_start;
    end_ss << std::hex << std::uppercase << std::setfill('0') << std::setw(4) << actual_display_end;

    result["success"] = true;
    result["area"] = editor;
    result["start_address"] = start_ss.str();
    result["end_address"] = end_ss.str();

    return result;
}

json DebugAdapter::SetMemorySelectionValue(int editor, u8 value)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    if (editor < 0 || editor >= MEMORY_EDITOR_MAX)
    {
        result["error"] = "Invalid editor number";
        return result;
    }

    gui_debug_memory_set_selection_value(editor, value);

    result["success"] = true;
    result["editor"] = editor;
    result["value"] = value;

    return result;
}

json DebugAdapter::AddMemoryBookmark(int editor, int address, const std::string& name)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    if (editor < 0 || editor >= MEMORY_EDITOR_MAX)
    {
        result["error"] = "Invalid editor number";
        return result;
    }

    MemoryAreaInfo info = GetMemoryAreaInfo(editor);
    int display_address = MemoryEditorOffsetToDisplayAddress(info, address);
    gui_debug_memory_add_bookmark(editor, display_address, name.c_str());

    result["success"] = true;
    result["editor"] = editor;
    result["address"] = address;
    result["name"] = name.empty() ? "auto-generated" : name;

    return result;
}

json DebugAdapter::RemoveMemoryBookmark(int editor, int address)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    if (editor < 0 || editor >= MEMORY_EDITOR_MAX)
    {
        result["error"] = "Invalid editor number";
        return result;
    }

    MemoryAreaInfo info = GetMemoryAreaInfo(editor);
    int display_address = MemoryEditorOffsetToDisplayAddress(info, address);
    gui_debug_memory_remove_bookmark(editor, display_address);

    result["success"] = true;
    result["editor"] = editor;
    result["address"] = address;

    return result;
}

json DebugAdapter::AddMemoryWatch(int editor, int address, const std::string& notes, int size)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    if (editor < 0 || editor >= MEMORY_EDITOR_MAX)
    {
        result["error"] = "Invalid editor number";
        return result;
    }

    MemoryAreaInfo info = GetMemoryAreaInfo(editor);
    u32 offset = 0;
    if (!NormalizeMemoryAreaAddress(info, (u32)address, &offset))
    {
        result["error"] = "Watch address outside memory area";
        return result;
    }

    int display_address = MemoryEditorOffsetToDisplayAddress(info, (int)offset);
    if (!gui_debug_memory_add_watch(editor, display_address, notes.c_str(), size))
    {
        result["error"] = "Unable to add memory watch";
        return result;
    }

    result["success"] = true;
    result["editor"] = editor;
    result["address"] = address;
    result["notes"] = notes;
    result["size"] = size;

    return result;
}

json DebugAdapter::RemoveMemoryWatch(int editor, int address)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    if (editor < 0 || editor >= MEMORY_EDITOR_MAX)
    {
        result["error"] = "Invalid editor number";
        return result;
    }

    MemoryAreaInfo info = GetMemoryAreaInfo(editor);
    int display_address = MemoryEditorOffsetToDisplayAddress(info, address);
    gui_debug_memory_remove_watch(editor, display_address);

    result["success"] = true;
    result["editor"] = editor;
    result["address"] = address;

    return result;
}

json DebugAdapter::ListDisassemblerBookmarks()
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    void* bookmarks_ptr = NULL;
    int count = gui_debug_get_disassembler_bookmarks(&bookmarks_ptr);

    std::vector<DisassemblerBookmark>* bookmarks = (std::vector<DisassemblerBookmark>*)bookmarks_ptr;

    json bookmarks_array = json::array();

    if (bookmarks)
    {
        for (const DisassemblerBookmark& bookmark : *bookmarks)
        {
            json bookmark_obj;

            std::ostringstream addr_ss;
            addr_ss << std::hex << std::uppercase << std::setfill('0') << std::setw(4) << bookmark.address;
            bookmark_obj["address"] = addr_ss.str();
            bookmark_obj["name"] = bookmark.name;

            bookmarks_array.push_back(bookmark_obj);
        }
    }

    result["bookmarks"] = bookmarks_array;
    result["count"] = count;

    return result;
}

json DebugAdapter::ListSymbols()
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    json symbols_array = json::array();

    for (int bank = 0; bank < 0x100; bank++)
    {
        for (int address = 0; address < 0x10000; address++)
        {
            DebugSymbol* symbol = gui_debug_get_symbol(bank, address);

            if (IsValidPointer(symbol))
            {
                json symbol_obj;

                std::ostringstream bank_ss, addr_ss;
                bank_ss << std::hex << std::uppercase << std::setfill('0') << std::setw(2) << bank;
                addr_ss << std::hex << std::uppercase << std::setfill('0') << std::setw(4) << address;

                symbol_obj["bank"] = bank_ss.str();
                symbol_obj["address"] = addr_ss.str();
                symbol_obj["name"] = symbol->text;

                symbols_array.push_back(symbol_obj);
            }
        }
    }

    result["symbols"] = symbols_array;
    result["count"] = symbols_array.size();

    return result;
}

json DebugAdapter::LookupSymbolByName(const std::string& name)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    std::vector<DebugSymbol*> symbols;
    gui_debug_find_symbols(name.c_str(), symbols);

    json matches = json::array();
    for (size_t i = 0; i < symbols.size(); i++)
    {
        std::ostringstream bank_ss, address_ss;
        bank_ss << std::hex << std::uppercase << std::setfill('0') << std::setw(2) << symbols[i]->bank;
        address_ss << std::hex << std::uppercase << std::setfill('0') << std::setw(4) << symbols[i]->address;

        matches.push_back({
            {"bank", bank_ss.str()},
            {"address", address_ss.str()},
            {"name", symbols[i]->text}
        });
    }

    result["matches"] = matches;
    result["count"] = matches.size();
    return result;
}

json DebugAdapter::LookupSymbolAtAddress(u8 bank, u16 address)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    std::ostringstream bank_ss, address_ss;
    bank_ss << std::hex << std::uppercase << std::setfill('0') << std::setw(2) << (int)bank;
    address_ss << std::hex << std::uppercase << std::setfill('0') << std::setw(4) << address;

    DebugSymbol* symbol = gui_debug_get_symbol(bank, address);
    result["found"] = IsValidPointer(symbol);
    result["bank"] = bank_ss.str();
    result["address"] = address_ss.str();

    if (IsValidPointer(symbol))
        result["name"] = symbol->text;

    return result;
}

json DebugAdapter::ListCallStack()
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    Memory* memory = m_core->GetMemory();
    Processor* processor = m_core->GetProcessor();
    std::stack<Processor::GC_CallStackEntry> temp_stack = *processor->GetDisassemblerCallStack();

    json stack_array = json::array();

    while (!temp_stack.empty())
    {
        Processor::GC_CallStackEntry entry = temp_stack.top();
        temp_stack.pop();

        json entry_obj;

        std::ostringstream dest_ss, src_ss, back_ss;
        dest_ss << "$" << std::hex << std::uppercase << std::setfill('0') << std::setw(4) << entry.dest;
        src_ss << "$" << std::hex << std::uppercase << std::setfill('0') << std::setw(4) << entry.src;
        back_ss << "$" << std::hex << std::uppercase << std::setfill('0') << std::setw(4) << entry.back;

        entry_obj["function"] = dest_ss.str();
        entry_obj["source"] = src_ss.str();
        entry_obj["return"] = back_ss.str();

        GC_Disassembler_Record* record = memory->GetDisassemblerRecord(entry.dest);
        if (IsValidPointer(record) && record->name[0] != 0)
        {
            DebugSymbol* symbol = gui_debug_get_symbol(record->bank, entry.dest);
            if (IsValidPointer(symbol))
                entry_obj["symbol"] = symbol->text;
        }

        stack_array.push_back(entry_obj);
    }

    result["stack"] = stack_array;
    result["depth"] = stack_array.size();

    return result;
}

json DebugAdapter::ListMemoryBookmarks(int area)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    if (area < 0 || area >= MEMORY_EDITOR_MAX)
    {
        result["error"] = "Invalid area number";
        return result;
    }

    void* bookmarks_ptr = NULL;
    int count = gui_debug_memory_get_bookmarks(area, &bookmarks_ptr);
    MemoryAreaInfo info = GetMemoryAreaInfo(area);

    std::vector<MemEditor::Bookmark>* bookmarks = (std::vector<MemEditor::Bookmark>*)bookmarks_ptr;

    json bookmarks_array = json::array();

    if (bookmarks)
    {
        for (const MemEditor::Bookmark& bookmark : *bookmarks)
        {
            json bookmark_obj;
            int offset = MemoryEditorDisplayAddressToOffset(info, bookmark.address);

            std::ostringstream addr_ss;
            addr_ss << std::hex << std::uppercase << std::setfill('0') << std::setw(4) << offset;
            bookmark_obj["address"] = addr_ss.str();
            bookmark_obj["name"] = bookmark.name;

            bookmarks_array.push_back(bookmark_obj);
        }
    }

    result["area"] = area;
    result["bookmarks"] = bookmarks_array;
    result["count"] = count;

    return result;
}

json DebugAdapter::ListMemoryWatches(int area)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    if (area < 0 || area >= MEMORY_EDITOR_MAX)
    {
        result["error"] = "Invalid area number";
        return result;
    }

    void* watches_ptr = NULL;
    int count = gui_debug_memory_get_watches(area, &watches_ptr);
    MemoryAreaInfo info = GetMemoryAreaInfo(area);

    std::vector<MemEditor::Watch>* watches = (std::vector<MemEditor::Watch>*)watches_ptr;

    json watches_array = json::array();

    if (watches)
    {
        const char* size_names[] = {"8", "16", "24", "32"};
        const char* format_names[] = {"hex", "binary", "decimal_unsigned", "decimal_signed"};

        for (const MemEditor::Watch& watch : *watches)
        {
            json watch_obj;
            int offset = MemoryEditorDisplayAddressToOffset(info, watch.address);

            std::ostringstream addr_ss;
            addr_ss << std::hex << std::uppercase << std::setfill('0') << std::setw(4) << offset;
            watch_obj["address"] = addr_ss.str();
            watch_obj["notes"] = watch.notes;

            int size_idx = (watch.size >= 0 && watch.size <= 3) ? watch.size : 0;
            int fmt_idx = (watch.format >= 0 && watch.format <= 3) ? watch.format : 0;
            watch_obj["size"] = size_names[size_idx];
            watch_obj["format"] = format_names[fmt_idx];

            watches_array.push_back(watch_obj);
        }
    }

    result["area"] = area;
    result["watches"] = watches_array;
    result["count"] = count;

    return result;
}

json DebugAdapter::GetMemorySelection(int area)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    if (area < 0 || area >= MEMORY_EDITOR_MAX)
    {
        result["error"] = "Invalid area number";
        return result;
    }

    int start = -1;
    int end = -1;
    gui_debug_memory_get_selection(area, &start, &end);

    result["area"] = area;

    if (start >= 0 && end >= 0 && start <= end)
    {
        std::ostringstream start_ss, end_ss;
        start_ss << std::hex << std::uppercase << std::setfill('0') << std::setw(4) << start;
        end_ss << std::hex << std::uppercase << std::setfill('0') << std::setw(4) << end;

        result["selected"] = true;
        result["start"] = start_ss.str();
        result["end"] = end_ss.str();
        result["size"] = end - start + 1;
    }
    else
    {
        result["selected"] = false;
        result["size"] = 0;
    }

    return result;
}

json DebugAdapter::MemorySearchCapture(int area)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    if (area < 0 || area >= MEMORY_EDITOR_MAX)
    {
        result["error"] = "Invalid area number";
        return result;
    }

    gui_debug_memory_search_capture(area);

    result["success"] = true;
    result["area"] = area;

    return result;
}

json DebugAdapter::MemorySearch(int area, const std::string& op, const std::string& compare_type, int compare_value, const std::string& data_type)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    if (area < 0 || area >= MEMORY_EDITOR_MAX)
    {
        result["error"] = "Invalid area number";
        return result;
    }

    int op_index = 0;
    if (op == "<") op_index = 0;
    else if (op == ">") op_index = 1;
    else if (op == "==") op_index = 2;
    else if (op == "!=") op_index = 3;
    else if (op == "<=") op_index = 4;
    else if (op == ">=") op_index = 5;
    else
    {
        result["error"] = "Invalid operator";
        return result;
    }

    int compare_type_index = 0;
    if (compare_type == "previous") compare_type_index = 0;
    else if (compare_type == "value") compare_type_index = 1;
    else if (compare_type == "address") compare_type_index = 2;
    else
    {
        result["error"] = "Invalid compare_type";
        return result;
    }

    if (compare_type_index == 2)
    {
        MemoryAreaInfo info = GetMemoryAreaInfo(area);
        u32 compare_offset = 0;
        if (!NormalizeMemoryAreaAddress(info, (u32)compare_value, &compare_offset))
        {
            result["error"] = "Compare address outside memory area";
            return result;
        }

        compare_value = (int)compare_offset;
    }

    int data_type_index = 0;
    if (data_type == "hex") data_type_index = 0;
    else if (data_type == "signed") data_type_index = 1;
    else if (data_type == "unsigned") data_type_index = 2;
    else
    {
        result["error"] = "Invalid data_type";
        return result;
    }

    void* results_ptr = NULL;
    int count = gui_debug_memory_search(area, op_index, compare_type_index, compare_value, data_type_index, &results_ptr);

    result["area"] = area;
    result["count"] = count;
    result["fields"] = json::array({"address", "value", "previous"});
    result["results"] = json::array();

    if (count > 0 && results_ptr != NULL)
    {
        std::vector<MemEditor::Search>* results = (std::vector<MemEditor::Search>*)results_ptr;

        int max_results = (count > 1000) ? 1000 : count;

        for (int i = 0; i < max_results; i++)
        {
            MemEditor::Search& search = (*results)[i];
            json item = json::array();

            std::ostringstream addr_ss;
            addr_ss << std::hex << std::uppercase << std::setfill('0') << std::setw(4) << search.address;

            item.push_back(addr_ss.str());
            item.push_back(search.value);
            item.push_back(search.prev_value);

            result["results"].push_back(item);
        }

        if (count > 1000)
        {
            result["total_matches"] = count;
        }
    }

    return result;
}

json DebugAdapter::MemoryFind(int area, const std::string& value, bool text, bool case_sensitive)
{
    json result;

    if (!m_core || !m_core->IsReady())
    {
        result["error"] = "No media loaded";
        return result;
    }

    if (area < 0 || area >= MEMORY_EDITOR_MAX)
    {
        result["error"] = "Invalid area number";
        return result;
    }

    if (value.empty())
    {
        result["error"] = text ? "text is empty" : "hex_bytes is empty";
        return result;
    }

    int addresses[100];
    int count = gui_debug_memory_find(area, value.c_str(), text, case_sensitive, addresses, 100);

    if (count < 0)
    {
        if (text)
            result["error"] = "text must not exceed 512 bytes";
        else
            result["error"] = "hex_bytes must contain valid hex byte pairs";
        return result;
    }

    result["area"] = area;
    result["count"] = count;
    result["addresses"] = json::array();

    int max_results = (count > 100) ? 100 : count;

    for (int i = 0; i < max_results; i++)
    {
        std::ostringstream addr_ss;
        addr_ss << std::hex << std::uppercase << std::setfill('0') << std::setw(4) << addresses[i];
        result["addresses"].push_back(addr_ss.str());
    }

    if (count > 100)
    {
        result["total_matches"] = count;
    }

    return result;
}

json DebugAdapter::GetTraceLog(s64 start, int count)
{
    json result;
    const char* stop_reason = gui_debug_trace_logger_get_stop_reason();
    result["enabled"] = gui_debug_trace_logger_is_enabled();

    if (IsValidPointer(stop_reason))
        result["stopped_by"] = stop_reason;


    TraceLogger* tl = m_core->GetTraceLogger();
    if (!tl)
    {
        result["error"] = "Trace logger not available";
        return result;
    }

    u32 retained = tl->GetCount();
    u64 total = tl->GetSequence();
    u64 oldest = total - retained;

    if (count < 1) count = 100;
    if (count > 1000) count = 1000;

    u64 actual_start;
    bool overrun = false;
    if (start < 0)
    {
        u64 tail = (u64)(-(start + 1)) + 1;
        actual_start = (total - oldest > tail) ? (total - tail) : oldest;
    }
    else
    {
        actual_start = (u64)start;
        if (actual_start < oldest)
        {
            actual_start = oldest;
            overrun = true;
        }
    }

    if (actual_start >= total)
    {
        result["total_entries"] = retained;
        result["total_logged"] = total;
        result["oldest_sequence"] = oldest;
        result["start"] = actual_start;
        result["next_sequence"] = actual_start;
        result["count"] = 0;
        result["overrun"] = overrun;
        result["lines"] = json::array();
        return result;
    }

    u32 actual_count = (u32)count;
    if ((u64)actual_count > total - actual_start)
        actual_count = (u32)(total - actual_start);
    u32 buffer_start = (u32)(actual_start - oldest);

    json lines = json::array();
    for (u32 i = 0; i < actual_count; i++)
    {
        const GC_Trace_Entry& entry = tl->GetEntry(buffer_start + i);
        char buf[GC_TRACE_FORMAT_BUFFER_SIZE];

        GC_Trace_Format_Options options = {};
        options.bank = true;
        options.registers = true;
        options.flags = true;
        options.bytes = true;
        options.cycles = true;
        if (buffer_start + i > 0)
            options.previous = &tl->GetEntry(buffer_start + i - 1);
        trace_logger_format_entry(entry, options, buf, sizeof(buf));
        lines.push_back(buf);
    }

    result["total_entries"] = retained;
    result["total_logged"] = total;
    result["oldest_sequence"] = oldest;
    result["start"] = actual_start;
    result["next_sequence"] = actual_start + actual_count;
    result["count"] = actual_count;
    result["overrun"] = overrun;
    result["lines"] = lines;
    return result;
}

json DebugAdapter::SetTraceLog(const json& arguments)
{
    static const char* const k_vblank_watch_operations[] = { "read", "write", "read_write" };
    json result;

#if !defined(GEARCOLECO_DISABLE_DISASSEMBLER)
    TraceLogger* tl = m_core->GetTraceLogger();
    if (!tl)
    {
        result["error"] = "Trace logger not available";
        return result;
    }

    bool enabled = arguments["enabled"].get<bool>();
    if (!enabled)
    {
        if (!gui_debug_trace_logger_stop())
            return {{"error", "Unable to stop trace logger cleanly"}};
        return {{"status", "stopped"}, {"total_entries", tl->GetCount()}};
    }

    u32 flags = 0;
    u32 masks[TRACE_TYPE_COUNT] = {};
    json filters = arguments.contains("filters") ? arguments["filters"] : json::array({"cpu.instructions", "cpu.interrupts"});
    if (filters.empty())
        return {{"error", "filters must not be empty"}};
    for (size_t i = 0; i < filters.size(); i++)
        for (size_t j = i + 1; j < filters.size(); j++)
            if (filters[i] == filters[j]) return {{"error", "filters must contain unique values"}};

    for (json::const_iterator it = filters.begin(); it != filters.end(); ++it)
    {
        std::string filter = it->get<std::string>();
        if (filter == "cpu.instructions") flags |= TRACE_FLAG_CPU;
        else if (filter == "cpu.interrupts") flags |= TRACE_FLAG_CPU_IRQ;
        else if (filter == "vdp.registers") { flags |= TRACE_FLAG_VDP; masks[TRACE_VDP] |= TRACE_VDP_EVENT_REGISTERS; }
        else if (filter == "vdp.interrupts") { flags |= TRACE_FLAG_VDP; masks[TRACE_VDP] |= TRACE_VDP_EVENT_INTERRUPTS; }
        else if (filter == "vdp.status") { flags |= TRACE_FLAG_VDP; masks[TRACE_VDP] |= TRACE_VDP_EVENT_STATUS; }
        else if (filter == "vdp.sprites") { flags |= TRACE_FLAG_VDP; masks[TRACE_VDP] |= TRACE_VDP_EVENT_SPRITES; }
        else if (filter == "vdp.sprite_budget") { flags |= TRACE_FLAG_VDP; masks[TRACE_VDP] |= TRACE_VDP_EVENT_SPRITE_BUDGET; }
        else if (filter == "vdp.sprite_limit") { flags |= TRACE_FLAG_VDP; masks[TRACE_VDP] |= TRACE_VDP_EVENT_SPRITE_LIMIT; }
        else if (filter == "vdp.missed_vblank") { flags |= TRACE_FLAG_VDP; masks[TRACE_VDP] |= TRACE_VDP_EVENT_MISSED_VBLANK; }
        else if (filter == "vdp.timing") { flags |= TRACE_FLAG_VDP; masks[TRACE_VDP] |= TRACE_VDP_EVENT_TIMING; }
        else if (filter == "vdp.vram") { flags |= TRACE_FLAG_VDP; masks[TRACE_VDP] |= TRACE_VDP_EVENT_VRAM; }
        else if (filter == "psg.tone") { flags |= TRACE_FLAG_PSG; masks[TRACE_PSG] |= TRACE_PSG_EVENT_TONE; }
        else if (filter == "psg.volume") { flags |= TRACE_FLAG_PSG; masks[TRACE_PSG] |= TRACE_PSG_EVENT_VOLUME; }
        else if (filter == "psg.noise") { flags |= TRACE_FLAG_PSG; masks[TRACE_PSG] |= TRACE_PSG_EVENT_NOISE; }
        else if (filter == "ay8910.registers") { flags |= TRACE_FLAG_AY8910; masks[TRACE_AY8910] |= TRACE_AY8910_EVENT_REGISTERS; }
        else if (filter == "ay8910.tone") { flags |= TRACE_FLAG_AY8910; masks[TRACE_AY8910] |= TRACE_AY8910_EVENT_TONE; }
        else if (filter == "ay8910.noise_mixer") { flags |= TRACE_FLAG_AY8910; masks[TRACE_AY8910] |= TRACE_AY8910_EVENT_NOISE_MIXER; }
        else if (filter == "ay8910.volume") { flags |= TRACE_FLAG_AY8910; masks[TRACE_AY8910] |= TRACE_AY8910_EVENT_VOLUME; }
        else if (filter == "ay8910.envelope") { flags |= TRACE_FLAG_AY8910; masks[TRACE_AY8910] |= TRACE_AY8910_EVENT_ENVELOPE; }
        else if (filter == "ay8910.io") { flags |= TRACE_FLAG_AY8910; masks[TRACE_AY8910] |= TRACE_AY8910_EVENT_IO; }
        else if (filter == "io.reads") { flags |= TRACE_FLAG_IO; masks[TRACE_IO] |= TRACE_IO_EVENT_READS; }
        else if (filter == "io.writes") { flags |= TRACE_FLAG_IO; masks[TRACE_IO] |= TRACE_IO_EVENT_WRITES; }
        else if (filter == "input.reads") { flags |= TRACE_FLAG_INPUT; masks[TRACE_INPUT] |= TRACE_INPUT_EVENT_READS; }
        else if (filter == "input.writes") { flags |= TRACE_FLAG_INPUT; masks[TRACE_INPUT] |= TRACE_INPUT_EVENT_WRITES; }
        else if (filter == "sgm.control") { flags |= TRACE_FLAG_SGM; masks[TRACE_SGM] |= TRACE_SGM_EVENT_CONTROL; }
        else if (filter == "adam.map") { flags |= TRACE_FLAG_ADAM; masks[TRACE_ADAM] |= TRACE_ADAM_EVENT_MAP; }
        else if (filter == "adam.commands") { flags |= TRACE_FLAG_ADAM; masks[TRACE_ADAM] |= TRACE_ADAM_EVENT_COMMANDS; }
        else if (filter == "adam.dma") { flags |= TRACE_FLAG_ADAM; masks[TRACE_ADAM] |= TRACE_ADAM_EVENT_DMA; }
        else if (filter == "adam.errors") { flags |= TRACE_FLAG_ADAM; masks[TRACE_ADAM] |= TRACE_ADAM_EVENT_ERRORS; }
        else if (filter == "mapper.banks") { flags |= TRACE_FLAG_MAPPER; masks[TRACE_MAPPER] |= TRACE_MAPPER_EVENT_BANKS; }
        else if (filter == "mapper.eeprom") { flags |= TRACE_FLAG_MAPPER; masks[TRACE_MAPPER] |= TRACE_MAPPER_EVENT_EEPROM; }
        else if (filter == "mapper.sram") { flags |= TRACE_FLAG_MAPPER; masks[TRACE_MAPPER] |= TRACE_MAPPER_EVENT_SRAM; }
        else return {{"error", "unknown trace filter: " + filter}};
    }

    int output = gui_debug_trace_logger_is_enabled() ? config_debug.trace_output : gui_TraceOutput_Memory;
    if (arguments.contains("output"))
        output = arguments["output"] == "disk" ? gui_TraceOutput_Disk : gui_TraceOutput_Memory;
    int capacity_index = config_debug.trace_capacity;
    int disk_index = config_debug.trace_disk_size;
    if (arguments.contains("memory_size"))
        capacity_index = gui_debug_trace_logger_memory_size_index(arguments["memory_size"].get<std::string>().c_str());
    if (arguments.contains("disk_size"))
        disk_index = gui_debug_trace_logger_disk_size_index(arguments["disk_size"].get<std::string>().c_str());
    if (capacity_index < 0)
        return {{"error", "Unknown trace memory size"}};
    if (disk_index < 0)
        return {{"error", "Unknown trace disk size"}};
    int vblank_watch_address_value = config_debug.trace_vblank_watch_address;
    std::string vblank_watch_address = arguments.value("vblank_watch_address", "");
    if (!vblank_watch_address.empty())
    {
        u16 address = 0;
        if (!parse_hex_with_prefix(vblank_watch_address, &address))
            return {{"error", "Invalid vblank watch address"}};
        vblank_watch_address_value = address;
    }

    int vblank_watch_operation_value = config_debug.trace_vblank_watch_operation;
    std::string vblank_watch_operation = arguments.value("vblank_watch_operation", "");
    if (!vblank_watch_operation.empty())
    {
        vblank_watch_operation_value = -1;
        for (int i = 0; i < 3; i++)
        {
            if (vblank_watch_operation == k_vblank_watch_operations[i])
                vblank_watch_operation_value = i;
        }
        if (vblank_watch_operation_value < 0)
            return {{"error", "Invalid vblank watch operation"}};
    }

    bool custom_path = arguments.contains("output_path") && !arguments["output_path"].get<std::string>().empty();
    std::string requested_path = custom_path ? arguments["output_path"].get<std::string>() : std::string();
    bool storage_change = output != config_debug.trace_output;
    if (output == gui_TraceOutput_Memory)
        storage_change = storage_change || capacity_index != config_debug.trace_capacity;
    else
    {
        storage_change = storage_change || disk_index != config_debug.trace_disk_size;
        if (custom_path)
        {
            storage_change = storage_change || config_debug.trace_disk_dir_option != 2 ||
                requested_path != config_debug.trace_disk_path;
        }
    }
    if (gui_debug_trace_logger_is_enabled() && storage_change && !gui_debug_trace_logger_stop())
        return {{"error", "Unable to stop trace logger cleanly"}};

    if (!gui_debug_trace_logger_is_enabled())
    {
        const char* path = custom_path ? requested_path.c_str() : NULL;
        if (!gui_debug_trace_logger_configure(output, capacity_index, disk_index, path))
            return {{"error", "Unable to configure trace logger"}};
    }
    gui_debug_trace_logger_set_event_filters(masks);
    config_debug.trace_vblank_watch_address = vblank_watch_address_value;
    config_debug.trace_vblank_watch_operation = vblank_watch_operation_value;
    if (!gui_debug_trace_logger_start(flags))
        return {{"error", "Unable to start trace logger"}};
    json active_filters = json::array();
    if (flags & TRACE_FLAG_CPU) active_filters.push_back("cpu.instructions");
    if (flags & TRACE_FLAG_CPU_IRQ) active_filters.push_back("cpu.interrupts");
    if (masks[TRACE_VDP] & TRACE_VDP_EVENT_REGISTERS) active_filters.push_back("vdp.registers");
    if (masks[TRACE_VDP] & TRACE_VDP_EVENT_INTERRUPTS) active_filters.push_back("vdp.interrupts");
    if (masks[TRACE_VDP] & TRACE_VDP_EVENT_STATUS) active_filters.push_back("vdp.status");
    if (masks[TRACE_VDP] & TRACE_VDP_EVENT_SPRITES) active_filters.push_back("vdp.sprites");
    if (masks[TRACE_VDP] & TRACE_VDP_EVENT_SPRITE_BUDGET) active_filters.push_back("vdp.sprite_budget");
    if (masks[TRACE_VDP] & TRACE_VDP_EVENT_SPRITE_LIMIT) active_filters.push_back("vdp.sprite_limit");
    if (masks[TRACE_VDP] & TRACE_VDP_EVENT_MISSED_VBLANK) active_filters.push_back("vdp.missed_vblank");
    if (masks[TRACE_VDP] & TRACE_VDP_EVENT_TIMING) active_filters.push_back("vdp.timing");
    if (masks[TRACE_VDP] & TRACE_VDP_EVENT_VRAM) active_filters.push_back("vdp.vram");
    if (masks[TRACE_PSG] & TRACE_PSG_EVENT_TONE) active_filters.push_back("psg.tone");
    if (masks[TRACE_PSG] & TRACE_PSG_EVENT_VOLUME) active_filters.push_back("psg.volume");
    if (masks[TRACE_PSG] & TRACE_PSG_EVENT_NOISE) active_filters.push_back("psg.noise");
    if (masks[TRACE_AY8910] & TRACE_AY8910_EVENT_REGISTERS) active_filters.push_back("ay8910.registers");
    if (masks[TRACE_AY8910] & TRACE_AY8910_EVENT_TONE) active_filters.push_back("ay8910.tone");
    if (masks[TRACE_AY8910] & TRACE_AY8910_EVENT_NOISE_MIXER) active_filters.push_back("ay8910.noise_mixer");
    if (masks[TRACE_AY8910] & TRACE_AY8910_EVENT_VOLUME) active_filters.push_back("ay8910.volume");
    if (masks[TRACE_AY8910] & TRACE_AY8910_EVENT_ENVELOPE) active_filters.push_back("ay8910.envelope");
    if (masks[TRACE_AY8910] & TRACE_AY8910_EVENT_IO) active_filters.push_back("ay8910.io");
    if (masks[TRACE_IO] & TRACE_IO_EVENT_READS) active_filters.push_back("io.reads");
    if (masks[TRACE_IO] & TRACE_IO_EVENT_WRITES) active_filters.push_back("io.writes");
    if (masks[TRACE_INPUT] & TRACE_INPUT_EVENT_READS) active_filters.push_back("input.reads");
    if (masks[TRACE_INPUT] & TRACE_INPUT_EVENT_WRITES) active_filters.push_back("input.writes");
    if (masks[TRACE_SGM] & TRACE_SGM_EVENT_CONTROL) active_filters.push_back("sgm.control");
    if (masks[TRACE_ADAM] & TRACE_ADAM_EVENT_MAP) active_filters.push_back("adam.map");
    if (masks[TRACE_ADAM] & TRACE_ADAM_EVENT_COMMANDS) active_filters.push_back("adam.commands");
    if (masks[TRACE_ADAM] & TRACE_ADAM_EVENT_DMA) active_filters.push_back("adam.dma");
    if (masks[TRACE_ADAM] & TRACE_ADAM_EVENT_ERRORS) active_filters.push_back("adam.errors");
    if (masks[TRACE_MAPPER] & TRACE_MAPPER_EVENT_BANKS) active_filters.push_back("mapper.banks");
    if (masks[TRACE_MAPPER] & TRACE_MAPPER_EVENT_EEPROM) active_filters.push_back("mapper.eeprom");
    if (masks[TRACE_MAPPER] & TRACE_MAPPER_EVENT_SRAM) active_filters.push_back("mapper.sram");
    result = {{"status", "started"}, {"output", output ? "disk" : "memory"},
        {"memory_size", gui_debug_trace_logger_memory_size_name(capacity_index)},
        {"disk_size", gui_debug_trace_logger_disk_size_name(disk_index)},
        {"filters", active_filters}, {"total_entries", tl->GetCount()}};
    if (masks[TRACE_VDP] & TRACE_VDP_EVENT_MISSED_VBLANK)
    {
        char address[8];
        snprintf(address, sizeof(address), "%04X", config_debug.trace_vblank_watch_address);
        result["vblank_watch_address"] = address;
        result["vblank_watch_operation"] = k_vblank_watch_operations[config_debug.trace_vblank_watch_operation];
    }
    if (output == gui_TraceOutput_Disk)
        result["output_path"] = gui_debug_trace_logger_get_output_path();
#else
    UNUSED(arguments);
    result["error"] = "Trace logging not available in this build";
#endif

    return result;
}

struct ProfilerEntry
{
    u32 index;
    u64 key;
    std::string name;
    const char* symbol;
};

static const char* const k_profiler_type_names[] = { "root", "halt", "call", "irq" };

static bool profiler_entry_compare(const ProfilerEntry& a, const ProfilerEntry& b)
{
    if (a.key != b.key)
        return a.key > b.key;
    return a.index < b.index;
}

static double profiler_round(double value)
{
    return floor((value * 100.0) + 0.5) / 100.0;
}

json DebugAdapter::SetProfiler(const std::string& action)
{
    json result;

    Profiler* profiler = m_core->GetProfiler();
    if (!IsValidPointer(profiler))
    {
        result["error"] = "Profiler not available";
        return result;
    }

    if (action == "start")
    {
        if (!config_debug.debug)
        {
            config_debug.debug = true;
            emu_debug_continue();
        }
        gui_debug_profiler_show(true);
    }
    else if (action == "stop")
        gui_debug_profiler_show(false);
    else if (action == "reset")
    {
        profiler->Reset();
        gui_debug_profiler_reset();
    }
    else
    {
        result["error"] = "Invalid profiler action";
        return result;
    }

    result["success"] = true;
    result["action"] = action;
    result["window_open"] = config_debug.show_profiler;
    return result;
}

json DebugAdapter::GetProfilerData(const std::string& sort, int count, const std::string& filter)
{
    json result;

    Profiler* profiler = m_core->GetProfiler();
    if (!IsValidPointer(profiler) || !IsValidPointer(profiler->GetFunctions()))
    {
        result["error"] = "Profiler not available";
        return result;
    }

    if (count < 1)
        count = 50;
    if (count > 1000)
        count = 1000;

    profiler->Sync();

    const GC_Profiler_Function* functions = profiler->GetFunctions();
    u32 function_count = profiler->GetFunctionCount();
    u64 total = profiler->GetTotalCycles();
    u32 frame_cycles = gui_debug_profiler_get_frame_cycles();
    double frames = (frame_cycles > 0) ? (double)total / (double)frame_cycles : 0.0;

    std::string filter_upper = filter;
    std::transform(filter_upper.begin(), filter_upper.end(), filter_upper.begin(), ::toupper);

    std::vector<ProfilerEntry> entries;

    for (u32 i = 0; i < function_count; i++)
    {
        const GC_Profiler_Function& function = functions[i];
        bool pseudo = (function.type == PROFILER_FUNCTION_ROOT) || (function.type == PROFILER_FUNCTION_HALT);

        ProfilerEntry entry;
        entry.index = i;
        entry.key = 0;
        entry.symbol = "none";

        if (function.type == PROFILER_FUNCTION_ROOT)
            entry.name = "[Root]";
        else if (function.type == PROFILER_FUNCTION_HALT)
            entry.name = "[HALT]";
        else
        {
            bool is_manual = false;
            bool is_prebuilt = false;
            const char* name = gui_debug_get_symbol_name(function.bank, function.address, &is_manual, &is_prebuilt);
            if (IsValidPointer(name))
            {
                entry.name = name;
                entry.symbol = is_manual ? "manual" : (is_prebuilt ? "prebuilt" : "auto");
            }
        }

        if (!filter_upper.empty())
        {
            std::string name_upper = entry.name;
            std::transform(name_upper.begin(), name_upper.end(), name_upper.begin(), ::toupper);

            char address[8];
            snprintf(address, sizeof(address), "%04X", function.address);

            bool name_match = (name_upper.find(filter_upper) != std::string::npos);
            bool address_match = !pseudo && (std::string(address).find(filter_upper) != std::string::npos);

            if (!name_match && !address_match)
                continue;
        }

        if (sort == "exclusive")
            entry.key = function.exclusive_cycles;
        else if (sort == "calls")
            entry.key = function.calls;
        else if (sort == "average")
            entry.key = (function.completed > 0) ? function.inclusive_cycles / function.completed : 0;
        else if (sort == "max")
            entry.key = (function.completed > 0) ? function.max_cycles : 0;
        else
            entry.key = function.inclusive_cycles;

        entries.push_back(entry);
    }

    std::sort(entries.begin(), entries.end(), profiler_entry_compare);

    json functions_array = json::array();

    for (size_t i = 0; (i < entries.size()) && (i < (size_t)count); i++)
    {
        const GC_Profiler_Function& function = functions[entries[i].index];
        bool root = (function.type == PROFILER_FUNCTION_ROOT);
        bool pseudo = root || (function.type == PROFILER_FUNCTION_HALT);
        json item;
        char text[16];

        item["name"] = entries[i].name;
        item["type"] = k_profiler_type_names[function.type];

        if (!pseudo)
        {
            item["symbol"] = entries[i].symbol;
            snprintf(text, sizeof(text), "%02X", function.bank);
            item["bank"] = text;
            snprintf(text, sizeof(text), "%04X", function.address);
            item["address"] = text;
        }

        if (!root)
        {
            item["calls"] = function.calls;
            item["calls_per_frame"] = (frames > 0.0) ? profiler_round((double)function.calls / frames) : 0.0;
            item["inclusive_cycles"] = function.inclusive_cycles;
            item["inclusive_percent"] = (total > 0) ? profiler_round(((double)function.inclusive_cycles * 100.0) / (double)total) : 0.0;
        }

        item["exclusive_cycles"] = function.exclusive_cycles;
        item["exclusive_percent"] = (total > 0) ? profiler_round(((double)function.exclusive_cycles * 100.0) / (double)total) : 0.0;

        if (!root && (function.completed > 0))
        {
            item["average_cycles"] = function.inclusive_cycles / function.completed;
            item["min_cycles"] = function.min_cycles;
            item["max_cycles"] = function.max_cycles;
        }

        functions_array.push_back(item);
    }

    result["collecting"] = profiler->IsEnabled();
    result["window_open"] = config_debug.show_profiler;
    result["total_cycles"] = total;
    result["frame_cycles"] = frame_cycles;
    result["frames"] = profiler_round(frames);
    result["function_count"] = function_count - 2;
    result["sort"] = sort;
    result["count"] = functions_array.size();
    result["functions"] = functions_array;

    return result;
}
