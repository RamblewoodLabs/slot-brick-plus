/*
 * Gearcoleco - ColecoVision Emulator
 * Copyright (C) 2021  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#include <string.h>
#include "emu.h"
#include "config.h"
#include "events.h"
#include "Adam.h"
#include "AdamNet.h"

#define REWIND_IMPORT
#include "rewind.h"

static u8* buffer = NULL;
static size_t sizes[REWIND_MAX_SNAPSHOTS] = { 0 };
static std::stack<Processor::GC_CallStackEntry> call_stacks[REWIND_MAX_SNAPSHOTS];
static int head = 0;
static int count = 0;
static int capacity = 0;
static int frame_accum = 0;
static bool active = false;
static bool storage_dirty = true;
static int seek_age = -1;
static size_t slot_size = 0;
static size_t allocated_size = 0;
static size_t estimated_size = 0;
static int estimated_capacity = 0;
static bool capacity_limited = false;
static int snapshot_width = 0;
static int snapshot_height = 0;
static const size_t kAdamRewindMemoryLimit = 512U * 1024U * 1024U;

static int slot_at(int age);
static int get_target_capacity(void);
static int get_effective_capacity(size_t target_slot_size);
static size_t get_target_slot_size(void);
static bool ensure_storage(void);
static void release_storage(void);
static void truncate_to_seek_position(void);
static void restore_screenshot(const u8* slot, size_t size);

bool rewind_init(void)
{
    rewind_reset();
    return true;
}

void rewind_destroy(void)
{
    release_storage();
    count = 0;
    head = 0;
    frame_accum = 0;
    active = false;
    storage_dirty = true;
    seek_age = -1;
    estimated_size = 0;
    estimated_capacity = 0;
    capacity_limited = false;
}

void rewind_reset(void)
{
    head = 0;
    count = 0;
    frame_accum = 0;
    active = false;
    storage_dirty = true;
    seek_age = -1;
    estimated_size = 0;
    estimated_capacity = 0;
    capacity_limited = false;

    for (int i = 0; i < REWIND_MAX_SNAPSHOTS; i++)
        sizes[i] = 0;

    if (!config_rewind.enabled || emu_is_empty())
    {
        release_storage();
        return;
    }

    size_t target_slot_size = get_target_slot_size();
    if (target_slot_size > 0)
        get_effective_capacity(target_slot_size);
}

void rewind_push(void)
{
    if (!config_rewind.enabled)
        return;
    if (emu_is_empty() || emu_is_paused())
        return;
    if (active)
        return;

    frame_accum++;
    if (frame_accum < config_rewind.frames_per_snapshot)
        return;
    frame_accum = 0;

    GC_RuntimeInfo runtime;
    if (emu_get_core()->GetRuntimeInfo(runtime) && ((runtime.screen_width != snapshot_width) || (runtime.screen_height != snapshot_height)))
    {
        storage_dirty = true;
    }

    if (!ensure_storage())
        return;

    u8* slot = buffer + ((size_t)head * slot_size);
    size_t size = slot_size;

    if (!emu_get_core()->SaveState(slot, size, true))
    {
        storage_dirty = true;
        if (!ensure_storage())
            return;

        slot = buffer + ((size_t)head * slot_size);
        size = slot_size;
        if (!emu_get_core()->SaveState(slot, size, true))
        {
            Log("Rewind: failed to save snapshot into %zu-byte slot", slot_size);
            return;
        }
    }

    if (config_debug.debug)
        call_stacks[head] = *emu_get_core()->GetProcessor()->GetDisassemblerCallStack();
    else
        call_stacks[head] = std::stack<Processor::GC_CallStackEntry>();

    sizes[head] = size;
    head = (head + 1) % capacity;
    if (count < capacity)
        count++;
}

bool rewind_pop(void)
{
    if (count == 0)
        return false;
    if (!IsValidPointer(buffer))
        return false;

    int idx = slot_at(0);
    const u8* slot = buffer + ((size_t)idx * slot_size);
    size_t size = sizes[idx];

    bool ok = emu_get_core()->LoadState(slot, size);

    if (ok)
    {
        emu_debug_state_restored();
        *emu_get_core()->GetProcessor()->GetDisassemblerCallStack() = call_stacks[idx];
        restore_screenshot(slot, size);
        events_sync_input();
    }

    head = idx;
    count--;
    seek_age = -1;
    return ok;
}

void rewind_commit_seek(void)
{
    truncate_to_seek_position();
}

void rewind_set_active(bool a)
{
    active = a;
    if (!a)
        frame_accum = 0;
}

bool rewind_is_active(void)
{
    return active;
}

int rewind_get_snapshot_count(void)
{
    return count;
}

size_t rewind_get_memory_usage(void)
{
    return allocated_size;
}

size_t rewind_get_estimated_memory_usage(void)
{
    return estimated_size;
}

bool rewind_is_capacity_limited(void)
{
    return capacity_limited;
}

bool rewind_seek(int age)
{
    if (age < 0 || age >= count)
        return false;
    if (!IsValidPointer(buffer))
        return false;

    int idx = slot_at(age);
    const u8* slot = buffer + ((size_t)idx * slot_size);
    size_t size = sizes[idx];

    bool ok = emu_get_core()->LoadState(slot, size);

    if (ok)
    {
        emu_debug_state_restored();
        *emu_get_core()->GetProcessor()->GetDisassemblerCallStack() = call_stacks[idx];
        restore_screenshot(slot, size);
        events_sync_input();
        seek_age = age;
    }

    return ok;
}

int rewind_get_capacity(void)
{
    return estimated_capacity;
}

int rewind_get_frames_per_snapshot(void)
{
    return config_rewind.frames_per_snapshot;
}

static int slot_at(int age)
{
    int idx = head - 1 - age;
    while (idx < 0)
        idx += capacity;
    return idx;
}

static int get_target_capacity(void)
{
    int fps = config_rewind.frames_per_snapshot;
    if (fps < 1)
        fps = 1;

    int target = (config_rewind.buffer_seconds * 60 + fps - 1) / fps;
    if (target < 1)
        target = 1;
    if (target > REWIND_MAX_SNAPSHOTS)
        target = REWIND_MAX_SNAPSHOTS;

    return target;
}

static int get_effective_capacity(size_t target_slot_size)
{
    int target = get_target_capacity();
    capacity_limited = false;

    if ((emu_get_machine() == GC_MACHINE_ADAM) && (target_slot_size > 0) && ((size_t)target > (kAdamRewindMemoryLimit / target_slot_size)))
    {
        target = (int)(kAdamRewindMemoryLimit / target_slot_size);
        capacity_limited = true;
    }

    estimated_capacity = target;
    estimated_size = target > 0 ? (size_t)target * target_slot_size : 0;
    return target;
}

static size_t get_target_slot_size(void)
{
    if (emu_is_empty())
        return 0;

    size_t target_slot_size = 0;
    if (!emu_get_core()->SaveState(NULL, target_slot_size, true))
        return 0;

    if (emu_get_machine() == GC_MACHINE_ADAM)
    {
        // Printing can grow a state without changing media or resetting rewind
        AdamNet* adam_net = emu_get_core()->GetAdam()->GetAdamNet();
        target_slot_size += AdamNet::kPrinterSpoolSize - adam_net->GetPrinterSize();
    }

    return target_slot_size;
}

static bool ensure_storage(void)
{
    if (!config_rewind.enabled)
    {
        release_storage();
        return false;
    }

    int target_capacity = get_effective_capacity(slot_size);
    if (!storage_dirty && IsValidPointer(buffer) && (capacity == target_capacity))
        return true;

    size_t target_slot_size = get_target_slot_size();
    if (target_slot_size == 0)
        return false;

    target_capacity = get_effective_capacity(target_slot_size);
    if (target_capacity < 1)
    {
        Log("Rewind: ADAM state exceeds the %zu MB rewind memory limit", kAdamRewindMemoryLimit / (1024U * 1024U));
        release_storage();
        return false;
    }

    GC_RuntimeInfo runtime;
    bool runtime_valid = emu_get_core()->GetRuntimeInfo(runtime);

    if (storage_dirty && IsValidPointer(buffer) && (capacity == target_capacity) && (slot_size >= target_slot_size))
    {
        if (runtime_valid)
        {
            snapshot_width = runtime.screen_width;
            snapshot_height = runtime.screen_height;
        }

        storage_dirty = false;
        return true;
    }

    size_t target_size = (size_t)target_capacity * target_slot_size;
    u8* new_buffer = new (std::nothrow) u8[target_size];

    if (!IsValidPointer(new_buffer))
    {
        Log("Rewind: failed to allocate %zu bytes", target_size);
        return false;
    }

    SafeDeleteArray(buffer);
    buffer = new_buffer;
    allocated_size = target_size;
    slot_size = target_slot_size;
    capacity = target_capacity;
    head = 0;
    count = 0;
    frame_accum = 0;
    active = false;
    storage_dirty = false;
    seek_age = -1;

    if (runtime_valid)
    {
        snapshot_width = runtime.screen_width;
        snapshot_height = runtime.screen_height;
    }

    for (int i = 0; i < REWIND_MAX_SNAPSHOTS; i++)
        sizes[i] = 0;

    Log("Rewind: allocated %.1f MB ring buffer (%d snapshots, %zu-byte slots)",
        (double)target_size / (1024.0 * 1024.0), target_capacity, target_slot_size);

    return true;
}

static void release_storage(void)
{
    SafeDeleteArray(buffer);
    allocated_size = 0;
    slot_size = 0;
    capacity = 0;
    snapshot_width = 0;
    snapshot_height = 0;

    for (int i = 0; i < REWIND_MAX_SNAPSHOTS; i++)
        call_stacks[i] = std::stack<Processor::GC_CallStackEntry>();
}

static void truncate_to_seek_position(void)
{
    if (seek_age <= 0)
    {
        seek_age = -1;
        return;
    }

    int idx = slot_at(seek_age);
    head = (idx + 1) % capacity;
    count -= seek_age;
    seek_age = -1;
}

static void restore_screenshot(const u8* slot, size_t size)
{
    if (size <= sizeof(GC_SaveState_Header))
        return;

    GC_SaveState_Header header;
    memcpy(&header, slot + size - sizeof(GC_SaveState_Header), sizeof(header));

    if (header.magic != GC_SAVESTATE_MAGIC)
        return;
    if (header.screenshot_size == 0)
        return;

    size_t max_screenshot_size = (size_t)GC_VIDEO_MAX_WIDTH * GC_VIDEO_MAX_HEIGHT * 4;

    if (header.screenshot_size > max_screenshot_size)
        return;

    if (header.screenshot_size > (size - sizeof(GC_SaveState_Header)))
        return;

    size_t screenshot_offset = size - sizeof(GC_SaveState_Header) - header.screenshot_size;
    const u8* screenshot_data = slot + screenshot_offset;

    memcpy(emu_frame_buffer, screenshot_data, header.screenshot_size);
}
