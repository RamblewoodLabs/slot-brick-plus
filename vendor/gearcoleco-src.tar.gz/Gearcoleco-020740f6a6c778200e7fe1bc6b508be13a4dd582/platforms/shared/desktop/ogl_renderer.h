/*
 * Gearcoleco - ColecoVision Emulator
 * Copyright (C) 2021  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#ifndef OGL_RENDERER_H
#define OGL_RENDERER_H

#include <stdint.h>
#include "emu.h"

#ifdef OGL_RENDERER_IMPORT
    #define EXTERN
#else
    #define EXTERN extern
#endif

#define SYSTEM_TEXTURE_WIDTH EMU_FRAME_BUFFER_WIDTH
#define SYSTEM_TEXTURE_HEIGHT EMU_FRAME_BUFFER_HEIGHT

EXTERN uint32_t ogl_renderer_emu_texture;
EXTERN uint32_t ogl_renderer_emu_debug_vram_background;
EXTERN uint32_t ogl_renderer_emu_debug_vram_sprites[GC_MAX_SPRITES];
EXTERN uint32_t ogl_renderer_emu_debug_vram_tiles;
EXTERN uint32_t ogl_renderer_emu_debug_f18a_nametable;
EXTERN uint32_t ogl_renderer_emu_debug_f18a_sprites[GC_MAX_SPRITES];
EXTERN uint32_t ogl_renderer_emu_debug_f18a_patterns;
EXTERN uint32_t ogl_renderer_emu_savestates;
EXTERN const char* ogl_renderer_opengl_version;

struct OglRendererScreenGeometry
{
    int physical_width;
    int physical_height;
    float framebuffer_scale;
};

EXTERN bool ogl_renderer_init(void);
EXTERN void ogl_renderer_destroy(void);
EXTERN void ogl_renderer_begin_render(void);
EXTERN void ogl_renderer_render(bool new_frame);
EXTERN void ogl_renderer_end_render(void);
EXTERN void ogl_renderer_set_screen_geometry(const OglRendererScreenGeometry* geometry);
EXTERN uint32_t ogl_renderer_get_screen_texture(void);
EXTERN void ogl_renderer_get_screen_uv(float* u, float* v);
EXTERN bool ogl_renderer_get_output_size(int* width, int* height);
EXTERN bool ogl_renderer_load_shader_preset(const char* path);
EXTERN void ogl_renderer_unload_shader_preset(void);
EXTERN void ogl_renderer_save_shader_parameter_config(void);

#undef OGL_RENDERER_IMPORT
#undef EXTERN
#endif /* OGL_RENDERER_H */
