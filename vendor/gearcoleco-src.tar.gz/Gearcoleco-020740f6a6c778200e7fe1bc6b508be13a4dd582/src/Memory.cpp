/*
 * Gearcoleco - ColecoVision Emulator
 * Copyright (C) 2021  Ignacio Sanchez

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/
 *
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include "Memory.h"
#include "Processor.h"
#include "Cartridge.h"
#include "Mapper.h"
#include "StandardMapper.h"
#include "MegaCartMapper.h"
#include "ActivisionMapper.h"
#include "OCMMapper.h"
#include "random.h"

#include "Memory.h"
#include "Processor.h"
#include "Cartridge.h"
#include "common.h"

Memory::Memory(Cartridge* pCartridge, Random* pRandom)
{
    m_pCartridge = pCartridge;
    m_pRandom = pRandom;
    InitPointer(m_pProcessor);
    InitPointer(m_pMapper);
    InitPointer(m_pStandardMapper);
    InitPointer(m_pTraceLogger);
    InitPointer(m_pAdam);
    InitPointer(m_pDisassembledRomMap);
    InitPointer(m_pDisassembledRamMap);
    InitPointer(m_pDisassembledBiosMap);
    InitPointer(m_pDisassembledSGMRamMap);
    InitPointer(m_pDisassembledAdamMap);
    InitPointer(m_pDisassembledAdamGeneration);
    m_AdamDisassemblerGeneration = 0;
    InitPointer(m_pBios);
    InitPointer(m_pRam);
    InitPointer(m_pSGMRam);
    m_bBiosLoaded = false;
    m_bSGMUpper = false;
    m_bSGMLower = false;
    m_iTotalCycles = 0;
}

Memory::~Memory()
{
    SafeDelete(m_pMapper);
    SafeDeleteArray(m_pBios);
    SafeDeleteArray(m_pRam);
    SafeDeleteArray(m_pSGMRam);

    if (IsValidPointer(m_pDisassembledRomMap))
    {
        for (int i = 0; i < MAX_ROM_SIZE; i++)
        {
            SafeDelete(m_pDisassembledRomMap[i]);
        }
        SafeDeleteArray(m_pDisassembledRomMap);
    }

    if (IsValidPointer(m_pDisassembledRamMap))
    {
        for (int i = 0; i < 0x400; i++)
        {
            SafeDelete(m_pDisassembledRamMap[i]);
        }
        SafeDeleteArray(m_pDisassembledRamMap);
    }

    if (IsValidPointer(m_pDisassembledBiosMap))
    {
        for (int i = 0; i < 0x2000; i++)
        {
            SafeDelete(m_pDisassembledBiosMap[i]);
        }
        SafeDeleteArray(m_pDisassembledBiosMap);
    }

    if (IsValidPointer(m_pDisassembledSGMRamMap))
    {
        for (int i = 0; i < 0x8000; i++)
        {
            SafeDelete(m_pDisassembledSGMRamMap[i]);
        }
        SafeDeleteArray(m_pDisassembledSGMRamMap);
    }

    if (IsValidPointer(m_pDisassembledAdamMap))
    {
        for (int i = 0; i < 0x10000; i++)
        {
            SafeDelete(m_pDisassembledAdamMap[i]);
        }
        SafeDeleteArray(m_pDisassembledAdamMap);
    }

    SafeDeleteArray(m_pDisassembledAdamGeneration);
}

void Memory::SetProcessor(Processor* pProcessor)
{
    m_pProcessor = pProcessor;
}

void Memory::SetAdam(Adam* adam)
{
    m_pAdam = adam;
}

void Memory::SetTraceLogger(TraceLogger* pTraceLogger)
{
#if !defined(GEARCOLECO_DISABLE_DISASSEMBLER)
    m_pTraceLogger = pTraceLogger;
    if (IsValidPointer(m_pMapper))
        m_pMapper->SetTraceLogger(pTraceLogger);
#else
    UNUSED(pTraceLogger);
#endif
}

void Memory::Init()
{
    m_pRam = new u8[0x0400];
    m_pBios = new u8[0x2000];
    m_pSGMRam = new u8[0x8000];

#ifndef GEARCOLECO_DISABLE_DISASSEMBLER
    m_pDisassembledRomMap = new GC_Disassembler_Record*[MAX_ROM_SIZE];
    for (int i = 0; i < MAX_ROM_SIZE; i++)
    {
        InitPointer(m_pDisassembledRomMap[i]);
    }

    m_pDisassembledRamMap = new GC_Disassembler_Record*[0x400];
    for (int i = 0; i < 0x400; i++)
    {
        InitPointer(m_pDisassembledRamMap[i]);
    }

    m_pDisassembledBiosMap = new GC_Disassembler_Record*[0x2000];
    for (int i = 0; i < 0x2000; i++)
    {
        InitPointer(m_pDisassembledBiosMap[i]);
    }

    m_pDisassembledSGMRamMap = new GC_Disassembler_Record*[0x8000];
    for (int i = 0; i < 0x8000; i++)
    {
        InitPointer(m_pDisassembledSGMRamMap[i]);
    }

    m_pDisassembledAdamMap = new GC_Disassembler_Record*[0x10000];
    for (int i = 0; i < 0x10000; i++)
    {
        InitPointer(m_pDisassembledAdamMap[i]);
    }

    m_pDisassembledAdamGeneration = new u32[0x10000];
    memset(m_pDisassembledAdamGeneration, 0, sizeof(u32) * 0x10000);
#endif

    Reset();
}

void Memory::SetupMapper()
{
    SafeDelete(m_pMapper);
    InitPointer(m_pStandardMapper);

    switch (m_pCartridge->GetType())
    {
        case Cartridge::CartridgeMegaCart:
            m_pMapper = new MegaCartMapper(m_pCartridge);
            break;
        case Cartridge::CartridgeActivisionCart:
            m_pMapper = new ActivisionMapper(m_pCartridge);
            break;
        case Cartridge::CartridgeOCM:
            m_pMapper = new OCMMapper(m_pCartridge, this);
            break;
        default:
            m_pStandardMapper = new StandardMapper(m_pCartridge);
            m_pMapper = m_pStandardMapper;
            break;
    }

#if !defined(GEARCOLECO_DISABLE_DISASSEMBLER)
    m_pMapper->SetTraceLogger(m_pTraceLogger);
#endif
    m_pMapper->Reset();
}

void Memory::Reset()
{
    m_iTotalCycles = 0;

    if (IsValidPointer(m_pAdam) && m_pAdam->IsEnabled())
    {
        m_bSGMUpper = false;
        m_bSGMLower = false;
        memset(m_pRam, 0, 0x400);
        memset(m_pSGMRam, 0, 0x8000);
        m_pBios[0x69] = 0x3C;
        return;
    }

    m_bSGMUpper = (m_pCartridge->GetType() == Cartridge::CartridgeOCM);
    m_bSGMLower = false;

    for (int i = 0; i < 0x400; i += 4)
    {
        u32 rnd = m_pRandom->Next();
        m_pRam[i] = (u8)rnd;
        m_pRam[i + 1] = (u8)(rnd >> 8);
        m_pRam[i + 2] = (u8)(rnd >> 16);
        m_pRam[i + 3] = (u8)(rnd >> 24);
    }

    for (int i = 0; i < 0x8000; i += 4)
    {
        u32 rnd = m_pRandom->Next();
        m_pSGMRam[i] = (u8)rnd;
        m_pSGMRam[i + 1] = (u8)(rnd >> 8);
        m_pSGMRam[i + 2] = (u8)(rnd >> 16);
        m_pSGMRam[i + 3] = (u8)(rnd >> 24);
    }

    if (m_pCartridge->IsPAL())
        m_pBios[0x69] = 0x32;
    else
        m_pBios[0x69] = 0x3C;
}

void Memory::SaveState(std::ostream& stream)
{
    stream.write(reinterpret_cast<const char*> (m_pRam), 0x400);
    stream.write(reinterpret_cast<const char*> (m_pSGMRam), 0x8000);
    stream.write(reinterpret_cast<const char*> (&m_bSGMUpper), sizeof(m_bSGMUpper));
    stream.write(reinterpret_cast<const char*> (&m_bSGMLower), sizeof(m_bSGMLower));
    m_pMapper->SaveState(stream);
}

void Memory::LoadState(std::istream& stream)
{
    stream.read(reinterpret_cast<char*> (m_pRam), 0x400);
    stream.read(reinterpret_cast<char*> (m_pSGMRam), 0x8000);
    stream.read(reinterpret_cast<char*> (&m_bSGMUpper), sizeof(m_bSGMUpper));
    stream.read(reinterpret_cast<char*> (&m_bSGMLower), sizeof(m_bSGMLower));
    m_pMapper->LoadState(stream);
}

void Memory::LoadBios(const char* szFilePath)
{
    using namespace std;

    UnloadBios();

    ifstream file;
    open_ifstream_utf8(file, szFilePath, ios::in | ios::binary | ios::ate);

    if (file.is_open())
    {
        int size = static_cast<int> (file.tellg());

        if (size != 0x2000)
        {
            Log("Incorrect BIOS size %d: %s", size, szFilePath);
            return;
        }

        u8 bios[0x2000];
        file.seekg(0, ios::beg);

        if (!file.read(reinterpret_cast<char*>(bios), size))
        {
            Log("There was a problem reading the BIOS file %s", szFilePath);
            return;
        }

        file.close();

        LoadBiosFromBuffer(bios, size);

        Log("BIOS %s loaded (%d bytes)", szFilePath, size);
    }
    else
    {
        Log("There was a problem opening the file %s", szFilePath);
    }
}

bool Memory::LoadBiosFromBuffer(const u8* buffer, int size)
{
    UnloadBios();

    if (!IsValidPointer(buffer) || (size != 0x2000))
        return false;

    memcpy(m_pBios, buffer, size);
    m_bBiosLoaded = true;
    return true;
}

void Memory::UnloadBios()
{
    m_bBiosLoaded = false;
}

u8* Memory::GetRam()
{
    return m_pRam;
}

u8* Memory::GetSGMRam()
{
    return m_pSGMRam;
}

u8* Memory::GetBios()
{
    return m_pBios;
}

u8 Memory::GetRomBank()
{
    return IsValidPointer(m_pMapper) ? m_pMapper->GetRomBank() : 0;
}

u32 Memory::GetRomBankAddress()
{
    return IsValidPointer(m_pMapper) ? m_pMapper->GetRomBankAddress() : 0;
}

bool Memory::IsBiosLoaded() const
{
    return m_bBiosLoaded;
}

void Memory::EnableSGMUpper(bool enable)
{
    m_bSGMUpper = enable;
}

void Memory::EnableSGMLower(bool enable)
{
    m_bSGMLower = enable;
}

Mapper* Memory::GetMapper()
{
    return m_pMapper;
}

void Memory::ResetRomDisassembledMemory()
{
    #ifndef GEARCOLECO_DISABLE_DISASSEMBLER

    if (IsValidPointer(m_pDisassembledRomMap))
    {
        for (int i = 0; i < MAX_ROM_SIZE; i++)
        {
            SafeDelete(m_pDisassembledRomMap[i]);
        }
    }

    if (IsValidPointer(m_pDisassembledRamMap))
    {
        for (int i = 0; i < 0x400; i++)
        {
            SafeDelete(m_pDisassembledRamMap[i]);
        }
    }

    if (IsValidPointer(m_pDisassembledBiosMap))
    {
        for (int i = 0; i < 0x2000; i++)
        {
            SafeDelete(m_pDisassembledBiosMap[i]);
        }
    }

    if (IsValidPointer(m_pDisassembledSGMRamMap))
    {
        for (int i = 0; i < 0x8000; i++)
        {
            SafeDelete(m_pDisassembledSGMRamMap[i]);
        }
    }

    if (IsValidPointer(m_pDisassembledAdamMap))
    {
        for (int i = 0; i < 0x10000; i++)
        {
            SafeDelete(m_pDisassembledAdamMap[i]);
        }
    }

    if (IsValidPointer(m_pDisassembledAdamGeneration))
        memset(m_pDisassembledAdamGeneration, 0, sizeof(u32) * 0x10000);

    m_AdamDisassemblerGeneration = IsValidPointer(m_pAdam) ? m_pAdam->GetMemoryMapGeneration() : 0;

    #endif
}

GC_Disassembler_Record* Memory::GetOrCreateDisassemblerRecord(u16 address)
{
#ifndef GEARCOLECO_DISABLE_DISASSEMBLER

    GC_Disassembler_Record** map = NULL;
    int offset = address;
    int bank = 0;

    if (IsValidPointer(m_pAdam) && m_pAdam->IsEnabled())
        return GetOrCreateAdamDisassemblerRecord(address);

    switch (address & 0xE000)
    {
        case 0x0000:
        {
            offset = address;
            map = m_bSGMLower ? m_pDisassembledSGMRamMap : m_pDisassembledBiosMap;
            break;
        }
        case 0x2000:
        case 0x4000:
        {
            offset = address;
            map = m_pDisassembledSGMRamMap;
            break;
        }
        case 0x6000:
        {
            offset = m_bSGMUpper ? address : address & 0x03FF;
            map = m_bSGMUpper ? m_pDisassembledSGMRamMap : m_pDisassembledRamMap;
            break;
        }
        default:
        {
            map = m_pDisassembledRomMap;

            switch (m_pCartridge->GetType())
            {
                case Cartridge::CartridgeMegaCart:
                {
                    if (address < 0xC000)
                    {
                        offset = (address & 0x3FFF) + (m_pCartridge->GetROMSize() - 0x4000);
                        bank = m_pCartridge->GetROMBankCount() - 1;
                    }
                    else
                    {
                        offset = (address & 0x3FFF) + GetRomBankAddress();
                        bank = GetRomBank();
                    }
                    break;
                }
                case Cartridge::CartridgeActivisionCart:
                {
                    if (address < 0xC000)
                    {
                        offset = address & 0x3FFF;
                        bank = 0;
                    }
                    else
                    {
                        offset = (address & 0x3FFF) + GetRomBankAddress();
                        bank = GetRomBank();
                    }
                    break;
                }
                case Cartridge::CartridgeOCM:
                {
                    if (address < 0xA000)
                    {
                        offset = (address - 0x8000) + (m_pMapper->GetBankReg(3) * 0x2000);
                        bank = m_pMapper->GetBankReg(3);
                    }
                    else if (address < 0xC000)
                    {
                        offset = (address - 0xA000) + (m_pMapper->GetBankReg(0) * 0x2000);
                        bank = m_pMapper->GetBankReg(0);
                    }
                    else if (address < 0xE000)
                    {
                        offset = (address - 0xC000) + (m_pMapper->GetBankReg(1) * 0x2000);
                        bank = m_pMapper->GetBankReg(1);
                    }
                    else
                    {
                        offset = (address - 0xE000) + (m_pMapper->GetBankReg(2) * 0x2000);
                        bank = m_pMapper->GetBankReg(2);
                    }
                    break;
                }
                default:
                {
                    offset = address - 0x8000;
                    bank = 0;
                    break;
                }
            }
        }
    }

    return GetOrCreateDisassemblerRecord(map, offset, bank);

#else
    UNUSED(address);
    return NULL;
#endif
}

GC_Disassembler_Record* Memory::GetOrCreateDisassemblerRecord(GC_Disassembler_Record** map,
    int offset, int bank)
{
#ifndef GEARCOLECO_DISABLE_DISASSEMBLER
    GC_Disassembler_Record* record = map[offset];

    if (!IsValidPointer(record))
    {
        record = new GC_Disassembler_Record();
        record->bank = (u8)bank;
        record->segment[0] = 0;
        record->name[0] = 0;
        record->bytes[0] = 0;
        record->size = 0;
        for (int i = 0; i < 7; i++)
            record->opcodes[i] = 0;
        record->jump = false;
        record->jump_address = 0;
        record->jump_bank = 0;
        record->subroutine = false;
        record->irq = 0;
        record->has_operand_address = false;
        record->operand_address = 0;
        record->operand_is_zp = false;
        record->operand_offset = 0;
        record->operand_length = 0;
        record->auto_symbol[0] = 0;
        map[offset] = record;
    }

    return record;

#else
    UNUSED(map);
    UNUSED(offset);
    UNUSED(bank);
    return NULL;
#endif
}

GC_Disassembler_Record* Memory::GetDisassemblerRecord(u16 address)
{
#ifndef GEARCOLECO_DISABLE_DISASSEMBLER

    GC_Disassembler_Record** map = NULL;
    int offset = address;

    if (IsValidPointer(m_pAdam) && m_pAdam->IsEnabled())
    {
        SyncAdamDisassemblerMap();
        return GetAdamDisassemblerRecord(address, GetBank(address));
    }

    switch (address & 0xE000)
    {
        case 0x0000:
        {
            offset = address;
            map = m_bSGMLower ? m_pDisassembledSGMRamMap : m_pDisassembledBiosMap;
            break;
        }
        case 0x2000:
        case 0x4000:
        {
            offset = address;
            map = m_pDisassembledSGMRamMap;
            break;
        }
        case 0x6000:
        {
            offset = m_bSGMUpper ? address : address & 0x03FF;
            map = m_bSGMUpper ? m_pDisassembledSGMRamMap : m_pDisassembledRamMap;
            break;
        }
        default:
        {
            map = m_pDisassembledRomMap;

            switch (m_pCartridge->GetType())
            {
                case Cartridge::CartridgeMegaCart:
                {
                    if (address < 0xC000)
                    {
                        offset = (address & 0x3FFF) + (m_pCartridge->GetROMSize() - 0x4000);
                    }
                    else
                    {
                        offset = (address & 0x3FFF) + GetRomBankAddress();
                    }
                    break;
                }
                case Cartridge::CartridgeActivisionCart:
                {
                    if (address < 0xC000)
                    {
                        offset = address & 0x3FFF;
                    }
                    else
                    {
                        offset = (address & 0x3FFF) + GetRomBankAddress();
                    }
                    break;
                }
                case Cartridge::CartridgeOCM:
                {
                    if (address < 0xA000)
                        offset = (address - 0x8000) + (m_pMapper->GetBankReg(3) * 0x2000);
                    else if (address < 0xC000)
                        offset = (address - 0xA000) + (m_pMapper->GetBankReg(0) * 0x2000);
                    else if (address < 0xE000)
                        offset = (address - 0xC000) + (m_pMapper->GetBankReg(1) * 0x2000);
                    else
                        offset = (address - 0xE000) + (m_pMapper->GetBankReg(2) * 0x2000);
                    break;
                }
                default:
                {
                    offset = address - 0x8000;
                    break;
                }
            }
        }
    }

    return map[offset];

#else
    UNUSED(address);
    return NULL;
#endif
}

void Memory::SyncAdamDisassemblerMap()
{
#ifndef GEARCOLECO_DISABLE_DISASSEMBLER
    if (!IsValidPointer(m_pAdam) || !IsValidPointer(m_pDisassembledAdamMap))
        return;

    u32 generation = m_pAdam->GetMemoryMapGeneration();
    m_AdamDisassemblerGeneration = generation;
#endif
}

GC_Disassembler_Record** Memory::GetDisassemblerAdamMap()
{
#ifndef GEARCOLECO_DISABLE_DISASSEMBLER
    SyncAdamDisassemblerMap();
    for (int i = 0; i < 0x10000; i++)
    {
        if (IsValidPointer(m_pDisassembledAdamMap[i]))
            GetAdamDisassemblerRecord((u16)i, GetBank((u16)i));
    }
#endif
    return m_pDisassembledAdamMap;
}

GC_Disassembler_Record* Memory::GetOrCreateAdamDisassemblerRecord(u16 address)
{
#ifndef GEARCOLECO_DISABLE_DISASSEMBLER
    SyncAdamDisassemblerMap();
    u8 bank = GetBank(address);

    if (!IsValidPointer(GetAdamDisassemblerRecord(address, bank)))
        m_pDisassembledAdamGeneration[address] = m_AdamDisassemblerGeneration;

    return GetOrCreateDisassemblerRecord(m_pDisassembledAdamMap, address, bank);
#else
    UNUSED(address);
    return NULL;
#endif
}

GC_Disassembler_Record* Memory::GetAdamDisassemblerRecord(u16 address, u8 bank)
{
#ifndef GEARCOLECO_DISABLE_DISASSEMBLER
    GC_Disassembler_Record* record = m_pDisassembledAdamMap[address];

    if (IsValidPointer(record) &&
        ((m_pDisassembledAdamGeneration[address] != m_AdamDisassemblerGeneration) ||
        (record->bank != bank) ||
        (record->jump && ((address ^ record->jump_address) & 0xE000) &&
        m_pCartridge->IsReady() && (record->jump_bank != GetBank(record->jump_address)))))
    {
        SafeDelete(m_pDisassembledAdamMap[address]);
    }

    return m_pDisassembledAdamMap[address];
#else
    UNUSED(address);
    UNUSED(bank);
    return NULL;
#endif
}

u32 Memory::GetPhysicalAddress(u16 address)
{
    if (IsValidPointer(m_pAdam) && m_pAdam->IsEnabled())
        return address;

    return GetCartridgeROMOffset(address);
}

u32 Memory::GetCartridgeROMOffset(u16 address)
{
    if (address < 0x8000)
        return (u32)address;

    switch (m_pCartridge->GetType())
    {
        case Cartridge::CartridgeMegaCart:
        {
            if (address < 0xC000)
                return (u32)((address & 0x3FFF) + (m_pCartridge->GetROMSize() - 0x4000));
            else
                return (u32)((address & 0x3FFF) + GetRomBankAddress());
        }
        case Cartridge::CartridgeActivisionCart:
        {
            if (address < 0xC000)
                return (u32)(address & 0x3FFF);
            else
                return (u32)((address & 0x3FFF) + GetRomBankAddress());
        }
        case Cartridge::CartridgeOCM:
        {
            if (address < 0xA000)
                return (u32)((address - 0x8000) + (m_pMapper->GetBankReg(3) * 0x2000));
            else if (address < 0xC000)
                return (u32)((address - 0xA000) + (m_pMapper->GetBankReg(0) * 0x2000));
            else if (address < 0xE000)
                return (u32)((address - 0xC000) + (m_pMapper->GetBankReg(1) * 0x2000));
            else
                return (u32)((address - 0xE000) + (m_pMapper->GetBankReg(2) * 0x2000));
        }
        default:
            return (u32)(address - 0x8000);
    }
}

u8 Memory::GetBank(u16 address)
{
    if (IsValidPointer(m_pAdam) && m_pAdam->IsEnabled() &&
        (m_pAdam->GetMemorySource(address) != Adam::MemorySourceCartridge))
    {
        return 0;
    }

    if (address < 0x8000)
        return 0;

    switch (m_pCartridge->GetType())
    {
        case Cartridge::CartridgeMegaCart:
        {
            if (address < 0xC000)
                return (u8)(m_pCartridge->GetROMBankCount() - 1);
            else
                return GetRomBank();
        }
        case Cartridge::CartridgeActivisionCart:
        {
            if (address < 0xC000)
                return 0;
            else
                return GetRomBank();
        }
        case Cartridge::CartridgeOCM:
        {
            if (address < 0xA000)
                return (u8)m_pMapper->GetBankReg(3);
            else if (address < 0xC000)
                return (u8)m_pMapper->GetBankReg(0);
            else if (address < 0xE000)
                return (u8)m_pMapper->GetBankReg(1);
            else
                return (u8)m_pMapper->GetBankReg(2);
        }
        default:
            return 0;
    }
}
