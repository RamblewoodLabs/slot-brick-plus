/*
 * afile.c - Detection and opening of different Atari file types.
 *
 * Copyright (c) 1998-2008 Atari800 development team (see DOC/CREDITS)
 *
 * This file is part of the Atari800 emulator project which emulates
 * the Atari 400, 800, 800XL, 130XE, and 5200 8-bit computers.
 *
 * Atari800 is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Atari800 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Atari800; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/
#include "config.h"
#include "atari.h"
#include "afile.h"
#include "binload.h"
#include "cartridge.h"
#include "cassette.h"
#include "gtia.h"
#include "img_tape.h"
#include "log.h"
#include "sio.h"
#include "statesav.h"
#include "util.h"
#ifndef BASIC
#include "ui.h"
#endif /* BASIC */
#ifdef HAVE_LIBZ
#include <zlib.h>
#endif
#include <stdio.h>
#ifdef __LIBRETRO__
#include "crc32.h"
#include "carts_hash.h"
#endif


int AFILE_DetectFileType(const char *filename)
{
	UBYTE header[4];
	int file_length;
#ifdef __LIBRETRO__
	retro_file_t *fp = retro_vfs_fopen(filename, RETRO_VFS_FILE_ACCESS_READ,
			RETRO_VFS_FILE_ACCESS_HINT_NONE);
#else
	FILE *fp = fopen(filename, "rb");
#endif

	if (fp == NULL)
		return AFILE_ERROR;

#ifdef __LIBRETRO__
	/* False positives - hack for raw images */
	{
		ULONG crc;
		CRC32_FromFile(fp, &crc);
		retro_vfs_fseek(fp, 0, RETRO_VFS_SEEK_POSITION_START);
		if (is_cart(crc)) {
			retro_vfs_fclose(fp);
			return AFILE_ROM;
		}
	}
#else
	if (fread(header, 1, 4, fp) != 4) {
		fclose(fp);
		return AFILE_ERROR;
	}
#endif /* __LIBRETRO__ */

#ifdef __LIBRETRO__
	if (retro_vfs_fread(fp, header, 4) != 4) {
		retro_vfs_fclose(fp);
		return AFILE_ERROR;
	}
#endif

	switch (header[0]) {
	case 0:
		if (header[1] == 0 && (header[2] != 0 || header[3] != 0) /* && file_length < 37 * 1024 */) {
#ifdef __LIBRETRO__
			retro_vfs_fclose(fp);
#else
			fclose(fp);
#endif
			return AFILE_BAS;
		}
		break;
	case 0x1f:
		if (header[1] == 0x8b) {
#ifndef HAVE_LIBZ
#ifdef __LIBRETRO__
			retro_vfs_fclose(fp);
#else
			fclose(fp);
#endif
			Log_print("\"%s\" is a compressed file.", filename);
			Log_print("This executable does not support compressed files. You can uncompress this file");
			Log_print("with an external program that supports gzip (*.gz) files (e.g. gunzip)");
			Log_print("and then load into this emulator.");
			return AFILE_ERROR;
#else /* HAVE_LIBZ */
#ifdef __LIBRETRO__
			retro_vfs_fclose(fp);
#else
			fclose(fp);
#endif
			{
				gzFile gzf = gzopen(filename, "rb");
				if (gzf == NULL)
					return AFILE_ERROR;
				if (gzread(gzf, header, 4) != 4) {
					gzclose(gzf);
					return AFILE_ERROR;
				}
				gzclose(gzf);
				if (header[0] == 0x96 && header[1] == 0x02)
					return AFILE_ATR_GZ;
				if (header[0] == 'A' && header[1] == 'T' &&
					header[2] == 'A' && header[3] == 'R')
					return AFILE_STATE_GZ;
				return AFILE_XFD_GZ;
			}
#endif /* HAVE_LIBZ */
		}
		break;
	case '0':
	case '1':
	case '2':
	case '3':
	case '4':
	case '5':
	case '6':
	case '7':
	case '8':
	case '9':
		if ((header[1] >= '0' && header[1] <= '9') || header[1] == ' ') {
#ifdef __LIBRETRO__
			retro_vfs_fclose(fp);
#else
			fclose(fp);
#endif
			return AFILE_LST;
		}
		break;
	case 'A':
		if (header[1] == 'T' && header[2] == 'A' && header[3] == 'R') {
#ifdef __LIBRETRO__
			retro_vfs_fclose(fp);
#else
			fclose(fp);
#endif
			return AFILE_STATE;
		}
		if (header[1] == 'T' && header[2] == '8' && header[3] == 'X') {
#ifdef __LIBRETRO__
			retro_vfs_fclose(fp);
#else
			fclose(fp);
#endif
			return AFILE_ATX;
		}
		break;
	case 'C':
		if (header[1] == 'A' && header[2] == 'R' && header[3] == 'T') {
#ifdef __LIBRETRO__
			retro_vfs_fclose(fp);
#else
			fclose(fp);
#endif
			return AFILE_CART;
		}
		break;
	case 0x96:
		if (header[1] == 0x02) {
#ifdef __LIBRETRO__
			retro_vfs_fclose(fp);
#else
			fclose(fp);
#endif
			return AFILE_ATR;
		}
		break;
	case 0xf9:
	case 0xfa:
#ifdef __LIBRETRO__
		retro_vfs_fclose(fp);
#else
		fclose(fp);
#endif
		return AFILE_DCM;
	case 0xff:
		if (header[1] == 0xff && (header[2] != 0xff || header[3] != 0xff)) {
#ifdef __LIBRETRO__
			retro_vfs_fclose(fp);
#else
			fclose(fp);
#endif
			return AFILE_XEX;
		}
		break;
	}
#ifdef __LIBRETRO__
	file_length = (int)retro_vfs_fsize(fp);
	retro_vfs_fclose(fp);
#else
	file_length = Util_flen(fp);
	fclose(fp);
#endif
	/* Detect .pro images */
	/* # of sectors is in header */
	if ((file_length-16)%(128+12) == 0 &&
			header[0]*256 + header[1] == (file_length-16)/(128+12) &&
			header[2] == 'P') {
#ifdef DEBUG_PRO
		Log_print(".pro file detected");
#endif
		return AFILE_PRO;
	}
	/* 40K or a-power-of-two between 4K and CARTRIDGE_MAX_SIZE */
	if (file_length >= 4 * 1024 && file_length <= CARTRIDGE_MAX_SIZE
	 && ((file_length & (file_length - 1)) == 0 || file_length == 40 * 1024))
		return AFILE_ROM;
	/* BOOT_TAPE is a raw file containing a program booted from a tape */
	if ((header[1] << 7) == file_length)
		return AFILE_BOOT_TAPE;
	if (IMG_TAPE_FileSupported(header))
		return AFILE_CAS;
	if ((file_length & 0x7f) == 0)
		return AFILE_XFD;
	return AFILE_ERROR;
}

int AFILE_OpenFile(const char *filename, int reboot, int diskno, int readonly)
{
	int type = AFILE_DetectFileType(filename);
	switch (type) {
	case AFILE_ATR:
	case AFILE_ATX:
	case AFILE_XFD:
	case AFILE_ATR_GZ:
	case AFILE_XFD_GZ:
	case AFILE_DCM:
	case AFILE_PRO:
		if (!SIO_Mount(diskno, filename, readonly))
			return AFILE_ERROR;
		if (reboot)
			Atari800_Coldstart();
		break;
	case AFILE_XEX:
	case AFILE_BAS:
	case AFILE_LST:
		if (!BINLOAD_Loader(filename))
			return AFILE_ERROR;
		break;
	case AFILE_CART:
	case AFILE_ROM:
		{
			int r;
			if (reboot)
				r = CARTRIDGE_InsertAutoReboot(filename);
			else
				r = CARTRIDGE_Insert(filename);
			switch (r) {
			case CARTRIDGE_CANT_OPEN:
			case CARTRIDGE_BAD_FORMAT:
				return AFILE_ERROR;
			case CARTRIDGE_BAD_CHECKSUM:
			case 0:
				/* ok */
				break;
			default:
				/* r > 0 */
				return (r << 8) | AFILE_ROM;
			}
		}
		break;
	case AFILE_CAS:
	case AFILE_BOOT_TAPE:
		if (!CASSETTE_Insert(filename))
			return AFILE_ERROR;
		if (reboot) {
			CASSETTE_hold_start = TRUE;
			Atari800_Coldstart();
		}
		break;
	case AFILE_STATE:
	case AFILE_STATE_GZ:
#ifdef BASIC
		Log_print("State files are not supported in BASIC version");
		return AFILE_ERROR;
#else
		if (!StateSav_ReadAtariState(filename, "rb"))
			return AFILE_ERROR;
		/* Don't press Start nor Option */
		GTIA_consol_override = 0;
		break;
#endif
	default:
		break;
	}
	return type;
}
