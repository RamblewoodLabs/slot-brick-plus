APP_STL := c++_static
APP_ABI := arm64-v8a armeabi-v7a x86 x86_64
